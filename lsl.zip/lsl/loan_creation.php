<?php session_start(); ?>
<?php require('./config.php'); ?>
<?php


if (!isset($_SESSION['staffname'])) {
    echo "<script>window.location.replace('login.php');</script>";
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Capture form data and calculate Agreed Monthly Payment
    $customerId = $_POST['customer_id'];
    $monthlyInterestRate = $_POST['monthly_interest_rate'];
    $requestedAmount = $_POST['requested_amount'];
    $repayDuration = $_POST['repay_duration'];
    $purpose = $_POST['purpose'];
    $loanType = $_POST['loan_type'];
    $guarantee1 = $_POST['guarantee_1'];
    $guarantee2 = $_POST['guarantee_2'];
    $guaranteeType = $_POST['guarantee_type'];
    $landAddress = $_POST['land_address'];
    $landSize = $_POST['land_size'];
    $landEmpty = $_POST['land_empty'];
    $nearestLandmark = $_POST['nearest_landmark'];
    $nearestCity = $_POST['nearest_city'];
    $lawyerName = $_POST['lawyer_name'];
    $lawyerOffice = $_POST['lawyer_office'];
    $lawyerAddress = $_POST['lawyer_address'];
    $agreedMonthlyPayment = $_POST['agreed_monthly_payment']; // Allow changes by user
    $createdBy = $_SESSION['staffname'];

    $stmt = $conn->prepare("INSERT INTO tbl_loan 
        (customer_id, monthly_interest_rate, requested_amount, repay_duration, purpose, agreed_monthly_payment, loan_type, guarantee_1, guarantee_2, guarantee_type, land_address, land_size, land_empty, nearest_landmark, nearest_city, lawyer_name, lawyer_office, lawyer_address, created_by)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

    $stmt->bind_param('iddisssiiisssssssss', 
        $customerId, $monthlyInterestRate, $requestedAmount, $repayDuration, $purpose, $agreedMonthlyPayment, $loanType, $guarantee1, $guarantee2, 
        $guaranteeType, $landAddress, $landSize, $landEmpty, $nearestLandmark, $nearestCity, $lawyerName, $lawyerOffice, $lawyerAddress, $createdBy);

    if ($stmt->execute()) {
        echo json_encode(['status' => 'success']);
    } else {
        echo json_encode(['status' => 'error']);
    }
    exit;
}
?>
<?php
if (!isset($_SESSION['staffname'])) {
    echo "<script> window.location.replace('login.php'); </script>";
} else { ?>
    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="utf-8" />
        <title>Add Customer</title>
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta content="Customer Management System" name="description" />
        <meta content="MyraStudio" name="author" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />

        <!-- App css -->
        <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/icons.min.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/theme.min.css" rel="stylesheet" type="text/css" />

        <!-- SweetAlert2 -->
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
        <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/css/select2.min.css" rel="stylesheet" />
    </head>

    <body>

        <div id="layout-wrapper">
            <?php include('header.php'); ?>
            <?php include('sidebar.php'); ?>

            <div class="main-content">
                <div class="page-content">
                    <div class="container-fluid">

                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box d-flex align-items-center justify-content-between">
                                    <h4 class="mb-0 font-size-18">Add Customer</h4>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-12">
                                <div class="card">
                                    <div class="card-body">
                                        <h4 class="card-title">New Customer</h4>
                                        <p class="card-subtitle mb-4">Fill in the required fields to add a new customer.</p>

                                        <h2 class="mt-4">Loan Creation</h2>
    <form id="loanForm" method="POST">
        <div class="form-group">
            <label for="customer_id">Customer</label>
            <select class="form-control select2" id="customer_id" name="customer_id" required>
                <!-- Fetch customers dynamically -->
            </select>
        </div>
        <div class="form-group">
            <label for="monthly_interest_rate">Monthly Interest Rate</label>
            <input type="number" class="form-control" id="monthly_interest_rate" name="monthly_interest_rate" required>
        </div>
        <div class="form-group">
            <label for="requested_amount">Requested Amount</label>
            <input type="number" class="form-control" id="requested_amount" name="requested_amount" required>
        </div>
        <div class="form-group">
            <label for="repay_duration">Repay Duration (Months)</label>
            <input type="number" class="form-control" id="repay_duration" name="repay_duration" required>
        </div>
        <div class="form-group">
            <label for="purpose">Purpose</label>
            <input type="text" class="form-control" id="purpose" name="purpose" required>
        </div>
        <div class="form-group">
            <label for="loan_type">Loan Type</label>
            <select class="form-control" id="loan_type" name="loan_type" required>
                <option value="Business">Business</option>
                <option value="Personal">Personal</option>
                <option value="Gold Loan">Gold Loan</option>
                <option value="Housing Loan">Housing Loan</option>
            </select>
        </div>
        <div class="form-group">
            <label for="agreed_monthly_payment">Agreed Monthly Payment</label>
            <input type="number" class="form-control" id="agreed_monthly_payment" name="agreed_monthly_payment" required>
        </div>
        <div class="form-group">
            <label for="guarantee_1">Guarantee 1</label>
            <select class="form-control select2" id="guarantee_1" name="guarantee_1" required></select>
        </div>
        <div class="form-group">
            <label for="guarantee_2">Guarantee 2</label>
            <select class="form-control select2" id="guarantee_2" name="guarantee_2"></select>
        </div>
        <div class="form-group">
            <label for="guarantee_type">Guarantee Type</label>
            <select class="form-control" id="guarantee_type" name="guarantee_type" required>
                <option value="Land">Land</option>
                <option value="Vehicle">Vehicle</option>
            </select>
        </div>
        <div class="form-group">
            <label for="land_address">Address of Land</label>
            <input type="text" class="form-control" id="land_address" name="land_address">
        </div>
        <div class="form-group">
            <label for="land_size">Size of Land</label>
            <input type="text" class="form-control" id="land_size" name="land_size">
        </div>
        <div class="form-group">
            <label for="land_empty">Is Land Empty?</label>
            <select class="form-control" id="land_empty" name="land_empty">
                <option value="Yes">Yes</option>
                <option value="No">No</option>
            </select>
        </div>
        <div class="form-group">
            <label for="nearest_landmark">Nearest Landmark</label>
            <input type="text" class="form-control" id="nearest_landmark" name="nearest_landmark">
        </div>
        <div class="form-group">
            <label for="nearest_city">Nearest City</label>
            <input type="text" class="form-control" id="nearest_city" name="nearest_city">
        </div>
        <div class="form-group">
            <label for="lawyer_name">Lawyer Name</label>
            <input type="text" class="form-control" id="lawyer_name" name="lawyer_name">
        </div>
        <div class="form-group">
            <label for="lawyer_office">Lawyer Office</label>
            <input type="text" class="form-control" id="lawyer_office" name="lawyer_office">
        </div>
        <div class="form-group">
            <label for="lawyer_address">Lawyer Address</label>
            <input type="text" class="form-control" id="lawyer_address" name="lawyer_address">
        </div>
        <button type="submit" class="btn btn-primary">Submit</button>
    </form>

                                    </div> <!-- end card-body -->
                                </div> <!-- end card -->
                            </div> <!-- end col -->
                        </div> <!-- end row -->

                    </div> <!-- container-fluid -->
                </div> <!-- End Page-content -->
            </div> <!-- end main content -->
        </div> <!-- END layout-wrapper -->

        <!-- jQuery  -->
        <!-- <script src="assets/js/jquery.min.js"></script> -->
        <script src="assets/js/bootstrap.bundle.min.js"></script>
        <script src="assets/js/waves.js"></script>
        <script src="assets/js/simplebar.min.js"></script>

        <!-- SweetAlert2 -->
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
        
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/js/select2.min.js"></script>

        <!-- App js -->
        <script src="assets/js/theme.js"></script>


        <script>
$(document).ready(function() {
    $('.select2').select2();

    // Load customer data for select2 fields (customer_id, guarantee_1, guarantee_2)
    function loadCustomers() {
        $.ajax({
            url: 'get_customers.php',
            type: 'GET',
            dataType: 'json',
            success: function(data) {
                let customerOptions = '';
                data.forEach(function(customer) {
                    customerOptions += `<option value="${customer.id}">${customer.name} (${customer.nic_no})</option>`;
                });
                $('#customer_id').html(customerOptions);
                $('#guarantee_1').html(customerOptions);
                $('#guarantee_2').html(customerOptions);
            },
            error: function(xhr, status, error) {
                console.error('Error loading customers:', error);
            }
        });
    }

    // Call loadCustomers on page load
    loadCustomers();

    // Handle form submission
    $('#loanForm').on('submit', function(e) {
        e.preventDefault();
        let formData = $(this).serialize();

        $.ajax({
            url: 'loan_creation.php',
            type: 'POST',
            data: formData,
            success: function(response) {
                let res = JSON.parse(response);
                if (res.status === 'success') {
                    Swal.fire({
                        icon: 'success',
                        title: 'Loan Created Successfully!',
                        showConfirmButton: false,
                        timer: 2000
                    });
                    $('#loanForm')[0].reset();
                    $('.select2').val(null).trigger('change');
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'Failed to Create Loan!',
                        text: 'Please try again.'
                    });
                }
            }
        });
    });
});
</script>
    </body>

    </html>
<?php } ?>