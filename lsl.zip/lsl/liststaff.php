<?php
session_start();
require('./config.php');
if (!isset($_SESSION['staffname'])) {
    header('Location: login.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <title>LSL System</title>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta content="Premium Multipurpose Admin & Dashboard Template" name="description" />
    <meta content="MyraStudio" name="author" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />

    <!-- App favicon -->
    <link rel="shortcut icon" href="assets/images/favicon.ico">

    <!-- App css -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <link href="assets/css/icons.min.css" rel="stylesheet" type="text/css" />
    <link href="assets/css/theme.min.css" rel="stylesheet" type="text/css" />

    <!-- DataTables css -->
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.css">

    <!-- SweetAlert2 -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>

</head>

<body>
    <div id="layout-wrapper">
        <?php include('header.php'); ?>
        <?php include('sidebar.php'); ?>

        <div class="main-content">
            <div class="page-content">
                <div class="container-fluid">
                    <!-- Page title -->
                    <div class="row">
                        <div class="col-12">
                            <div class="page-title-box d-flex align-items-center justify-content-between">
                                <h4 class="mb-0 font-size-18">Staff</h4>
                                <div class="page-title-right">
                                    <ol class="breadcrumb m-0">
                                        <li class="breadcrumb-item"><a href="javascript: void(0);">Staff</a></li>
                                        <li class="breadcrumb-item active">Add Staff</li>
                                    </ol>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Table -->
                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-body">
                                    <h4 class="card-title">Add Staff</h4>
                                    <p class="card-subtitle mb-4">Add staff here with required details.</p>

                                    <div class="table-responsive">
                                        <table class="table table-striped table-bordered" id="staffTable">
                                            <thead>
                                                <tr>
                                                    <th>Name</th>
                                                    <th>User Type</th>
                                                    <th>Email</th>
                                                    <th>Username</th>
                                                    <th>Phone</th>
                                                    <th>Status</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody></tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>

            <footer class="footer">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-sm-6">2020 © Xeloro.</div>
                        <div class="col-sm-6">
                            <div class="text-sm-right d-none d-sm-block">Design & Develop by Myra</div>
                        </div>
                    </div>
                </div>
            </footer>

        </div>
    </div>

    <div class="menu-overlay"></div>

    <!-- Scripts -->
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/metismenu.min.js"></script>
    <script src="assets/js/waves.js"></script>
    <script src="assets/js/simplebar.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.js"></script>
    
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>


    <script>
        var $j = jQuery.noConflict();

        $j(document).ready(function() {
            var table = $j('#staffTable').DataTable({
                "ajax": "staffdata.php",
                "columns": [{
                        "data": "name"
                    },
                    {
                        "data": "user_type"
                    },
                    {
                        "data": "email"
                    },
                    {
                        "data": "username"
                    },
                    {
                        "data": "phone"
                    },
                    {
                        "data": "status"
                    },
                    {
                        "data": null,
                        "render": function(data, type, full, meta) {
                            if (full.usertype === 'admin') {
                                return "<button class='edit-btn btn btn-primary' disabled>Edit</button> &nbsp;&nbsp; <button class='delete-btn btn btn-danger'>Delete</button>";
                            } else {
                                return "<button class='edit-btn btn btn-primary'>Edit</button> &nbsp;&nbsp; <button class='delete-btn btn btn-danger'>Delete</button>";
                            }
                        }
                    }
                ],
                "createdRow": function(row, data, dataIndex) {
                    $j(row).find('.edit-btn').on('click', function() {
                        var username = data.username;
                        window.location.href = 'edit_staff.php?id=' + username;
                    });

                    $j(row).find('.delete-btn').on('click', function() {
                        var username = data.username;
                        Swal.fire({
                            title: 'Are you sure?',
                            text: "You won't be able to revert this!",
                            icon: 'warning',
                            showCancelButton: true,
                            confirmButtonColor: '#3085d6',
                            cancelButtonColor: '#d33',
                            confirmButtonText: 'Yes, delete it!'
                        }).then((result) => {
                            if (result.isConfirmed) {
                                deleteStaff(username);
                            }
                        });
                    });
                }
            });

            function deleteStaff(username) {
                $j.ajax({
                    type: 'POST',
                    url: 'delete_staff.php',
                    data: {
                        id: username
                    },
                    success: function(response) {
                        Swal.fire('Deleted!', 'Staff has been deleted.', 'success');
                        table.ajax.reload();
                    },
                    error: function(xhr, status, error) {
                        Swal.fire('Error!', 'An error occurred while deleting staff.', 'error');
                    }
                });
            }
        });
    </script>

</body>
</html>
