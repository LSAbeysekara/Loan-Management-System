<?php
session_start();
require('./config.php');

// Check if the user is logged in
if (!isset($_SESSION['staffname'])) {
    echo "<script>window.location.replace('login.php');</script>";
    exit;
}

// Check if lender ID is provided
if (isset($_GET['id'])) {
    $lenderId = intval($_GET['id']); // Sanitize input

    // Fetch lender details
    $query = $conn->prepare("SELECT * FROM tbl_lender WHERE id = ?");
    $query->bind_param("i", $lenderId);
    $query->execute();
    $result = $query->get_result();

    if ($result->num_rows > 0) {
        $lender = $result->fetch_assoc();
    } else {
        echo "<script>alert('Lender not found.'); window.location.replace('lender_list.php');</script>";
        exit;
    }
} else {
    echo "<script>alert('Invalid request.'); window.location.replace('lender_list.php');</script>";
    exit;
}

// Handle form submission to update lender details
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);
    $address = trim($_POST['address']);

    // Validate inputs
    if (empty($name) || empty($email) || empty($phone)) {
        $error = "Name, email, and phone are required.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Invalid email format.";
    } elseif (!preg_match("/^[0-9]{10}$/", $phone)) {
        $error = "Invalid phone number. It must be 10 digits.";
    } else {
        // Update lender details in the database
        $updateQuery = $conn->prepare("
            UPDATE tbl_lender 
            SET lender_name = ?, lender_email = ?, lender_phone = ?, lender_address = ? 
            WHERE id = ?
        ");
        $updateQuery->bind_param("ssssi", $name, $email, $phone, $address, $lenderId);

        if ($updateQuery->execute()) {
            echo "<script>alert('Lender details updated successfully.'); window.location.replace('lender_list.php');</script>";
            exit;
        } else {
            $error = "Failed to update lender details.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <title>Edit Lender | LSL System</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="Edit Lender Information" name="description" />
    <meta content="MyraStudio" name="author" />
    <!-- App favicon -->
    <link rel="shortcut icon" href="assets/images/favicon.ico">

    <!-- Bootstrap CSS -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" />
    <!-- Theme CSS -->
    <link href="assets/css/theme.min.css" rel="stylesheet" />
    <!-- Custom CSS -->
    <link href="assets/css/custom.css" rel="stylesheet" />
</head>
<body>
    <!-- Page Wrapper -->
    <div id="layout-wrapper">
        <?php include('header.php'); ?>
        <?php include('sidebar.php'); ?>

        <!-- Main Content -->
        <div class="main-content">
            <div class="page-content">
                <div class="container-fluid">
                    <!-- Page Title -->
                    <div class="row">
                        <div class="col-12">
                            <div class="page-title-box d-flex align-items-center justify-content-between">
                                <h4 class="mb-0">Edit Lender</h4>
                                <div class="page-title-right">
                                    <ol class="breadcrumb m-0">
                                        <li class="breadcrumb-item"><a href="lender_list.php">Lenders</a></li>
                                        <li class="breadcrumb-item active">Edit Lender</li>
                                    </ol>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Page Title -->

                    <!-- Form Section -->
                    <div class="row">
                        <div class="col-lg-8 mx-auto">
                            <div class="card">
                                <div class="card-body">
                                    <h4 class="card-title">Edit Lender Details</h4>
                                    <p class="card-subtitle mb-4">Update the details of the lender.</p>
                                    <?php if (isset($error)) { ?>
                                        <div class="alert alert-danger"><?php echo $error; ?></div>
                                    <?php } ?>
                                    <form method="POST" id="edit-lender-form">
                                        <div class="form-group">
                                            <label for="name">Lender Name</label>
                                            <input type="text" name="name" id="name" class="form-control" 
                                                value="<?php echo htmlspecialchars($lender['lender_name']); ?>" required>
                                        </div>
                                        <div class="form-group">
                                            <label for="email">Email</label>
                                            <input type="email" name="email" id="email" class="form-control" 
                                                value="<?php echo htmlspecialchars($lender['lender_email']); ?>" required>
                                        </div>
                                        <div class="form-group">
                                            <label for="phone">Phone</label>
                                            <input type="text" name="phone" id="phone" class="form-control" 
                                                value="<?php echo htmlspecialchars($lender['lender_phone']); ?>" required>
                                        </div>
                                        <div class="form-group">
                                            <label for="address">Address</label>
                                            <textarea name="address" id="address" class="form-control"><?php echo htmlspecialchars($lender['lender_address']); ?></textarea>
                                        </div>
                                        <div class="text-right">
                                            <button type="submit" class="btn btn-primary">Update</button>
                                            <a href="lender_list.php" class="btn btn-secondary">Cancel</a>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Form Section -->
                </div>
            </div>
            <?php include('footer.php'); ?>
        </div>
        <!-- End Main Content -->
    </div>
    <!-- End Page Wrapper -->

    <!-- Scripts -->
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/theme.js"></script>
</body>
</html>
