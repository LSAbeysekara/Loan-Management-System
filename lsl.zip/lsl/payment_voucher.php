<?php
session_start();
include('./config.php');
$payment_id = filter_input(INPUT_GET, 'id', FILTER_SANITIZE_NUMBER_INT);
if (!$payment_id) {
    die('Invalid payment ID');
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Payment Receipt</title>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        body {
            font-size: 12px;
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 10px;
        }
        .container {
            max-width: 80mm;
            margin: 0 auto;
        }
        .header {
            text-align: center;
            margin-bottom: 10px;
        }
        .details {
            margin-bottom: 10px;
        }
        .amount {
            border-top: 1px solid #000;
            border-bottom: 1px solid #000;
            padding: 5px 0;
            margin: 10px 0;
        }
        .signatures {
            margin-top: 15px;
            font-size: 10px;
            margin-bottom: 20px;
        }
        .signature-line {
            border-top: 1px solid #000;
            width: 100px;
            margin: 5px auto;
        }
        .button-container {
            text-align: center;
            margin-top: 20px;
            padding: 10px;
        }
        .btn {
            padding: 8px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-weight: bold;
            font-size: 14px;
            margin: 0 5px;
            transition: all 0.3s ease;
        }
        .btn-print {
            background-color: #4CAF50;
            color: white;
        }
        .btn-print:hover {
            background-color: #45a049;
        }
        .btn-cancel {
            background-color: #f44336;
            color: white;
        }
        .btn-cancel:hover {
            background-color: #da190b;
        }
        @media print {
            .no-print {
                display: none;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <?php
        try {
            $sql = "SELECT 
                    p.id, p.amount_paid, p.payment_method, p.create_date,
                    l.loan_balance, l.loan_type,
                    c.membership_number, c.name_with_initials
                FROM tbl_payments p
                JOIN tbl_loan l ON p.loan_id = l.id
                JOIN tbl_customer c ON p.customer_id = c.id
                WHERE p.id = ?";
            
            $stmt = $conn->prepare($sql);
            $stmt->bind_param('i', $payment_id);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result && $result->num_rows > 0) {
                $data = $result->fetch_assoc();
                ?>
                <div class="header">
                    <h3>LSL Credit</h3>
                    <h4>Payment Receipt</h4>
                </div>

                <div class="details">
                    <p>No: <?php echo str_pad($payment_id, 6, '0', STR_PAD_LEFT); ?></p>
                    <p>Date: <?php echo date('Y-m-d', strtotime($data['create_date'])); ?></p>
                    <p>Member: <?php echo htmlspecialchars($data['membership_number']); ?></p>
                    <p>Name: <?php echo htmlspecialchars($data['name_with_initials']); ?></p>
                </div>

                <div class="amount">
                    <p><strong>Amount Paid:</strong> Rs. <?php echo number_format($data['amount_paid'], 2); ?></p>
                    <p><strong>Balance:</strong> Rs. <?php echo number_format($data['loan_balance'], 2); ?></p>
                    <p><strong>Payment Method:</strong> <?php echo htmlspecialchars($data['payment_method']); ?></p>
                </div>

                <div class="signatures">
                    <div style="float: left; width: 50%; text-align: center;">
                        <p>Issued By</p>
                        <div class="signature-line"></div>
                    </div>
                    <div style="float: right; width: 50%; text-align: center;">
                        <p>Customer</p>
                        <div class="signature-line"></div>
                    </div>
                    <div style="clear: both;"></div>
                </div>

                <div class="button-container no-print">
                    <button onclick="printAndRedirect()" class="btn btn-print">Print</button>
                    <button onclick="confirmCancel()" class="btn btn-cancel">Cancel</button>
                </div>
                <?php
            } else {
                echo 'Payment record not found.';
            }
        } catch (Exception $e) {
            echo 'Error: ' . htmlspecialchars($e->getMessage());
        }
        ?>
    </div>

    <script>
        function printAndRedirect() {
            window.print();
            // Add a small delay to ensure printing is complete
            setTimeout(function() {
                window.location.href = 'repay.php';
            }, 1000);
        }

        function confirmCancel() {
            Swal.fire({
                title: 'Are you sure?',
                text: "Do you want to go back to the repayment page?",
                icon: 'question',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes',
                cancelButtonText: 'No'
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = 'repay.php';
                }
            });
        }

        // Listen for print completion
        window.onafterprint = function() {
            window.location.href = 'repay.php';
        };
    </script>
</body>
</html>