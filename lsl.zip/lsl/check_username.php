<?php
require('./config.php');

if (isset($_POST['username'])) {
    $username = $_POST['username'];
    $query = "SELECT username FROM tbl_user WHERE username = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('s', $username);
    $stmt->execute();
    $stmt->store_result();
    if ($stmt->num_rows > 0) {
        echo '<span style="color:red;">Username already exists.</span>';
    } else {
        echo '<span style="color:green;">Username available.</span>';
    }
}
?>
