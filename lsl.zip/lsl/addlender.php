<?php session_start(); ?>
<?php require('./config.php'); ?>
<?php
if (!isset($_SESSION['staffname'])) {
    echo "<script> window.location.replace('login.php'); </script>";
} else { ?>
    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="utf-8" />
        <title>Add Lender</title>
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta content="Lender Management System" name="description" />
        <meta content="MyraStudio" name="author" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />

        <!-- App css -->
        <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/icons.min.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/theme.min.css" rel="stylesheet" type="text/css" />

        <!-- SweetAlert2 -->
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
    </head>

    <body>
        <div id="layout-wrapper">
            <?php include('header.php'); ?>
            <?php include('sidebar.php'); ?>

            <div class="main-content">
                <div class="page-content">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box d-flex align-items-center justify-content-between">
                                    <h4 class="mb-0 font-size-18">Add Lender</h4>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-12">
                                <div class="card">
                                    <div class="card-body">
                                        <h4 class="card-title">New Lender</h4>
                                        <p class="card-subtitle mb-4">Fill in the required fields to add a new lender.</p>

                                        <form class="form-horizontal" id="addLenderForm" enctype="multipart/form-data">
                                            <div class="form-group row mb-3">
                                                <label for="lender_name" class="col-3 col-form-label">Lender Name</label>
                                                <div class="col-9">
                                                    <input type="text" class="form-control" id="lender_name" name="lender_name" required>
                                                </div>
                                            </div>

                                            <div class="form-group row mb-3">
                                                <label for="lender_address" class="col-3 col-form-label">Lender Address</label>
                                                <div class="col-9">
                                                    <textarea class="form-control" id="lender_address" name="lender_address" required></textarea>
                                                </div>
                                            </div>

                                            <div class="form-group row mb-3">
                                                <label for="lender_phone" class="col-3 col-form-label">Lender Phone Number</label>
                                                <div class="col-9">
                                                    <input type="text" class="form-control" id="lender_phone" name="lender_phone" required>
                                                </div>
                                            </div>

                                            <div class="form-group row mb-3">
                                                <label for="lender_email" class="col-3 col-form-label">Lender Email</label>
                                                <div class="col-9">
                                                    <input type="email" class="form-control" id="lender_email" name="lender_email">
                                                </div>
                                            </div>

                                            <div class="form-group mb-0 justify-content-end row">
                                                <div class="col-9">
                                                    <button type="submit" class="btn btn-info waves-effect waves-light">Save</button>
                                                </div>
                                            </div>
                                        </form>

                                    </div> <!-- end card-body -->
                                </div> <!-- end card -->
                            </div> <!-- end col -->
                        </div> <!-- end row -->
                    </div> <!-- container-fluid -->
                </div> <!-- End Page-content -->
            </div> <!-- end main content -->
        </div> <!-- END layout-wrapper -->

        <script src="assets/js/jquery.min.js"></script>
        <script src="assets/js/bootstrap.bundle.min.js"></script>
        <script src="assets/js/waves.js"></script>
        <script src="assets/js/simplebar.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
        <script src="assets/js/theme.js"></script>

        <script>
            $(document).ready(function() {
                $("#addLenderForm").on('submit', function(e) {
                    e.preventDefault();

                    var formData = new FormData(this);
                    $.ajax({
                        url: "save_lender.php",
                        method: "POST",
                        data: formData,
                        contentType: false,
                        processData: false,
                        success: function(response) {
                            var result = JSON.parse(response);
                            if (result.status === 'success') {
                                Swal.fire({
                                    title: 'Success!',
                                    text: 'Lender has been added successfully!',
                                    icon: 'success',
                                    confirmButtonText: 'OK'
                                }).then((result) => {
                                    if (result.isConfirmed) {
                                        window.location.href = "lender_list.php";
                                    }
                                });
                            } else {
                                Swal.fire({
                                    title: 'Error!',
                                    text: result.message,
                                    icon: 'error',
                                    confirmButtonText: 'OK'
                                });
                            }
                        }
                    });
                });
            });
        </script>
    </body>
    </html>
<?php } ?>
