<?php session_start(); ?>
<?php require('./config.php'); ?>

<?php if (!isset($_SESSION['staffname'])) {
    echo "<script> window.location.replace('login.php'); </script>";
} else { ?>

    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="utf-8" />
        <title>LSL System</title>
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta content="Premium Multipurpose Admin & Dashboard Template" name="description" />
        <meta content="MyraStudio" name="author" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />

        <!-- App favicon -->
        <link rel="shortcut icon" href="assets/images/favicon.ico">

        <!-- App css -->
        <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/icons.min.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/theme.min.css" rel="stylesheet" type="text/css" />

    </head>

    <body>

        <!-- Begin page -->
        <div id="layout-wrapper">
            <?php include('header.php'); ?>
            <?php include('sidebar.php'); ?>


            <!-- ============================================================== -->
            <!-- Start right Content here -->
            <!-- ============================================================== -->
            <div class="main-content">

                <div class="page-content">
                    <div class="container-fluid">

                        <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box d-flex align-items-center justify-content-between">
                                    <h4 class="mb-0 font-size-18">Income</h4>

                                    <div class="page-title-right">
                                        <ol class="breadcrumb m-0">
                                            <li class="breadcrumb-item"><a href="javascript: void(0);">Income</a></li>
                                            <li class="breadcrumb-item active">Add Income</li>
                                        </ol>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- end page title -->

                        <div class="row">
                            <div class="col-12">
                                <div class="card">
                                    <div class="card-body">

                                        <h4 class="card-title">Add Income</h4>
                                        <p class="card-subtitle mb-4">Add income here with required details.</p>

                                        <h5 class="">Search & View Income</h5>
                                        <form class="form-inline" method="get" action="income_recept.php" target="_blank" role="search">
                                            <input class="form-control mr-sm-2" type="search" placeholder="Enter Income Recept" name="income_id" aria-label="Search" required>
                                            <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
                                        </form>


                                        <hr>
                                        <form id="expenseForm">


                                            <div id="otherFields">
                                                <div class="mb-3">
                                                    <label for="incomeCategory" class="form-label">Income Category</label>
                                                    <select id="incomeCategory" name="incomeCategory" class="form-control col-sm-2">

                                                    </select>
                                                </div>


                                            </div>

                                            <div class="mb-3">
                                                <label for="incomeDescription" class="form-label">Income Description</label>
                                                <input type="text" id="incomeDescription" name="incomeDescription" class="form-control" required>
                                            </div>

                                            <div class="mb-3">
                                                <label for="froms" class="form-label">From</label>
                                                <input type="text" id="froms" name="froms" class="form-control" required>
                                            </div>

                                            <div class="mb-3">
                                                <label for="amount" class="form-label">Amount</label>
                                                <input type="number" id="amount" name="amount" class="form-control" required>
                                            </div>

                                            <div class="mb-3">
                                                <label for="paymentType" class="form-label">Payment Type</label>
                                                <select id="paymentType" name="paymentType" class="form-control" required>

                                                </select>
                                            </div>



                                            <button type="submit" class="btn btn-primary">Submit</button>
                                        </form>
                                    </div> <!-- end card-body-->
                                </div> <!-- end card-->
                            </div> <!-- end col -->
                        </div>
                        <!-- end row-->

                    </div> <!-- container-fluid -->
                </div>
                <!-- End Page-content -->

                <?php include './footer.php'; ?>

            </div>
            <!-- end main content-->

        </div>
        <!-- END layout-wrapper -->

        <!-- Overlay-->
        <div class="menu-overlay"></div>

        <!-- jQuery  -->
        <script src="assets/js/jquery.min.js"></script>
        <script src="assets/js/bootstrap.bundle.min.js"></script>
        <script src="assets/js/metismenu.min.js"></script>
        <script src="assets/js/waves.js"></script>
        <script src="assets/js/simplebar.min.js"></script>

        <!-- Validation custom js-->
        <script src="assets/pages/validation-demo.js"></script>

        <!-- App js -->
        <script src="assets/js/theme.js"></script>

        <!-- Custom script -->
        <script>
            $(document).ready(function() {

                        $.ajax({
                            url: 'get_income_categories.php',
                            type: 'GET',
                            dataType: 'json',
                            success: function(data) {
                                const $incomeCategoryDropdown = $('#incomeCategory');
                                data.forEach(function(incomeCategory) {
                                    $incomeCategoryDropdown.append($('<option>', {
                                        value: incomeCategory.cat_id,
                                        text: incomeCategory.cat_name
                                    }));
                                });
                                $incomeCategoryDropdown.select2();
                            },
                            error: function() {
                                console.error('Error fetching expense categories.');
                            }
                        });


                        $.ajax({
                            url: 'exp_get_payment_types.php',
                            type: 'GET',
                            dataType: 'json',
                            success: function(data) {
                                const $paymentTypeDropdown = $('#paymentType');
                                data.forEach(function(paymentType) {
                                    $paymentTypeDropdown.append($('<option>', {
                                        value: paymentType.Pay_id,
                                        text: paymentType.pay_desc
                                    }));
                                });
                                $paymentTypeDropdown.select2();
                            },
                            error: function() {
                                console.error('Error fetching payment types.');
                            }
                        });


                        $('#expenseForm').submit(function(e) {
                            e.preventDefault();
                            const formData = $(this).serialize();

                            $.ajax({
                                type: 'POST',
                                url: 'process_form2.php',
                                data: formData,
                                dataType: 'json',
                                success: function(response) {
                                    if (response.success) {
                                        const income_id = response.income_id;
                                        Swal.fire({
                                            icon: 'success',
                                            title: 'Success!',
                                            text: 'Record has been saved successfully.',
                                            showCancelButton: true,
                                            showConfirmButton: true,
                                            confirmButtonText: 'Preview',
                                            cancelButtonText: 'Cancel'
                                        }).then((result) => {
                                            if (result.isConfirmed) {
                                                window.location.href = 'income_recept.php?income_id=' + income_id;
                                            }
                                        });
                                    } else {
                                        Swal.fire({
                                            icon: 'error',
                                            title: 'Error!',
                                            text: 'An error occurred. Please try again.'
                                        });
                                        console.error(response.error);
                                    }
                                },
                                error: function(error) {
                                    alert('An error occurred. Please try again.');
                                    console.error(error.responseText);
                                }
                            });
                        });
                    });
        </script>

    </body>

    </html>
<?php } ?>