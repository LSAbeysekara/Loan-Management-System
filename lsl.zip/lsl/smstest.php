<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "ticolk_therush";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
 date_default_timezone_set('Asia/Kolkata');

// BUYSMS.LK API token
$apiToken = "9|DYzoXCITFyGb7hohxGXDJTdD3B1eNe9vR0pNavIW66869718";
$apiUrl = "https://portal.buysms.lk/api/v3/sms/send";
$senderId = "BUYSMSDEMO";

// Query to get messages with status "no"
function formatSriLankanNumber($phoneNumber) {
    // Remove any non-digit characters (if any)
    $phoneNumber = preg_replace('/\D/', '', $phoneNumber);

    // Check if the number starts with '0'
    if (substr($phoneNumber, 0, 1) === '0') {
        // Replace '0' at the beginning with '94'
        return '94' . substr($phoneNumber, 1);
    }
    
    // If the number doesn't start with '0', add '94' as prefix
    if (substr($phoneNumber, 0, 1) !== '9' && strlen($phoneNumber) >= 9) {
        return '94' . $phoneNumber;
    }

    // If the number is already in the correct format (starts with '94')
    return $phoneNumber;
}

// Query to get messages with status "no"
$sql = "SELECT `SMS_ID`, `Message`, `phoneNo`, `ser_Id` FROM `tbl_sms` WHERE `status`='no'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $smsId = $row['SMS_ID'];
        $message = $row['Message'];
        $phoneNo = $row['phoneNo'];
        $serId = $row['ser_Id'];

        // Format the phone number
        $formattedPhoneNo = formatSriLankanNumber($phoneNo);

        // Prepare the data for the API request
        $postData = [
            "recipient" => $formattedPhoneNo,
            "sender_id" => $senderId,
            "type" => "plain",
            "message" => $message
        ];

        // Send SMS using CURL
        $ch = curl_init($apiUrl);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            "Authorization: Bearer $apiToken",
            "Content-Type: application/json",
            "Accept: application/json"
        ]);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($postData));

        $response = curl_exec($ch);
        $responseData = json_decode($response, true);

        if (curl_errno($ch)) {
            echo "CURL Error: " . curl_error($ch);
        } else {
            if ($responseData['status'] === "success") {
                $refNo = $responseData['data']['id'] ?? null; // Store unique refno if provided

                // Update the message status to "yes" and save reference number
                $updateSql = "UPDATE `tbl_sms` SET `status`='Yes', `refno`='$refNo' WHERE `SMS_ID`='$smsId'";
                $conn->query($updateSql);
                
                echo "SMS sent successfully for SMS_ID: $smsId\n";
            } else {
                echo "Error: " . $responseData['message'] . "\n";
            }
        }

        curl_close($ch);
    }
} else {
    echo "No SMS messages with status 'no' found.\n";
}

$conn->close();