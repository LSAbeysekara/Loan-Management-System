<?php
require('./config.php');
session_start();
// Function to generate the membership number
function generateMembershipNumber($conn) {
    // Get the last inserted membership number
    $query = "SELECT membership_number FROM tbl_customer ORDER BY id DESC LIMIT 1";
    $result = $conn->query($query);

    if ($result->num_rows > 0) {
        // Fetch the last membership number and extract the numeric part
        $row = $result->fetch_assoc();
        $last_membership_number = $row['membership_number'];
        $last_number = (int)substr($last_membership_number, 4); // Extract the numeric part after 'LSLC'
        $new_number = $last_number + 1; // Increment by 1
    } else {
        // No previous record, start from 1
        $new_number = 1;
    }

    // Format the new membership number as LSLC followed by a 6-digit number
    return 'LSLC' . str_pad($new_number, 6, '0', STR_PAD_LEFT);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $full_name = $_POST['full_name'];
    $membership_number = generateMembershipNumber($conn); // Generate the membership number
    $name_with_initials = $_POST['name_with_initials'];
    $nic_no = $_POST['nic_no'];
    $postal_address = $_POST['postal_address'];
    $job = $_POST['job_position'];
    $job_address = $_POST['job_address'];
    $fixed_phone = $_POST['fixed_phone'];
    $mobile_phone = $_POST['mobile_phone'];
    $marital_status = $_POST['marital_status'];
    $spouse_name = $_POST['spouse_name'] ?? null;
    $spouse_job = $_POST['spouse_job'] ?? null;
    $spouse_phone = $_POST['spouse_phone'] ?? null;
    $created_by = $_SESSION['staffname'];
    $created_date = date('Y-m-d H:i:s');

    $nic_document = null;  // Default value if no file is uploaded

    // Check if NIC document is uploaded
    if (isset($_FILES['nic_document']) && $_FILES['nic_document']['error'] == 0) {
        $file_tmp = $_FILES['nic_document']['tmp_name'];
        $file_ext = pathinfo($_FILES['nic_document']['name'], PATHINFO_EXTENSION); // Get file extension

        // Create the uploads directory if it doesn't exist
        if (!file_exists('uploads/' . $membership_number)) {
            mkdir('uploads/' . $membership_number, 0777, true);
        }

        // Set the path for the NIC document (inside the customer's folder)
        $nic_document_name = 'nic.' . $file_ext;
        $nic_document_path = 'uploads/' . $membership_number . '/' . $nic_document_name;

        // Move the file to the specific folder
        if (move_uploaded_file($file_tmp, $nic_document_path)) {
            $nic_document = $nic_document_name;  // Save the file name to the database
        }
    }

    // Prepare SQL query
    $stmt = $conn->prepare("
        INSERT INTO tbl_customer 
        (full_name, membership_number, name_with_initials, nic_no, postal_address, job_position, job_address, fixed_phone, mobile_phone, marital_status, spouse_name, spouse_job, spouse_phone, nic_document, created_by, created_date)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ");

    // Bind parameters
    $stmt->bind_param(
        'ssssssssssssssss',
        $full_name, $membership_number, $name_with_initials, $nic_no, $postal_address, $job, $job_address, $fixed_phone,
        $mobile_phone, $marital_status, $spouse_name, $spouse_job, $spouse_phone, $nic_document, $created_by, $created_date
    );

    // Execute the query
    if ($stmt->execute()) {
        echo json_encode(['status' => 'success', 'message' => 'Customer added successfully']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Error saving customer']);
    }

    $stmt->close();
    $conn->close();
}
?>
