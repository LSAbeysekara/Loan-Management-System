<?php
session_start();
require('./config.php');

if (!isset($_SESSION['staffname'])) {
    echo "<script>window.location.replace('login.php');</script>";
    exit;
}

$customer_id = $_GET['id'] ?? 0;

// Get complete customer details
$customer_query = "SELECT * FROM tbl_customer WHERE id = ?";
$stmt = $conn->prepare($customer_query);
$stmt->bind_param("i", $customer_id);
$stmt->execute();
$customer_result = $stmt->get_result();
$customer = $customer_result->fetch_assoc();

// Get all loans for this customer
$loan_query = "SELECT id, loan_type, requested_amount, monthly_interest_rate, repay_duration, 
               loan_balance, last_payment_date, status 
               FROM tbl_loan WHERE customer_id = ?";
$stmt = $conn->prepare($loan_query);
$stmt->bind_param("i", $customer_id);
$stmt->execute();
$result = $stmt->get_result();

// If only one loan exists, redirect to customer_loan_view.php
if ($result->num_rows === 1) {
    $loan = $result->fetch_assoc();
    header("Location: customer_loan_view.php?id=" . $loan['id']);
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Loan Selection | LSL System</title>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/icons.min.css" rel="stylesheet">
    <link href="assets/css/theme.min.css" rel="stylesheet">
</head>

<body>
    <div id="layout-wrapper">
        <?php include('header.php'); ?>
        <?php include('sidebar.php'); ?>

        <div class="main-content">
            <div class="page-content">
                <div class="container-fluid">
                    <!-- Page title -->
                    <div class="row">
                        <div class="col-12">
                            <div class="page-title-box d-flex align-items-center justify-content-between">
                                <div>
                                    <h4 class="mb-2">Loans for <?php echo htmlspecialchars($customer['full_name']); ?></h4>
                                    <!-- <button type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#customerDetailsModal">
                                        <i class="mdi mdi-account-details mr-1"></i> View Customer Details
                                    </button> -->
                                </div>
                                <div class="page-title-right">
                                    <ol class="breadcrumb m-0">
                                        <li class="breadcrumb-item"><a href="customer_list.php">Customers</a></li>
                                        <li class="breadcrumb-item active">Loan Selection</li>
                                    </ol>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Loan cards -->
                    <div class="row">
                        <?php if ($result->num_rows > 0): ?>
                            <?php while ($loan = $result->fetch_assoc()): ?>
                            <div class="col-md-4">
                                <div class="card">
                                    <div class="card-body">
                                        <h5 class="card-title">
                                            <?php echo htmlspecialchars($loan['loan_type']); ?>
                                            <span class="badge badge-<?php echo $loan['status'] === 'active' ? 'success' : 'danger'; ?> float-right">
                                                <?php echo ucfirst(htmlspecialchars($loan['status'])); ?>
                                            </span>
                                        </h5>
                                        <div class="mt-4">
                                            <p class="mb-2">Loan Amount: <strong>Rs. <?php echo number_format($loan['requested_amount'], 2); ?></strong></p>
                                            <p class="mb-2">Interest Rate: <strong><?php echo $loan['monthly_interest_rate']; ?>%</strong></p>
                                            <p class="mb-2">Duration: <strong><?php echo $loan['repay_duration']; ?> months</strong></p>
                                            <p class="mb-2">Balance: <strong>Rs. <?php echo number_format($loan['loan_balance'], 2); ?></strong></p>
                                            <?php if ($loan['last_payment_date']): ?>
                                            <p class="mb-2">Last Payment: <strong><?php echo date('d-m-Y', strtotime($loan['last_payment_date'])); ?></strong></p>
                                            <?php endif; ?>
                                        </div>
                                        <div class="mt-4">
                                            <a href="customer_loan_view.php?id=<?php echo $loan['id']; ?>" 
                                            class="btn btn-primary btn-block">View Details</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <div class="col-12">
                                <div class="alert alert-info text-center">
                                    <h4><?php echo htmlspecialchars($customer['full_name']); ?> hasn't got any loans yet.</h4>
                                    <p>Back to customers?</p>
                                    <a href="customer_list.php" class="btn btn-secondary">Go to Customers</a>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <?php include 'footer.php'; ?>
        </div>
    </div>

    <!-- Customer Details Modal -->
    <div class="modal fade" id="customerDetailsModal" tabindex="-1" role="dialog" aria-labelledby="customerDetailsModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="customerDetailsModalLabel">Customer Details</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-6">
                            <h6 class="font-weight-bold">Personal Information</h6>
                            <table class="table table-borderless">
                                <tr>
                                    <td class="font-weight-bold">Full Name:</td>
                                    <td><?php echo htmlspecialchars($customer['full_name']); ?></td>
                                </tr>
                                <tr>
                                    <td class="font-weight-bold">Name with Initials:</td>
                                    <td><?php echo htmlspecialchars($customer['name_with_initials']); ?></td>
                                </tr>
                                <tr>
                                    <td class="font-weight-bold">Sinhala Name:</td>
                                    <td><?php echo htmlspecialchars($customer['namesinhala']); ?></td>
                                </tr>
                                <tr>
                                    <td class="font-weight-bold">Membership No:</td>
                                    <td><?php echo htmlspecialchars($customer['membership_number']); ?></td>
                                </tr>
                                <tr>
                                    <td class="font-weight-bold">NIC Number:</td>
                                    <td><?php echo htmlspecialchars($customer['nic_no']); ?></td>
                                </tr>
                                <tr>
                                    <td class="font-weight-bold">Gender:</td>
                                    <td><?php echo htmlspecialchars($customer['gender']); ?></td>
                                </tr>
                                <tr>
                                    <td class="font-weight-bold">Marital Status:</td>
                                    <td><?php echo htmlspecialchars($customer['marital_status']); ?></td>
                                </tr>
                            </table>
                        </div>
                        <div class="col-md-6">
                            <h6 class="font-weight-bold">Contact Information</h6>
                            <table class="table table-borderless">
                                <tr>
                                    <td class="font-weight-bold">Address:</td>
                                    <td><?php echo htmlspecialchars($customer['postal_address']); ?></td>
                                </tr>
                                <tr>
                                    <td class="font-weight-bold">Mobile Phone:</td>
                                    <td><?php echo htmlspecialchars($customer['mobile_phone']); ?></td>
                                </tr>
                                <tr>
                                    <td class="font-weight-bold">Fixed Phone:</td>
                                    <td><?php echo htmlspecialchars($customer['fixed_phone'] ?: 'N/A'); ?></td>
                                </tr>
                            </table>

                            <h6 class="font-weight-bold mt-4">Employment Information</h6>
                            <table class="table table-borderless">
                                <tr>
                                    <td class="font-weight-bold">Job Position:</td>
                                    <td><?php echo htmlspecialchars($customer['job_position'] ?: 'N/A'); ?></td>
                                </tr>
                                <tr>
                                    <td class="font-weight-bold">Job Address:</td>
                                    <td><?php echo htmlspecialchars($customer['job_address'] ?: 'N/A'); ?></td>
                                </tr>
                            </table>
                        </div>
                    </div>

                    <?php if ($customer['marital_status'] === 'Married'): ?>
                    <div class="row mt-3">
                        <div class="col-12">
                            <h6 class="font-weight-bold">Spouse Information</h6>
                            <table class="table table-borderless">
                                <tr>
                                    <td class="font-weight-bold">Spouse Name:</td>
                                    <td><?php echo htmlspecialchars($customer['spouse_name'] ?: 'N/A'); ?></td>
                                </tr>
                                <tr>
                                    <td class="font-weight-bold">Spouse Job:</td>
                                    <td><?php echo htmlspecialchars($customer['spouse_job'] ?: 'N/A'); ?></td>
                                </tr>
                                <tr>
                                    <td class="font-weight-bold">Spouse Phone:</td>
                                    <td><?php echo htmlspecialchars($customer['spouse_phone'] ?: 'N/A'); ?></td>
                                </tr>
                            </table>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Scripts -->
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/metismenu.min.js"></script>
    <script src="assets/js/waves.js"></script>
    <script src="assets/js/simplebar.min.js"></script>
    <script src="assets/js/theme.js"></script>
</body>
</html>