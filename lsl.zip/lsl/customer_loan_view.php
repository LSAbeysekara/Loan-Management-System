<?php
session_start();
require('./config.php');

if (!isset($_SESSION['staffname'])) {
    echo "<script>window.location.replace('login.php');</script>";
    exit;
}

$loan_id = $_GET['id'] ?? 0;

// Get loan details with customer information including spouse information
$query = "SELECT l.*, c.full_name, c.membership_number, c.nic_no, c.mobile_phone, 
          c.name_with_initials, c.namesinhala, c.postal_address, c.gender, c.marital_status,
          c.spouse_name, c.spouse_job, c.spouse_phone
          FROM tbl_loan l
          JOIN tbl_customer c ON l.customer_id = c.id
          WHERE l.id = ?";

$stmt = $conn->prepare($query);
$stmt->bind_param("i", $loan_id);
$stmt->execute();
$result = $stmt->get_result();
$loan = $result->fetch_assoc();

if (!$loan) {
    header("Location: customer_list.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Loan Details | LSL System</title>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/icons.min.css" rel="stylesheet">
    <link href="assets/css/theme.min.css" rel="stylesheet">
</head>

<body>
    <div id="layout-wrapper">
        <?php include('header.php'); ?>
        <?php include('sidebar.php'); ?>

        <div class="main-content">
            <div class="page-content">
                <div class="container-fluid">
                    <!-- Page title -->
                    <div class="row">
                        <div class="col-12">
                            <div class="page-title-box d-flex align-items-center justify-content-between">
                                <h4 class="mb-0">Loan Details</h4>
                                <div class="page-title-right">
                                    <ol class="breadcrumb m-0">
                                        <li class="breadcrumb-item"><a href="customer_list.php">Customers</a></li>
                                        <li class="breadcrumb-item active">Loan Details</li>
                                    </ol>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Customer Information -->
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="card">
                                <div class="card-body">
                                    <h4 class="card-title d-flex justify-content-between align-items-center">
                                        Customer Information
                                        <button type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#customerDetailsModal">
                                            <i class="mdi mdi-account-details mr-1"></i> View Customer Details
                                        </button>
                                    </h4>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <p><strong>Name:</strong> <?php echo htmlspecialchars($loan['full_name']); ?></p>
                                            <p><strong>Membership Number:</strong> <?php echo htmlspecialchars($loan['membership_number']); ?></p>
                                        </div>
                                        <div class="col-md-6">
                                            <p><strong>NIC:</strong> <?php echo htmlspecialchars($loan['nic_no']); ?></p>
                                            <p><strong>Mobile:</strong> <?php echo htmlspecialchars($loan['mobile_phone']); ?></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Loan Details -->
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="card">
                                <div class="card-body">
                                    <h4 class="card-title">Loan Information</h4>
                                    <div class="table-responsive">
                                        <table class="table table-striped mb-0">
                                            <tbody>
                                                <tr>
                                                    <th>Loan Type</th>
                                                    <td><?php echo htmlspecialchars($loan['loan_type']); ?></td>
                                                </tr>
                                                <tr>
                                                    <th>Amount</th>
                                                    <td>Rs. <?php echo number_format($loan['requested_amount'], 2); ?></td>
                                                </tr>
                                                <tr>
                                                    <th>Interest Rate</th>
                                                    <td><?php echo $loan['monthly_interest_rate']; ?>% monthly</td>
                                                </tr>
                                                <tr>
                                                    <th>Duration</th>
                                                    <td><?php echo $loan['repay_duration']; ?> months</td>
                                                </tr>
                                                <tr>
                                                    <th>Monthly Payment</th>
                                                    <td>Rs. <?php echo number_format($loan['agreed_monthly_payment'], 2); ?></td>
                                                </tr>
                                                <tr>
                                                    <th>Purpose</th>
                                                    <td><?php echo htmlspecialchars($loan['purpose']); ?></td>
                                                </tr>
                                                <tr>
                                                    <th>Status</th>
                                                    <td><span class="badge badge-<?php echo $loan['status'] === 'active' ? 'success' : 'danger'; ?>">
                                                        <?php echo ucfirst(htmlspecialchars($loan['status'])); ?>
                                                    </span></td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-6">
                            <div class="card">
                                <div class="card-body">
                                    <h4 class="card-title">Payment Information</h4>
                                    <div class="table-responsive">
                                        <table class="table table-striped mb-0">
                                            <tbody>
                                                <tr>
                                                    <th>Current Balance</th>
                                                    <td>Rs. <?php echo number_format($loan['loan_balance'], 2); ?></td>
                                                </tr>
                                                <tr>
                                                    <th>Last Payment Date</th>
                                                    <td><?php echo $loan['last_payment_date'] ? date('d-m-Y', strtotime($loan['last_payment_date'])) : 'N/A'; ?></td>
                                                </tr>
                                                <tr>
                                                    <th>Last Installment Amount</th>
                                                    <td>Rs. <?php echo number_format($loan['last_installment_amount'], 2); ?></td>
                                                </tr>
                                                <tr>
                                                    <th>Last Installment Date</th>
                                                    <td><?php echo $loan['last_installment_date'] ? date('d-m-Y', strtotime($loan['last_installment_date'])) : 'N/A'; ?></td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                    <div class="mt-3">
                                        <a href="loan_history_view.php?loan_id=<?php echo $loan_id; ?>" 
                                           class="btn btn-primary">
                                            <i class="mdi mdi-history mr-1"></i> View Payment History
                                        </a>
                                    </div>
                                </div>
                            </div>

                            <?php if ($loan['guarantee_type']): ?>
                            <div class="card">
                                <div class="card-body">
                                    <h4 class="card-title">Guarantee Information</h4>
                                    <div class="table-responsive">
                                        <table class="table table-striped mb-0">
                                            <tbody>
                                                <tr>
                                                    <th>Guarantee Type</th>
                                                    <td><?php echo htmlspecialchars($loan['guarantee_type']); ?></td>
                                                </tr>
                                                <?php if ($loan['guarantee_type'] === 'Land'): ?>
                                                <tr>
                                                    <th>Land Address</th>
                                                    <td><?php echo htmlspecialchars($loan['land_address']); ?></td>
                                                </tr>
                                                <tr>
                                                    <th>Land Size</th>
                                                    <td><?php echo htmlspecialchars($loan['land_size']); ?></td>
                                                </tr>
                                                <tr>
                                                    <th>Empty Land</th>
                                                    <td><?php echo htmlspecialchars($loan['land_empty']); ?></td>
                                                </tr>
                                                <?php endif; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
            <?php include 'footer.php'; ?>
        </div>
    </div>

    <!-- Customer Details Modal -->
    <div class="modal fade" id="customerDetailsModal" tabindex="-1" role="dialog" aria-labelledby="customerDetailsModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="customerDetailsModalLabel">Customer Details</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true ">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-6">
                            <h6 class="font-weight-bold">Personal Information</h6>
                            <table class="table table-borderless">
                                <tr>
                                    <td class="font-weight-bold">Full Name:</td>
                                    <td><?php echo htmlspecialchars($loan['full_name']); ?></td>
                                </tr>
                                <tr>
                                    <td class="font-weight-bold">Name with Initials:</td>
                                    <td><?php echo htmlspecialchars($loan['name_with_initials']); ?></td>
                                </tr>
                                <tr>
                                    <td class="font-weight-bold">Sinhala Name:</td>
                                    <td><?php echo htmlspecialchars($loan['namesinhala']); ?></td>
                                </tr>
                                <tr>
                                    <td class="font-weight-bold">Membership No:</td>
                                    <td><?php echo htmlspecialchars($loan['membership_number']); ?></td>
                                </tr>
                                <tr>
                                    <td class="font-weight-bold">NIC Number:</td>
                                    <td><?php echo htmlspecialchars($loan['nic_no']); ?></td>
                                </tr>
                                <tr>
                                    <td class="font-weight-bold">Gender:</td>
                                    <td><?php echo htmlspecialchars($loan['gender']); ?></td>
                                </tr>
                                <tr>
                                    <td class="font-weight-bold">Marital Status:</td>
                                    <td><?php echo htmlspecialchars($loan['marital_status']); ?></td>
                                </tr>
                            </table>
                        </div>
                        <div class="col-md-6">
                            <h6 class="font-weight-bold">Contact Information</h6>
                            <table class="table table-borderless">
                                <tr>
                                    <td class="font-weight-bold">Address:</td>
                                    <td><?php echo htmlspecialchars($loan['postal_address']); ?></td>
                                </tr>
                                <tr>
                                    <td class="font-weight-bold">Mobile Phone:</td>
                                    <td><?php echo htmlspecialchars($loan['mobile_phone']); ?></td>
                                </tr>
                            </table>
                        </div>
                    </div>
                    <?php if ($loan['marital_status'] === 'Married'): ?>
                    <div class="row mt-3">
                        <div class="col-12">
                            <h6 class="font-weight-bold">Spouse Information</h6>
                            <table class="table table-borderless">
                                <tr>
                                    <td class="font-weight-bold">Spouse Name:</td>
                                    <td><?php echo htmlspecialchars($loan['spouse_name'] ?: 'N/A'); ?></td>
                                </tr>
                                <tr>
                                    <td class="font-weight-bold">Spouse Job:</td>
                                    <td><?php echo htmlspecialchars($loan['spouse_job'] ?: 'N/A'); ?></td>
                                </tr>
                                <tr>
                                    <td class="font-weight-bold">Spouse Phone:</td>
                                    <td><?php echo htmlspecialchars($loan['spouse_phone'] ?: 'N/A'); ?></td>
                                </tr>
                            </table>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Scripts -->
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/metismenu.min.js"></script>
    <script src="assets/js/waves.js"></script>
    <script src="assets/js/simplebar.min.js"></script>
    <script src="assets/js/theme.js"></script>
</body>
</html>