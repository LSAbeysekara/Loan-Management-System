<?php include('./config.php') ?>
<?php if(!isset($_REQUEST['id'])){
    

echo "<script> window.location.replace('index.php'); </script>"; }else{

    $delete="DELETE FROM `tbl_accounts_catogery` where acc_id=".$_REQUEST['id']."";
    
    if (mysqli_query($conn,$delete)){
        //echo "Registration is successful..!";
        header("location: accountcatogeris.php");
      }
      mysqli_close($conn);
  }
  ?>

 