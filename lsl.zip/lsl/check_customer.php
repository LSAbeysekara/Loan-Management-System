<?php
require('./config.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Check if NIC is being submitted
    if (isset($_POST['nic_no'])) {
        $nic_no = $_POST['nic_no'];

        // Check if NIC exists
        $query_nic = $conn->prepare("SELECT id, full_name, membership_number FROM tbl_customer WHERE nic_no = ?");
        $query_nic->bind_param('s', $nic_no);
        $query_nic->execute();
        $query_nic->store_result(); // Store result to check number of rows

        if ($query_nic->num_rows > 0) {
            $query_nic->bind_result($id, $full_name, $membership_number);
            $query_nic->fetch();
            echo json_encode([
                'status' => 'error',
                'message' => 'NIC already exists for ' . $full_name . ' (Membership No: ' . $membership_number . ')'
            ]);
            exit;
        }
    }

    // Check if mobile phone is being submitted
    if (isset($_POST['mobile_phone'])) {
        $mobile_phone = $_POST['mobile_phone'];

        // Check if Phone exists
        $query_phone = $conn->prepare("SELECT id, full_name, membership_number FROM tbl_customer WHERE mobile_phone = ?");
        $query_phone->bind_param('s', $mobile_phone);
        $query_phone->execute();
        $query_phone->store_result();

        if ($query_phone->num_rows > 0) {
            $query_phone->bind_result($id, $full_name, $membership_number);
            $query_phone->fetch();
            echo json_encode([
                'status' => 'error',
                'message' => 'Phone number already exists for ' . $full_name . ' (Membership No: ' . $membership_number . ')'
            ]);
            exit;
        }
    }

    // If no duplicates found, return an empty response (no content)
    echo json_encode([]);
}
?>
