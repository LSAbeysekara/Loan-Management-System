<?php
session_start();
require('./config.php');

if (!isset($_SESSION['staffname'])) {
    echo "<script>window.location.replace('login.php');</script>";
} else {
    // Check if customer ID is provided
    if (isset($_GET['id'])) {
        $customerId = $_GET['id'];
        // Fetch customer details
        $query = "SELECT * FROM tbl_customer WHERE id = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("i", $customerId);
        $stmt->execute();
        $result = $stmt->get_result();

        // Check if the customer exists
        if ($result->num_rows == 1) {
            $customer = $result->fetch_assoc();
        } else {
            echo "<script>window.location.replace('customer_list.php');</script>";
        }
    } else {
        echo "<script>window.location.replace('customer_list.php');</script>";
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Sanitize and capture form data
    $fullName = isset($_POST['full_name']) ? $_POST['full_name'] : $customer['full_name'];
    $membershipNumber = isset($_POST['membership_number']) ? $_POST['membership_number'] : $customer['membership_number'];
    $nameWithInitials = isset($_POST['name_with_initials']) ? $_POST['name_with_initials'] : $customer['name_with_initials'];
    $nicNo = isset($_POST['nic_no']) ? $_POST['nic_no'] : $customer['nic_no'];
    $postalAddress = isset($_POST['postal_address']) ? $_POST['postal_address'] : $customer['postal_address'];
    $jobPosition = isset($_POST['job_position']) ? $_POST['job_position'] : $customer['job_position'];
    $jobAddress = isset($_POST['job_address']) ? $_POST['job_address'] : $customer['job_address'];
    $fixedPhone = isset($_POST['fixed_phone']) ? $_POST['fixed_phone'] : $customer['fixed_phone'];
    $mobilePhone = isset($_POST['mobile_phone']) ? $_POST['mobile_phone'] : $customer['mobile_phone'];
    $maritalStatus = isset($_POST['marital_status']) ? $_POST['marital_status'] : $customer['marital_status'];
    $spouseName = isset($_POST['spouse_name']) ? $_POST['spouse_name'] : $customer['spouse_name'];
    $spouseJob = isset($_POST['spouse_job']) ? $_POST['spouse_job'] : $customer['spouse_job'];
    $spousePhone = isset($_POST['spouse_phone']) ? $_POST['spouse_phone'] : $customer['spouse_phone'];
    $modifiedBy = $_SESSION['staffname'];
    $modifyDate = date('Y-m-d H:i:s');

    // Update customer details in the database
    $updateQuery = "UPDATE tbl_customer SET 
        full_name = ?, 
        name_with_initials = ?, 
        nic_no = ?, 
        postal_address = ?, 
        job_position = ?, 
        job_address = ?, 
        fixed_phone = ?, 
        mobile_phone = ?, 
        marital_status = ?, 
        spouse_name = ?, 
        spouse_job = ?, 
        spouse_phone = ?, 
        modified_by = ?, 
        modified_date = ? 
        WHERE id = ?";

    $stmt = $conn->prepare($updateQuery);
    $stmt->bind_param("ssssssssssssssi", 
        $fullName, $nameWithInitials, $nicNo, $postalAddress, 
        $jobPosition, $jobAddress, $fixedPhone, $mobilePhone, 
        $maritalStatus, $spouseName, $spouseJob, $spousePhone, 
        $modifiedBy, $modifyDate, $customerId
    );

    if ($stmt->execute()) {
        echo "<script>
            Swal.fire({
                icon: 'success',
                title: 'Customer updated successfully!',
                showConfirmButton: false,
                timer: 1500
            }).then(() => window.location.href = 'customer_list.php');
        </script>";
    } else {
        echo "<script>
            Swal.fire({
                icon: 'error',
                title: 'Error updating customer!',
                text: 'Please try again.',
            });
        </script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <title>Edit Customer | LSL System</title>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta content="Admin & Dashboard Template" name="description" />
    <meta content="MyraStudio" name="author" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />

    <!-- App favicon -->
    <link rel="shortcut icon" href="assets/images/favicon.ico">
    
    <!-- App css -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <link href="assets/css/icons.min.css" rel="stylesheet" type="text/css" />
    <link href="assets/css/theme.min.css" rel="stylesheet" type="text/css" />

    <!-- SweetAlert2 -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
</head>

<body>
    <div id="layout-wrapper">
        <?php include('header.php'); ?>
        <?php include('sidebar.php'); ?>

        <div class="main-content">
            <div class="page-content">
                <div class="container-fluid">

                    <!-- start page title -->
                    <div class="row">
                        <div class="col-12">
                            <div class="page-title-box d-flex align-items-center justify-content-between">
                                <h4 class="mb-0 font-size-18">Edit Customer</h4>
                                <div class="page-title-right">
                                    <ol class="breadcrumb m-0">
                                        <li class="breadcrumb-item"><a href="javascript: void(0);">Customers</a></li>
                                        <li class="breadcrumb-item active">Edit Customer</li>
                                    </ol>
                                </div>
                            </div>
                        </div>
                    </div>     
                    <!-- end page title -->

                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-body">
                                    <h4 class="card-title">Edit Customer</h4>

                                    <form method="POST" class="form-horizontal">
                                        <div class="form-group row mb-3">
                                            <label for="full_name" class="col-3 col-form-label">Full Name</label>
                                            <div class="col-9">
                                                <input type="text" class="form-control" id="full_name" name="full_name" value="<?= $customer['full_name'] ?>" required>
                                            </div>
                                        </div>

                                        <div class="form-group row mb-3">
                                            <label for="membership_number" class="col-3 col-form-label">Membership Number</label>
                                            <div class="col-9">
                                                <input type="text" class="form-control" id="membership_number" name="membership_number" value="<?= $customer['membership_number'] ?>" readonly>
                                            </div>
                                        </div>

                                        <div class="form-group row mb-3">
                                            <label for="nic_no" class="col-3 col-form-label">NIC No</label>
                                            <div class="col-9">
                                                <input type="text" class="form-control" id="nic_no" name="nic_no" value="<?= $customer['nic_no'] ?>" required>
                                            </div>
                                        </div>

                                        <div class="form-group row mb-3">
                                            <label for="mobile_phone" class="col-3 col-form-label">Mobile Phone</label>
                                            <div class="col-9">
                                                <input type="text" class="form-control" id="mobile_phone" name="mobile_phone" value="<?= $customer['mobile_phone'] ?>" required>
                                            </div>
                                        </div>

                                        <div class="form-group row mb-3">
                                            <label for="marital_status" class="col-3 col-form-label">Marital Status</label>
                                            <div class="col-9">
                                                <select name="marital_status" id="marital_status" class="form-control">
                                                    <option value="single" <?= ($customer['marital_status'] == 'Single') ? 'selected' : '' ?>>Single</option>
                                                    <option value="married" <?= ($customer['marital_status'] == 'Married') ? 'selected' : '' ?>>Married</option>
                                                </select>
                                            </div>
                                        </div>

<?php if($customer['marital_status'] == 'Married'){ ?>
                                        <div class="form-group row mb-3">
                                            <label for="spouse_name" class="col-3 col-form-label">Spouse Name</label>
                                            <div class="col-9">
                                                <input type="text" class="form-control" id="spouse_name" name="spouse_name" value="<?= $customer['spouse_name'] ?>">
                                            </div>
                                        </div>

                                        <div class="form-group row mb-3">
                                            <label for="spouse_job" class="col-3 col-form-label">Spouse Job</label>
                                            <div class="col-9">
                                                <input type="text" class="form-control" id="spouse_job" name="spouse_job" value="<?= $customer['spouse_job'] ?>">
                                            </div>
                                        </div>

                                        <div class="form-group row mb-3">
                                            <label for="spouse_phone" class="col-3 col-form-label">Spouse Phone</label>
                                            <div class="col-9">
                                                <input type="text" class="form-control" id="spouse_phone" name="spouse_phone" value="<?= $customer['spouse_phone'] ?>">
                                            </div>
                                        </div>
<?php } ?>

                                        <div class="form-group row mb-3">
                                            <div class="col-9 offset-3">
                                                <button type="submit" class="btn btn-primary">Update Customer</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>

        <?php include('footer.php'); ?>

    </div>

    <!-- JS Libraries -->
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <!-- SweetAlert2 -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</body>
</html>
