<?php session_start(); ?>
<?php require('./config.php'); ?>

<?php
if (!isset($_SESSION['staffname'])) {
    echo "<script> window.location.replace('login.php'); </script>";
} else {
    $staffid = $_GET['id'];

    // Fetch staff details
    $query = "SELECT id, name, username, email, user_type, phone FROM tbl_user WHERE username = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('s', $staffid);
    $stmt->execute();
    $stmt->bind_result($id, $name, $usernames, $email, $user_type, $phone);
    $stmt->fetch();
    $stmt->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <title>Edit Staff</title>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta content="Premium Multipurpose Admin & Dashboard Template" name="description" />
    <meta content="MyraStudio" name="author" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />

    <!-- App favicon -->
    <link rel="shortcut icon" href="assets/images/favicon.ico">

    <!-- App css -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <link href="assets/css/icons.min.css" rel="stylesheet" type="text/css" />
    <link href="assets/css/theme.min.css" rel="stylesheet" type="text/css" />

    <!-- SweetAlert2 -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
</head>

<body>

    <div id="layout-wrapper">
        <?php include('header.php'); ?>
        <?php include('sidebar.php'); ?>

        <div class="main-content">
            <div class="page-content">
                <div class="container-fluid">

                    <div class="row">
                        <div class="col-12">
                            <div class="page-title-box d-flex align-items-center justify-content-between">
                                <h4 class="mb-0 font-size-18">Edit Staff</h4>

                                <div class="page-title-right">
                                    <ol class="breadcrumb m-0">
                                        <li class="breadcrumb-item"><a href="javascript: void(0);">Staff</a></li>
                                        <li class="breadcrumb-item active">Edit Staff</li>
                                    </ol>
                                </div>
                            </div>
                        </div>
                    </div>     

                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-body">
                                    <h4 class="card-title">Edit Staff Details</h4>
                                    <p class="card-subtitle mb-4">Edit staff information below.</p>

                                    <form class="form-horizontal" id="editStaffForm" method="POST">
                                        <input type="hidden" name="staffid" value="<?php echo $id; ?>">
                                        
                                        <div class="form-group row mb-3">
                                            <label for="fname" class="col-3 col-form-label">Name:</label>
                                            <div class="col-9">
                                                <input type="text" class="form-control" id="fname" name="fname" value="<?php echo $name; ?>" required>
                                            </div>
                                        </div>

                                        <div class="form-group row mb-3">
                                            <label for="username" class="col-3 col-form-label">Username</label>
                                            <div class="col-9">
                                                <input type="text" class="form-control" id="username" name="username" value="<?php echo $usernames; ?>" required>
                                                <span id="usernamestatus"></span>
                                            </div>
                                        </div>

                                        <div class="form-group row mb-3">
                                            <label for="email" class="col-3 col-form-label">Email</label>
                                            <div class="col-9">
                                                <input type="email" class="form-control" id="email" name="email" value="<?php echo $email; ?>" required>
                                            </div>
                                        </div>

                                        <div class="form-group row mb-3">
                                            <label for="usertype" class="col-3 col-form-label">User Type</label>
                                            <div class="col-9">
                                                <select name="usertype" id="usertype" class="form-control" required> 
                                                    <option value="admin" <?php if ($user_type == 'admin') echo 'selected'; ?>>Admin</option>
                                                    <option value="Staff" <?php if ($user_type == 'Staff') echo 'selected'; ?>>Staff</option>
                                                    <option value="Manager" <?php if ($user_type == 'Manager') echo 'selected'; ?>>Manager</option>
                                                </select> 
                                            </div>
                                        </div>

                                        <div class="form-group row mb-3">
                                            <label for="phone" class="col-3 col-form-label">Phone</label>
                                            <div class="col-9">
                                                <input type="number" class="form-control" id="phone" name="phone" value="<?php echo $phone; ?>" required>
                                            </div>
                                        </div>

                                        <div class="form-group mb-0 justify-content-end row">
                                            <div class="col-9">
                                                <button type="submit" class="btn btn-info waves-effect waves-light">Update</button>
                                            </div>
                                        </div>
                                    </form>

                                </div> <!-- end card-body-->
                            </div> <!-- end card-->
                        </div> <!-- end col -->
                    </div> <!-- end row-->

                </div> <!-- container-fluid -->
            </div> <!-- End Page-content -->

            <footer class="footer">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-sm-6">
                            2020 © Xeloro.
                        </div>
                        <div class="col-sm-6">
                            <div class="text-sm-right d-none d-sm-block">
                                Design & Develop by Myra
                            </div>
                        </div>
                    </div>
                </div>
            </footer>

        </div>
        <!-- end main content-->

    </div>
    <!-- END layout-wrapper -->

    <!-- Overlay-->
    <div class="menu-overlay"></div>

    <!-- jQuery  -->
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/metismenu.min.js"></script>
    <script src="assets/js/waves.js"></script>
    <script src="assets/js/simplebar.min.js"></script>

    <!-- SweetAlert2 -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <!-- Custom script -->
    <script>
        // Submit form via AJAX
        $('#editStaffForm').on('submit', function(e) {
            e.preventDefault(); // Prevent normal form submission
            var formData = $(this).serialize(); // Serialize form data

            $.ajax({
                url: 'update_staff.php', // PHP script to update staff details
                method: 'POST',
                data: formData,
                success: function(response) {
                    Swal.fire({
                        icon: 'success',
                        title: 'Success!',
                        text: response,
                        confirmButtonText: 'OK'
                    }).then((result) => {
                        if (result.isConfirmed) {
                            window.location.href = 'staff_list.php'; // Redirect after success
                        }
                    });
                },
                error: function() {
                    Swal.fire({
                        icon: 'error',
                        title: 'Error!',
                        text: 'There was an error updating the staff details. Please try again.',
                        confirmButtonText: 'OK'
                    });
                }
            });
        });
    </script>

</body>

</html>
<?php } ?>
