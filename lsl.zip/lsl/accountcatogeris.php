<?php session_start(); ?>
<?php require('./config.php'); ?>

<?php if (!isset($_SESSION['staffname'])) {
    echo "<script> window.location.replace('login.php'); </script>";
} else { ?>

    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="utf-8" />
        <title>LSL System</title>
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta content="Premium Multipurpose Admin & Dashboard Template" name="description" />
        <meta content="MyraStudio" name="author" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />

        <!-- App favicon -->
        <link rel="shortcut icon" href="assets/images/favicon.ico">

        <!-- App css -->
        <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/icons.min.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/theme.min.css" rel="stylesheet" type="text/css" />
        <link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css">
        <link href="https://cdn.jsdelivr.net/npm/sweetalert2@11.7.12/dist/sweetalert2.min.css" rel="stylesheet">
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.7.12/dist/sweetalert2.all.min.js"></script>

    </head>

    <body>

        <!-- Begin page -->
        <div id="layout-wrapper">
            <?php include('header.php'); ?>
            <?php include('sidebar.php'); ?>


            <!-- ============================================================== -->
            <!-- Start right Content here -->
            <!-- ============================================================== -->
            <div class="main-content">

                <div class="page-content">
                    <div class="container-fluid">

                        <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box d-flex align-items-center justify-content-between">
                                    <h4 class="mb-0 font-size-18">Accounts Catogeries</h4>

                                    <div class="page-title-right">
                                        <ol class="breadcrumb m-0">
                                            <li class="breadcrumb-item"><a href="javascript: void(0);">Accounts Catogeries</a></li>
                                            <li class="breadcrumb-item active">Add Accounts Catogeries</li>
                                        </ol>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- end page title -->

                        <div class="row">
                            <div class="col-12">
                                <div class="card">
                                    <div class="card-body">

                                        <h4 class="card-title">Add Accounts Catogeries</h4>
                                        <p class="card-subtitle mb-4">Add accounts catogeries here with required details.</p>

                                        <form class="ml-3 mr-3" method="post" action="#" enctype="multipart/form-data">
                                            <h5>Add Accounts Catogeries</h5>
                                            <div class="form-group row">
                                                <label for="fname" class="col-sm-2  col-form-label"> Acc. Catogery Code: </label>
                                                <div class="col-sm-10">
                                                    <input type="text" class="form-control" id="ccode" name="ccode" style="width: 300px; " disabled>
                                                </div>
                                            </div>

                                            <div class="form-group row">
                                                <label for="account_type" class="col-sm-2 col-form-label">Account Type:</label>
                                                <div class="col-sm-10">
                                                    <select class="form-control" id="account_type" name="account_type" style="width: 300px;" required>
                                                        <option value="income">Income </option>
                                                        <option value="expenses">Expenses </option>

                                                    </select>
                                                </div>
                                            </div>

                                            <div class="form-group row">
                                                <label for="inputcatname" class="col-sm-2  col-form-label">Acc. Category Name: </label>
                                                <div class="col-sm-10">
                                                    <input type="text" class="form-control" id="catname" name="catname" style="width: 500px;">
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <div class="col-sm-10">
                                                    <button type="submit" name="save" class="btn btn-primary">Save</button>
                                                </div>
                                            </div>
                                        </form>

                                    </div> <!-- end card-body-->
                                </div> <!-- end card-->
                            </div> <!-- end col -->
                        </div>
                        <!-- end row-->
                        <div class="row">
                            <div class="col-12">
                                <div class="card">
                                    <div class="card-body"></div>
                                    <h5 class="" style="padding-left: 1%;">List of Accounts Catogeries</h5>
                                    <!-- <div class="col-lg-3">
                                        <input type="text" class="form-control float-end" id="search_box" placeholder="Enter a search query" width="30%">
                                        <br>
                                    </div> -->

                                    <div class="ml-3 mr-5">
                                        <div id="table_container">
                                            <table class="table" id="customer_table">
                                                <thead class="thead-dark">
                                                    <tr>
                                                        <th scope="col">#</th>
                                                        <th scope="col">Accounts Cat. Name</th>
                                                        <th scope="col">Account Type</th>
                                                        <th scope="col">Edit</th>
                                                        <th scope="col">Delete</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php
                                                    if (empty($_GET['search_query'])) {
                                                        $sql = "SELECT * FROM tbl_accounts_catogery";
                                                        $result = mysqli_query($conn, $sql);

                                                        if (mysqli_num_rows($result) > 0) {
                                                            while ($row = mysqli_fetch_assoc($result)) {
                                                                echo "<tr>";
                                                                echo "<td>" . $row['acc_id'] . "</td>";
                                                                echo "<td>" . $row['Description'] . "</td>";
                                                                echo "<td>" . $row['account_type'] . "</td>";
                                                                echo "<td><a href='acc_category_edit.php?id=" . $row['acc_id'] . "' class='btn btn-dark' role='button' aria-pressed='true'>Edit</a></td>";
                                                                echo "<td><a href='#' class='btn btn-danger' role='button' aria-pressed='true' onclick='showConfirmation(" . $row['acc_id'] . ")'>Delete</a></td>";
                                                                echo "</tr>";
                                                            }
                                                        } 
                                                    }

                                                    ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div> <!-- end card-body-->
                            </div> <!-- end card-->
                        </div> <!-- end col -->
                    </div>
                </div> <!-- container-fluid -->
            </div>
            <!-- End Page-content -->

            <?php include './footer.php'; ?>

        </div>
        <!-- end main content-->

        </div>
        <!-- END layout-wrapper -->

        <!-- Overlay-->
        <div class="menu-overlay"></div>

        <!-- jQuery  -->
        <script src="assets/js/jquery.min.js"></script>
        <script src="assets/js/bootstrap.bundle.min.js"></script>
        <script src="assets/js/metismenu.min.js"></script>
        <script src="assets/js/waves.js"></script>
        <script src="assets/js/simplebar.min.js"></script>
        <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
        <!-- Validation custom js-->
        <script src="assets/pages/validation-demo.js"></script>

        <!-- App js -->
        <script src="assets/js/theme.js"></script>

        <!-- Custom script -->
        <script>
            $('#customer_table').DataTable();

            function showConfirmation(jobId) {
        Swal.fire({
          title: 'Are you sure?',
          text: 'You are about to delete Catogery ID: ' + jobId,
          icon: 'warning',
          showCancelButton: true,
          confirmButtonColor: '#3085d6',
          cancelButtonColor: '#d33',
          confirmButtonText: 'Yes, delete it!'
        }).then((result) => {
          if (result.isConfirmed) {
            window.location.href = 'acc_category_delete.php?id=' + jobId;
          }
        });
      }

      

        </script>

<?php
if (isset($_POST['save'])) {
  $catname = $_POST['catname'];
  $type = $_POST['account_type'];
  $current_u = $_SESSION['staffname'];

  $insert = "INSERT INTO `tbl_accounts_catogery`(`Description`, `account_type`, `created_by`) VALUES ('$catname','$type','$current_u')";
  
  if (mysqli_query($conn, $insert)) {
    echo "<script>
      Swal.fire({
        icon: 'success',
        title: 'Success!',
        text: 'Record has been saved successfully.',
        showConfirmButton: false,
        timer: 1500 // Automatically close after 1.5 seconds
      }).then(function() {
        window.location.href = 'accountcatogeris.php'; // Redirect after alert is closed
      });
    </script>";
  } else {
    echo "Error: " . mysqli_error($conn);
  }
  
  mysqli_close($conn);
} ?>

    </body>

    </html>
<?php } ?>

