<?php
require('./config.php'); // Database connection

function calculateInterest($conn) {
    $today = date('Y-m-d');

    // Fetch all active loans with balance > 0
    $sql = "SELECT id, loan_balance, monthly_interest_rate, create_date 
            FROM tbl_loan 
            WHERE loan_balance > 0";

    $result = $conn->query($sql);

    while ($row = $result->fetch_assoc()) {
        $loanId = $row['id'];
        $balance = $row['loan_balance'];
        $interestRate = $row['monthly_interest_rate'];
        $createDate = $row['create_date'];

        // Calculate the number of 30-day cycles since loan creation
        $daysDiff = (strtotime($today) - strtotime($createDate)) / (60 * 60 * 24);
        $cycles = floor($daysDiff / 30);

        // Fetch the last interest calculation date


        // Calculate interest for missing cycles
        while ($cycles > 0) {
            $lastInterestDateSql = "SELECT MAX(payment_date) AS last_interest_date 
            FROM tbl_loan_interest 
            WHERE loan_id = ?";
            $stmt = $conn->prepare($lastInterestDateSql);
            $stmt->bind_param('i', $loanId);
            $stmt->execute();
            $lastInterestDateResult = $stmt->get_result()->fetch_assoc();
            $lastInterestDate = $lastInterestDateResult['last_interest_date'] ?? $createDate;

            $lastlnstallDateSql = "SELECT MAX(due_date) AS last_install_date 
            FROM tbl_installments 
            WHERE loan_id = ?";
            $stmt = $conn->prepare($lastlnstallDateSql);
            $stmt->bind_param('i', $loanId);
            $stmt->execute();
            $lastlnstallDateResult = $stmt->get_result()->fetch_assoc();
            $lastlnstallDate = $lastlnstallDateResult['last_install_date'] ?? $createDate;

           
            $lcount="SELECT letter_count from tbl_loan WHERE id = ?";
            $stmt = $conn->prepare($lcount);
            $stmt->bind_param('i', $loanId);
            $stmt->execute();
            $lettercountr = $stmt->get_result()->fetch_assoc();
            $lettercount = $lettercountr['letter_count'];
           
           $balance1 = "SELECT loan_balance
            FROM tbl_loan 
            WHERE id = ?";

            $stmt = $conn->prepare($balance1);
            $stmt->bind_param('i', $loanId);
            $stmt->execute();
            $balance1r = $stmt->get_result()->fetch_assoc();
            $balance = $balance1r['loan_balance'] ;

            $balance2 = "SELECT requested_amount, repay_duration
            FROM tbl_loan 
            WHERE id = ?";

            $stmt = $conn->prepare($balance2);
            $stmt->bind_param('i', $loanId);
            $stmt->execute();
            $balance2r = $stmt->get_result()->fetch_assoc();
            $balance2 = $balance2r['requested_amount'] ;
            $duration = $balance2r['repay_duration'] ;
            $duedate= date('Y-m-d', strtotime($lastlnstallDate . ' +30 days'));
            $nextInterestDate = date('Y-m-d', strtotime($lastInterestDate . ' +30 days'));
            $nextInstallDate = date('Y-m-d', strtotime($lastlnstallDate . ' +30 days'));
            if (strtotime($nextInterestDate) > strtotime($today)) {
                break;
            }

            if (strtotime($nextInstallDate) > strtotime($today)) {
                break;
            }
            $payment_st_date=$nextInterestDate;
            $payment_end_date=date('Y-m-d', strtotime($nextInterestDate . ' +30 days'));
            // Calculate interest for this cycle
            $interestAmount = $balance * ($interestRate / 100);
            $installamount = $balance2 / $duration;

            // Insert into tbl_lender_interest
            $insertSql = "INSERT INTO tbl_loan_interest 
                          (loan_id, interest_amount, payment_date, payment_st_date, payment_end_date, balance_interest) 
                          VALUES (?, ?, ?, ?, ?, ?)";
            $insertStmt = $conn->prepare($insertSql);
            $insertStmt->bind_param('idsssd', $loanId, $interestAmount, $nextInterestDate,$payment_st_date, $payment_end_date, $interestAmount);
            $insertStmt->execute();

            $insertSql1 = "INSERT INTO tbl_installments 
            (loan_id, installment_amount, due_date, status, payment_st_date, payment_end_date) 
            VALUES (?, ?, ?, 'Pending',?,?)";
            $insertStmt1 = $conn->prepare($insertSql1);
            $insertStmt1->bind_param('idsss', $loanId, $installamount, $duedate,$payment_st_date, $payment_end_date);
            $insertStmt1->execute();
            $lettercount++;
            // Update balance in tbl_lender_loan
            $updateSql = "UPDATE tbl_loan 
                          SET loan_balance = loan_balance + ? 
                          WHERE id = ?";
            $updateStmt = $conn->prepare($updateSql);
            $updateStmt->bind_param('di', $interestAmount, $loanId);
            $updateStmt->execute();

            $updateSql2 = "UPDATE tbl_loan 
                          SET letter_count = ? 
                          WHERE id = ?";
            $updateStmt2 = $conn->prepare($updateSql2);
            $updateStmt2->bind_param('ii', $lettercount, $loanId);
            $updateStmt2->execute();

            // Update lastInterestDate and decrement cycles
            $lastInterestDate = $nextInterestDate;
            $cycles--;
        }
    }
}

calculateInterest($conn);
?>
