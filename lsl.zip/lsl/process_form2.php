<?php
session_start(); 
require('./config.php');


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $expenseDescription = $_POST['incomeDescription'];
    $amount = $_POST['amount'];
    $createdBy = $_SESSION['staffname'];
    $billType = $_POST['billType'];
    $froms = $_POST['froms'];
    $payType = $_POST['paymentType'];

    // if ($payType == 5 || $payType == 6) {
    //     $chequeNo = $_POST['checkNumber'];
    //     $realizeDate = $_POST['realizationDate'];
    // } else {
    //     $chequeNo = null;
    //     $realizeDate = null;
    // }

    if ($billType == 'customer') {
        $custId = $_POST['customer'];
        $billNo = $_POST['InvNumber'];
        $expCat = null;
    } elseif ($billType == 'other') {
        $custId = null;
        $billNo = null;
        $expCat = $_POST['incomeCategory'];
    }

    // Insert data into tbl_income
    $insertQuery = "INSERT INTO tbl_income (billType, `froms`, Inv_no, inc_cat, inc_desc, amount, cust_ID, pay_id,  create_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($insertQuery);
    $stmt->bind_param("sssssdsss",$billType, $froms, $billNo, $expCat, $expenseDescription, $amount, $custId, $payType,  $createdBy );
    
    if ($stmt->execute()) {
        $income_id = $stmt->insert_id; 
        $response = array("success" => true, "income_id" => $income_id);
        echo json_encode($response);
    } else {
        $response = array("success" => false, "error" => $stmt->error);
        echo json_encode($response);
    }

    $stmt->close();
}

$conn->close();
?>
