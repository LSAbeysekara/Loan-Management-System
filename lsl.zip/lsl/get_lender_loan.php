<?php
require('./config.php');

// Fetch lender loans with unpaid interest or outstanding balance
$query = "
SELECT 
    ll.id, 
    CONCAT(l.lender_name, ' - Loan ID: ', ll.id, 
           ' (Remaining Balance: ', ll.balance, 
           ', Unpaid Interest: ', COALESCE(SUM(li.interest_amount), 0), ')') AS loan_details
FROM 
    tbl_lender_loan ll
JOIN 
    tbl_lender l ON ll.lender_id = l.id
LEFT JOIN 
    tbl_lender_interest li ON li.lender_loan_id = ll.id AND li.status = 'unpaid'
WHERE 
    ll.balance > 0
GROUP BY 
    ll.id, l.lender_name, ll.balance
HAVING 
    SUM(li.interest_amount) > 0
ORDER BY 
    l.lender_name ASC;


";

$result = mysqli_query($conn, $query);

if (!$result) {
    echo json_encode(['error' => 'Failed to fetch lender loans.']);
    exit;
}

$lenderLoans = [];
while ($row = mysqli_fetch_assoc($result)) {
    $lenderLoans[] = [
        'id' => $row['id'],
        'loan_details' => $row['loan_details']
    ];
}

echo json_encode($lenderLoans);
?>
