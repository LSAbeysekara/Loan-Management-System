<?php
session_start();
require('./config.php');

// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

date_default_timezone_set('Asia/Kolkata');

function debug_print($message, $data = null) {
    echo $message;
    if ($data !== null) {
        echo "<pre>";
        print_r($data);
        echo "</pre>";
    }
    echo "<br>";
}

function getPaymentDetails($conn, $loan_id) {
    // Get installment details
    $installment_query = "SELECT 
        MIN(payment_st_date) as first_installment_date,
        MAX(payment_end_date) as last_installment_date,
        COUNT(*) as total_installments,
        SUM(CASE WHEN status = 'Pending' THEN installment_amount ELSE 0 END) as pending_installments,
        COUNT(CASE WHEN status = 'Pending' AND due_date < CURRENT_DATE THEN 1 END) as overdue_count
        FROM tbl_installments 
        WHERE loan_id = ?";
    
    $stmt = $conn->prepare($installment_query);
    $stmt->bind_param("i", $loan_id);
    $stmt->execute();
    $installment_result = $stmt->get_result()->fetch_assoc();
    
    // Debugging: Check installment results
    error_log("Installment Details: " . print_r($installment_result, true));

    // Get interest payment details
    $interest_query = "SELECT 
        MIN(payment_st_date) as first_interest_date,
        MAX(payment_end_date) as last_interest_date,
        SUM(interest_amount) as total_interest,
        SUM(balance_interest) as pending_interest
        FROM tbl_loan_interest 
        WHERE loan_id = ?";
    
    $stmt = $conn->prepare($interest_query);
    $stmt->bind_param("i", $loan_id);
    $stmt->execute();
    $interest_result = $stmt->get_result()->fetch_assoc();
    
    // Debugging: Check interest results
    error_log("Interest Details: " . print_r($interest_result, true));
    
    return [
        'installments' => $installment_result,
        'interest' => $interest_result
    ];
}

function checkExistingWarningLetter($conn, $loan_id, $warning_type) {
    // Check if a warning letter already exists for this specific loan in the current month
    $query = "SELECT COUNT(*) as letter_count 
              FROM tbl_warning_letters 
              WHERE loan_id = ? 
              AND warning_type = ?
              AND MONTH(issued_date) = MONTH(CURRENT_DATE)
              AND YEAR(issued_date) = YEAR(CURRENT_DATE)";
    
    $stmt = $conn->prepare($query);
    $stmt->bind_param("is", $loan_id, $warning_type);
    $stmt->execute();
    $result = $stmt->get_result()->fetch_assoc();
    
    return $result['letter_count'] > 0;
}

function generateWarningLetters($conn, $sent_by) {
    debug_print("Starting warning letter generation process...");
    
    // Modified query to handle multiple loans per customer at different warning stages
    $check_query = "
        SELECT l.*, c.namesinhala, c.membership_number, c.nic_no
        FROM tbl_loan l
        JOIN tbl_customer c ON l.customer_id = c.id
        WHERE l.status = 'active' 
        AND l.letter_count IN (1, 2, 3)
        AND l.id NOT IN (
            -- Exclude loans that already have a warning letter this month
            SELECT w.loan_id 
            FROM tbl_warning_letters w 
            WHERE MONTH(w.issued_date) = MONTH(CURRENT_DATE)
            AND YEAR(w.issued_date) = YEAR(CURRENT_DATE)
        )
        ORDER BY l.customer_id, l.id";
    
    $check_result = $conn->query($check_query);
    
    if (!$check_result) {
        debug_print("Initial query failed: " . $conn->error);
        return;
    }
    
    debug_print("Initial query successful. Found " . $check_result->num_rows . " loans requiring warnings");
    
    while ($loan = $check_result->fetch_assoc()) {
        debug_print("Processing loan ID: {$loan['id']}, Customer ID: {$loan['customer_id']}, Letter Count: {$loan['letter_count']}");
        
        // Determine warning type
        $warning_type = '';
        switch ((int)$loan['letter_count']) {
            case 1:
                $warning_type = 'first';
                break;
            case 2:
                $warning_type = 'second';
                break;
            case 3:
                $warning_type = 'final';
                break;
            default:
                debug_print("Invalid letter count for loan ID " . $loan['id'] . ". Skipping.");
                continue 2;
        }
        
        // Get payment details and generate letter
        $payment_details = getPaymentDetails($conn, $loan['id']);
        $loan['payment_details'] = $payment_details;
        
        $message = generateSinhalaMessage($loan, $warning_type);
        
        // Insert warning letter
        $insert_query = "INSERT INTO tbl_warning_letters 
                        (customer_id, loan_id, message, warning_type, issued_date, sent_by, status)
                        VALUES (?, ?, ?, ?, CURRENT_DATE, ?, 'Pending')";
        
        $stmt = $conn->prepare($insert_query);
        
        if (!$stmt) {
            debug_print("Prepare failed: " . $conn->error);
            continue;
        }
        
        $stmt->bind_param("iissi", 
            $loan['customer_id'],
            $loan['id'],
            $message,
            $warning_type,
            $sent_by
        );
        
        if ($stmt->execute()) {
            debug_print("Successfully inserted warning letter for loan ID: {$loan['id']}, " .
                       "Warning type: {$warning_type}, Customer ID: {$loan['customer_id']}");
        } else {
            debug_print("Insert failed for loan ID {$loan['id']}: " . $stmt->error);
        }
        
        $stmt->close();
    }
    
    debug_print("Warning letter generation process completed");
}

function generateSinhalaMessage($loan, $warning_type) {
    $date = date('Y-m-d');
    $payment_details = $loan['payment_details'];

    // Calculate overdue information
    $overdue_days = floor((strtotime($date) - strtotime($loan['last_payment_date'])) / (60 * 60 * 24));
    $overdue_installments = $payment_details['installments']['pending_installments'] ?? 0;
    $overdue_interest = $payment_details['interest']['pending_interest'] ?? 0;
    $total_overdue = $overdue_installments + $overdue_interest;

    // Debugging: Check the values of overdue_installments and overdue_interest
    error_log("Overdue Installments: " . $overdue_installments);
    error_log("Overdue Interest: " . $overdue_interest);
    error_log("Total Overdue: " . $total_overdue);

    // Define message templates based on the warning type
    switch ($warning_type) {
        case 'first':
            // First Warning Letter
            $message = "$date\n\n";
            $message .= "පළමු සිහිකැදවීමයි.\n";
            $message .= "නම  : " . $loan['namesinhala'] . "\n";
            $message .= "ජා. හැ. අ:  " . $loan['nic_no'] . "\n";
            $message .= "සා. මා. අ : " . $loan['membership_number'] . "\n\n";
            $message .= "ණය වාරික ගෙවීම පැහැර හැරීම සම්බන්ධවයි.\n";
            $message .= $loan['namesinhala'] . " යන අය එල්.එස්.එල්. ක්‍රෙඩිට් ඇන්ඩ් ඉන්වෙස්මන්ට් (ප්‍රයිවට්) ලිමිටඩ් ආයතනය මගින් ණය මුදලක් ලබාගෙන ඇති අතර, මෙි වනවිට එම ණය මුදල ආපසු ගෙවීම ප්‍රමාදවී ඇති අතර ඒ සදහා ඹබ ගන්නා ක්‍රියාමාර්ගය ............. වන මස .......... දිනට ප්‍රථම ආයතනය දැනුවත් කරනමෙන් ඉල්ලා සිටිමු. එසේ කිරීමට ඹබ අපොහොසත් වන්නේනම් ආයතනය මගින් නීතිමය ක්‍රියාමාර්ග ගැනීමට සිදුවන බව කණගාටුවෙන් උවද දැනුම් දෙමු\n\n";
            $message .= "මුල් ණය මුදල: රු. " . number_format($loan['requested_amount'], 2) . "\n";
            $message .= "මාසික වාරික මුදල: රු. " . number_format($loan['agreed_monthly_payment'], 2) . "\n";
            $message .= "හිඟ වාරික මුදල: රු. " . number_format($overdue_installments, 2) . "\n";
            $message .= "හිඟ පොලී මුදල: රු. " . number_format($overdue_interest, 2) . "\n";
            $message .= "මුළු හිඟ මුදල: රු. " . number_format($total_overdue, 2) . "\n\n";
            $message .= "මෙයට,\nඅධ්‍ය ක්ෂ\n\n";
            $message .= "( මෙම එක් සිහිකැදවීම් ලිපියක් සදහා රැපියල් 250.00 මුදලක් අයවෙන බවද මෙයින් දන්වා සිටී. )";
            break;

        case 'second':
            // Second Warning Letter
            $message = "$date\n\n";
            $message .= "දෙවන සිහිකැදවීමයි.\n";
            $message .= "නම  : " . $loan['namesinhala'] . "\n";
            $message .= "ජා. හැ. අ:  " . $loan['nic_no'] . "\n";
            $message .= "සා. මා. අ : " . $loan['membership_number'] . "\n\n";
            $message .= "ණය වාරික ගෙවීම පැහැර හැරීම සම්බන්ධවයි.\n";
            $message .= $loan['namesinhala'] . " යන අය ඒල්. එස්. එල්. ක්‍රේඩිටි ඇන්ඩ් ඉන්වෙස්මන්ටි (ප්‍රයිවට්) ලිමිටඩ් ආයතනය මගින් ණය මුදලක් ලබාගෙන ඇති අතර මේ වන විට එම ණය මුදල ආපසු ගෙවිම ප්‍රමාදවී ඇත, මීට පෙර ඹබ වෙත පළමු සිහි කැදවීමි ලිපිය යොමුකල අතර ඒ සම්බන්දයෙන් ආයතනය කිසිදු දැනුවත් කිරීමක් ඔබ විසින් සිදු නොකල ඇති අතර, ඒ් සදහා ඔබ ගන්නා ක්‍රියාමාර්ගය .......... වන මස ......... වන දිනට ප්‍රථම ආයතනය දැනුවත් කරනමෙන් ඉල්ලා සිටිමු. එසේ කිරීමට ඹබ අපොහොසත් වන්නේ නම් ආයතනය මගින් නීතිමය ක්‍රියාමාර්ග ගැනීමට සිදුවන බව කණගාටුවෙන් වුවද දැනුම් දෙමු\n\n";
            $message .= "මුල් ණය මුදල: රු. " . number_format($loan['requested_amount'], 2) . "\n";
            $message .= "මාසික වාරික මුදල: රු. " . number_format($loan['agreed_monthly_payment'], 2) . "\n";
            $message .= "හිඟ වාරික මුදල: රු. " . number_format($overdue_installments, 2) . "\n";
            $message .= "හිඟ පොලී මුදල: රු. " . number_format($overdue_interest, 2) . "\n";
            $message .= "මුළු හිඟ මුදල: රු. " . number_format($total_overdue, 2) . "\n\n";
            $message .= "මෙයට,\nඅධ්‍යක්ෂ\n\n";
            $message .= "(මෙම එක් සිහිකැදවීීම් ලිපියක් සදහා රැපියල් 250.00 මුදලක් අයවෙන බවද මෙයින් දන්වා සිටී.)";
            break;

        case 'final':
            // Final Warning Letter
            $message = "$date\n";
            $message .= "අවසන් සිහිකැදවීමයි\n";
            $message .= "නම  : " . $loan['namesinhala'] . "\n";
            $message .= "ජා. හැ. අ:  " . $loan['nic_no'] . "\n";
            $message .= "සා. මා. අ : " . $loan['membership_number'] . "\n\n";
            $message .= "ණය වාරික ගෙවීම පැහැර හැරීම සම්බන්ධවයි.\n";
            $message .= $loan['namesinhala'] . " යන අය ඒල්. එස්. ඒල්. ක්‍රෙඩිටි ඇන්ඩ් ඉන්වෙස්මන්ටි (ප්‍රයිවට්) ලිමිටඩ් ආයතනය මගින් ණය මුදලක් ලබාගෙන ඇති අතර, මේ වන විට එම ණය මුදල ආපසු ගෙවිම ප්‍රමාදවී ඇත, මීට පෙර ඹබ වෙත සිහි කැදවීම් ලිපි යොමුකලත් ඒ සම්බන්දයෙන් ආයතනය කිසිදු දැනුවත් කිරීමක් ඔබ විසින් සිදු කළ නොමැත. ආයතනික ක්‍රියාමාර්ග සියල්ල අවසාන සිහිකැඳවීම මගින් අවසන් වන අතර අපගේ නීතීඥ මණ්ඩලයේ නීතීඥ මහතෙකු විසින් ඔබට එන්තරවාසියක් ලැබීමට සලස්වන අතර එහිදී නීතීඥ උපදෙස් අනුව නඩු පැවරීම සිදු කරනු ලබයි. මෙය ආයතනය ලෙස දැනුවත් කරන අවසාන ලිපිය වෙයි.\n\n";
            $message .= "මුල් ණය මුදල: රු. " . number_format($loan['requested_amount'], 2) . "\n"; // Use requested_amount
            $message .= "මාසික වාරික මුදල: රු. " . number_format($loan['agreed_monthly_payment'], 2) . "\n"; // Use agreed_monthly_payment
            $message .= "හිඟ වාරික මුදල: රු. " . number_format($overdue_installments, 2) . "\n";
            $message .= "හිඟ පොලී මුදල: රු. " . number_format($overdue_interest, 2) . "\n";
            $message .= "මුළු හිඟ මුදල: රු. " . number_format($total_overdue, 2) . "\n\n";
            $message .= "මීට ,\nඅධ්‍යක්ෂක.\n\n";
            $message .= "( මෙම එක් සිහිකැදවීීම් ලිපියක් සදහා රැපියල් 250.00 මුදලක් අයවෙන බවද මෙයින් දන්වා සිටී. )";
            break;

        default:
            // Invalid warning type
            $message = "Invalid warning type specified.";
            break;
    }

    return $message;
}

// Execute
debug_print("Starting script execution");
generateWarningLetters($conn, 1);
debug_print("Script execution completed");

$conn->close();
?>