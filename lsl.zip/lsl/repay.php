<?php session_start(); ?>
<?php require('./config.php'); 

// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Start output buffering
ob_start();

?>

<?php if (!isset($_SESSION['staffname'])) {
  echo "<script> window.location.replace('login.php'); </script>";
} else { ?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <title>LSL System</title>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta content="Premium Multipurpose Admin & Dashboard Template" name="description" />
    <meta content="MyraStudio" name="author" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />

    <!-- App favicon -->
    <link rel="shortcut icon" href="assets/images/favicon.ico">

    <!-- App css -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <link href="assets/css/icons.min.css" rel="stylesheet" type="text/css" />
    <link href="assets/css/theme.min.css" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/css/select2.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0&icon_names=edit" />
    <link rel="stylesheet" type="text/css" href="https://common.olemiss.edu/_js/sweet-alert/sweet-alert.css">

    <script src="https://common.olemiss.edu/_js/sweet-alert/sweet-alert.min.js"></script>
    <style type="text/css">
    body {
        font-family: Arial, sans-serif;
        background-color: #f9f9f9;
        margin: 0;
        padding: 0;
    }

    .container {
        max-width: 800px;
        margin: 50px auto;
        padding: 20px;
        background-color: #fff;
        border-radius: 5px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }

    h2, h3 {
        margin-bottom: 20px;
        color: #333;
    }

    .form-group {
        margin-bottom: 15px;
    }

    label {
        display: block;
        font-weight: bold;
        margin-bottom: 5px;
    }

    input, select {
        width: 100%;
        padding: 8px;
        font-size: 14px;
        border: 1px solid #ccc;
        border-radius: 4px;
    }

    #records-table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
    }

    #records-table th, #records-table td {
        border: 1px solid #ddd;
        padding: 8px;
        text-align: center;
    }

    #records-table th {
        background-color: #f4f4f4;
    }

    button {
        padding: 10px 15px;
        font-size: 16px;
        color: #fff;
        background-color: #007BFF;
        border: none;
        border-radius: 4px;
        cursor: pointer;
    }

    button:hover {
        background-color: #0056b3;
    }

    .period-header td {
        padding: 10px !important;
        background-color: #f0f0f0 !important;
        border-top: 2px solid #ddd !important;
        border-bottom: 2px solid #ddd !important;
    }

    .period-header td span {
        font-weight: bold;
    }
    
    /* Container for each installment or interest value */
    .amount-container {
        display: inline-flex;
        align-items: center;
        justify-content: space-between;
        width: 100%;
    }

    /* Style for the edit icon */
    .material-symbols-outlined.edit-icon {
        cursor: pointer;
        margin-left: 8px; /* Adjust this to add space between the value and the icon */
        font-size: 20px; /* Adjust icon size */
        color: #007bff; /* Optional: Set the color of the icon */
    }

    /* Optionally, you can style the amount (installment/interest) text */
    .amount-text {
        font-size: 16px; /* Adjust text size */
        color: #333; /* Optional: Set the color of the text */
    }

    

    #payment-section{
        margin-top: 20px;
    }

    </style>
</head>

<body>

    <!-- Begin page -->
    <div id="layout-wrapper">
    <?php include('header.php'); ?>
    <?php include('sidebar.php'); ?>


        <!-- ============================================================== -->
        <!-- Start right Content here -->
        <!-- ============================================================== -->
        <div class="main-content">

            <div class="page-content">
                <div class="container-fluid">

                    <!-- start page title -->
                    <div class="row">
                        <div class="col-12">
                            <div class="page-title-box d-flex align-items-center justify-content-between">
                                <h4 class="mb-0 font-size-18">Payments</h4>

                                <div class="page-title-right">
                                    <ol class="breadcrumb m-0">
                                        <li class="breadcrumb-item"><a href="javascript: void(0);">Staff</a></li>
                                        <li class="breadcrumb-item active">Add Staff</li>
                                    </ol>
                                </div>
                            </div>
                        </div>
                    </div>     
                    <!-- end page title -->

                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-body">
                    
                                <h4 class="card-title">Add Staff</h4>
                                <p class="card-subtitle mb-4">Add staff here with required details.</p>

                                <div class="form-group">
                                    <label for="customer">Select Customer:</label>
                                    <select id="customer" class="searchable-dropdown" style="width: 100%;"></select>
                                </div>

                                <!-- Pending Records -->
                                <div id="pending-records">
                                    <h3>Pending Payments</h3>
                                    <table id="records-table">
                                        <thead>
                                            <tr>
                                                <th>Type</th>
                                                <th>Amount</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <!-- Rows will be dynamically populated -->
                                        </tbody>
                                    </table>
                                </div>

                                <!-- Modal for Manager Password -->
                                <div id="managerPasswordModal" class="modal" tabindex="-1" role="dialog">
                                    <div class="modal-dialog" role="document">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title">Manager Password Required</h5>
                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                    <span aria-hidden="true">&times;</span>
                                                </button>
                                            </div>
                                            <div class="modal-body">
                                                <p>Please enter the manager's password to edit the interest amount.</p>
                                                <input type="password" id="manager-password-input" class="form-control" placeholder="Manager Password">
                                                <!-- Add the hidden input for manager username -->
                                                <input type="hidden" id="manager-username" name="manager_username">
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                                                <button type="button" id="submit-manager-password" class="btn btn-primary">Submit</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <!-- Payment Section -->
                                <div id="payment-section">
                                    <h3>Make Payment</h3>
                                    <form id="payment-form">
                                        <div class="form-group">
                                            <label for="repayment-amount">Total Amount to Pay:</label>
                                            <input type="number" id="repayment-amount" name="repayment_amount" readonly>
                                        </div>

                                        <div id="manager-approval-section" style="display: none;">
                                            <label for="manager-password">Manager Approval Password:</label>
                                            <input type="password" id="manager-password">
                                        </div>

                                        <div class="form-group">
                                            <label for="payment-method">Payment Method:</label>
                                            <select id="payment-method" name="payment_method" required>
                                                <option value="Cash">Cash</option>
                                                <option value="Bank Deposit">Bank Deposit</option>
                                            </select>
                                        </div>

                                        <button type="submit">Submit Payment</button>
                                    </form>
                                </div>

                                </div> <!-- end card-body-->
                            </div> <!-- end card-->
                        </div> <!-- end col -->
                    </div>
                    <!-- end row-->

                </div> <!-- container-fluid -->
            </div>
            <!-- End Page-content -->

         <?php include './footer.php'; ?>                                           

        </div>
        <!-- end main content-->

    </div>
    <!-- END layout-wrapper -->

    <!-- Overlay-->
    <div class="menu-overlay"></div>

    <!-- jQuery  -->
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/metismenu.min.js"></script>
    <script src="assets/js/waves.js"></script>
    <script src="assets/js/simplebar.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/js/select2.min.js"></script>

     <!-- Validation custom js-->
     <script src="assets/pages/validation-demo.js"></script>

    <!-- App js -->
    <script src="assets/js/theme.js"></script>

    <!-- Custom script -->
    <script>
    $(document).ready(function () {
        let totalAmount = 0;
        let reducedAmounts = {};
        let originalAmounts = {};

        $('.searchable-dropdown').select2({
            ajax: {
                url: 'repayback.php',
                method: 'POST',
                dataType: 'json',
                data: function(params) {
                    return {
                        action: 'load_customers',
                        search: params.term
                    };
                },
                processResults: function(data) {
                    return {
                        results: data.map(customer => ({
                            id: customer.id,
                            text: customer.full_name
                        }))
                    };
                }
            },
            placeholder: 'Select a customer'
        });

        $('#customer').on('change', function () {
            const customerId = $(this).val();
            $.post('repayback.php', { action: 'load_pending', customer_id: customerId }, function (data) {
                const periods = JSON.parse(data);
                const tableBody = $('#records-table tbody');
                tableBody.empty();
                totalAmount = 0;

                periods.forEach(period => {
                    const [startDate, endDate] = period.period.split(' to ');
                    
                    tableBody.append(`
                        <tr class="period-header">
                            <td colspan="3" style="text-align: left;">
                                Payment Period: <span style="color: red;">${startDate}</span> to <span style="color: red;">${endDate}</span>
                            </td>
                        </tr>
                    `);

                    period.records.forEach(record => {
                        totalAmount += parseFloat(record.amount);
                        const isInterest = record.type === 'Interest';
                        
                        tableBody.append(`
                            <tr>
                                <td>${record.type}</td>
                                <td>
                                    <span class="amount-text" data-amount="${record.amount}">${record.amount}</span>
                                    <input type="number" min="0" class="edit-amount" value="${record.amount}" style="display:none;" />
                                    <button class="submit-edit" style="display:none;">Submit</button>
                                    ${isInterest ? `
                                        <span class='material-symbols-outlined edit-icon' style="cursor: pointer; color: blue;">edit</span>
                                        <span class='material-symbols-outlined edit-icon-red' style="cursor: pointer; color: red; margin-left: 5px;">edit</span>
                                    ` : `
                                        <span class='material-symbols-outlined edit-icon' style="cursor: pointer;">edit</span>
                                    `}
                                </td>
                                <td>
                                    <input type="checkbox" class="record-select" 
                                        data-type="${record.type}" 
                                        data-id="${record.id}" 
                                        data-amount="${record.amount}">
                                </td>
                            </tr>
                        `);
                    });
                });

                updateTotalAmount();
            });
        });

        $(document).on('click', '.edit-icon', function() {
            const row = $(this).closest('tr');
            const recordId = row.find('.record-select').data('id');
            const recordType = row.find('.record-select').data('type');
            const currentAmount = parseFloat(row.find('.amount-text').data('amount'));
            
            // Store original amount
            originalAmounts[recordId] = currentAmount;
            
            const amountText = row.find('.amount-text');
            const editAmount = row.find('.edit-amount');
            const submitButton = row.find('.submit-edit');

            amountText.hide();
            $(this).hide();
            row.find('.edit-icon-red').hide();
            editAmount.show();
            submitButton.show();
            
            // Store record type with the edit input
            editAmount.data('recordType', recordType);
            // Mark this as blue edit
            editAmount.data('editType', 'blue');
        });

        $(document).on('click', '.edit-icon-red', function () {
            const row = $(this).closest('tr');
            const recordId = row.find('.record-select').data('id');
            
            $.post('repayback.php', {
                action: 'get_original_interest',
                record_id: recordId
            }, function(response) {
                const result = JSON.parse(response);
                if (result.status === 'success') {
                    $('#managerPasswordModal')
                        .data('originalDbAmount', result.original_amount)
                        .data('row', row)
                        .data('isRedEdit', true)
                        .data('recordId', recordId);
                    $('#managerPasswordModal').modal('show');
                } else {
                    alert('Failed to fetch original interest amount');
                }
            });
        });

        function updateTotalAmount() {
            let selectedTotal = 0;
            $('.record-select:checked').each(function () {
                const amount = parseFloat($(this).closest('tr').find('.amount-text').data('amount'));
                selectedTotal += amount;
            });
            $('#repayment-amount').val(selectedTotal.toFixed(2));
        }

        $('#submit-manager-password').on('click', function () {
            const password = $('#manager-password-input').val();
            const row = $('#managerPasswordModal').data('row');
            const isRedEdit = $('#managerPasswordModal').data('isRedEdit');

            $.post('repayback.php', {
                action: 'validate_manager_password',
                password: password
            }, function (response) {
                const res = JSON.parse(response);
                if (res.status === 'success') {
                    const amountText = row.find('.amount-text');
                    const editAmount = row.find('.edit-amount');
                    const submitButton = row.find('.submit-edit');

                    $('#manager-username').val(res.username);

                    if (isRedEdit) {
                        // For red edit button
                        submitButton.data('isRedEdit', true);
                    } else {
                        // For blue edit button
                        submitButton.data('isRedEdit', false);
                    }

                    amountText.hide();
                    row.find('.edit-icon').hide();
                    row.find('.edit-icon-red').hide();
                    editAmount.show();
                    submitButton.show();
                    editAmount.data('isRedEdit', isRedEdit);

                    $('#managerPasswordModal').modal('hide');
                } else {
                    alert(res.message || 'Invalid password. Please try again.');
                }
            });
        });

        $('#managerPasswordModal').on('hidden.bs.modal', function () {
            $('#manager-password-input').val('');
        });

        $(document).on('click', '.submit-edit', function() {
            const row = $(this).closest('tr');
            const editAmount = row.find('.edit-amount');
            const amountText = row.find('.amount-text');
            const recordId = row.find('.record-select').data('id');
            const recordType = editAmount.data('recordType');
            const newAmount = parseFloat(editAmount.val());
            const isRedEdit = editAmount.data('isRedEdit');

            if (isRedEdit) {
                // Handle red edit button submission - immediate update to database
                const originalAmount = originalAmounts[recordId];

                // Insert into expenses table with the correctly calculated reduction
                const reducedAmount = originalAmount - newAmount;

                $.post('repayback.php', {
                    action: 'process_interest_reduction',
                    record_id: recordId,
                    original_db_amount: originalAmount,
                    new_amount: newAmount,
                    manager_username: $('#manager-username').val() || ''
                }, function(response) {
                    const result = JSON.parse(response);
                    if (result.status === 'success') {
                        // Update display
                        amountText.text(newAmount.toFixed(2));
                        amountText.data('amount', newAmount);
                        editAmount.hide();
                        row.find('.submit-edit').hide();
                        amountText.show();
                        row.find('.edit-icon').show();
                        row.find('.edit-icon-red').show();
                        updateTotalAmount();

                        // Insert reduced amount into tbl_expenses
                        $.post('repayback.php', {
                            action: 'insert_expense',
                            exp_desc: `Interest reduction: Record ID ${recordId}, Original Amount: ${originalAmount}, Reduced to: ${newAmount}`,
                            reduced_amount: reducedAmount
                        }, function(expenseResponse) {
                            const expenseResult = JSON.parse(expenseResponse);
                            if (expenseResult.status !== 'success') {
                                alert('Failed to record expense: ' + expenseResult.message);
                            }
                        });
                    } else {
                        alert(result.message || 'Failed to update interest amount');
                    }
                });
            } else {
                // Handle blue edit button submission - store for payment processing
                const originalAmount = originalAmounts[recordId];
                
                // Validate new amount
                if (newAmount > originalAmount) {
                    alert('New payment amount cannot be greater than the original amount');
                    return;
                }
                
                if (newAmount < 0) {
                    alert('Amount cannot be negative');
                    return;
                }
                
                // Calculate remaining amount that will be stored in DB
                const remainingAmount = originalAmount - newAmount;
                reducedAmounts[recordId] = {
                    originalAmount: originalAmount,
                    paymentAmount: newAmount,
                    remainingAmount: remainingAmount,
                    type: recordType
                };

                // Update display
                amountText.text(newAmount.toFixed(2));
                amountText.data('amount', newAmount);
                editAmount.hide();
                row.find('.submit-edit').hide();
                amountText.show();
                row.find('.edit-icon').show();
                row.find('.edit-icon-red').show();
                updateTotalAmount();
            }
        });

        $(document).on('change', '.record-select', function () {
            updateTotalAmount();
        });

        $('#payment-form').on('submit', function(e) {
            e.preventDefault();

            const selectedRecords = [];
            $('.record-select:checked').each(function() {
                const row = $(this).closest('tr');
                const recordId = $(this).data('id');
                const recordType = $(this).data('type');
                const paymentAmount = parseFloat(row.find('.amount-text').data('amount'));
                
                const recordData = {
                    id: recordId,
                    type: recordType,
                    amount: paymentAmount  // Amount being paid now
                };

                // Add reduction info if exists
                if (reducedAmounts[recordId]) {
                    recordData.originalAmount = reducedAmounts[recordId].originalAmount;
                    recordData.remainingAmount = reducedAmounts[recordId].remainingAmount;  // Amount to store in DB
                }

                selectedRecords.push(recordData);
            });

            const formData = new FormData();
            formData.append('action', 'process_payment');
            formData.append('customer_id', $('#customer').val());
            formData.append('repayment_amount', $('#repayment-amount').val());
            formData.append('payment_method', $('#payment-method').val());
            formData.append('manager_username', $('#manager-username').val() || '');
            formData.append('selected_records', JSON.stringify(selectedRecords));

            $.ajax({
                url: 'repayback.php',
                type: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                success: function(response) {
                    try {
                        const result = JSON.parse(response);
                        if (result.status === 'success') {
                            swal({
                                title: "Payment Successful",
                                text: "Would you like to print the payment voucher?",
                                type: "success",
                                showCancelButton: true,
                                confirmButtonText: "Yes, print it!",
                                cancelButtonText: "No, skip printing",
                                closeOnConfirm: false,
                                closeOnCancel: false
                            }, function(isConfirm) {
                                if (isConfirm) {
                                    window.location.href = `payment_voucher.php?id=${result.paymentId}`;
                                } else {
                                    swal({
                                        title: "Print Cancelled",
                                        text: "You can print the voucher later from the payments section",
                                        type: "info"
                                    }, function() {
                                        $('#payment-form')[0].reset();
                                        location.reload();
                                    });
                                }
                            });
                        } else {
                            swal("Error", result.message || 'Payment processing failed', "error");
                        }
                    } catch (e) {
                        console.error('Error parsing response:', e);
                        swal("Error", 'An unexpected error occurred', "error");
                    }
                },
                error: function(xhr, status, error) {
                    console.error('AJAX Error:', status, error);
                    swal("Error", 'Failed to process payment. Please try again.', "error");
                }
            });
        });
    });

    </script>

</body>

</html>
<?php } ?>
