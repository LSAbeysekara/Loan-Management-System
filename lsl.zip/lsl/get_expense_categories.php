<?php session_start(); 
 require('./config.php'); ?>
<?php 

$expenseCategories = array();

$expenseQuery = "SELECT acc_id, Description FROM tbl_accounts_catogery WHERE account_type = 'expenses'";
$result = $conn->query($expenseQuery);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $expenseCategories[] = array(
            "cat_id" => $row["acc_id"],
            "cat_name" => $row["Description"]
        );
    }
}

$conn->close();

header("Content-Type: application/json");
echo json_encode($expenseCategories);
?>
