<?php
require('./config.php');
$query = "
    SELECT ll.id, l.lender_name AS lender_name, ll.monthly_interest_rate, ll.requested_amount, ll.repay_duration,
           ll.purpose, ll.loan_type, ll.agreed_monthly_payment
    FROM tbl_lender_loan ll
    JOIN tbl_lender l ON ll.lender_id = l.id
";
$result = $conn->query($query);
$loans = [];
while ($row = $result->fetch_assoc()) {
    $loans[] = $row;
}
echo json_encode($loans);
?>
