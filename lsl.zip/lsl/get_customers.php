<?php
require('./config.php');

$query = "SELECT id, name_with_initials AS name, nic_no FROM tbl_customer ORDER BY name ASC";
$result = $conn->query($query);

$customers = [];
while ($row = $result->fetch_assoc()) {
    $customers[] = $row;
}

echo json_encode($customers);
?>
