<?php
require('./config.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $docType = $_POST['docType'];
    $docId = $_POST['docId'];

    $tableFields = [
        'tbl_expenses' => 'exp_id',
        'tbl_income' => 'income_id',
        'tbl_payments' => 'id'
    ];

    if (isset($tableFields[$docType])) {
        $idField = $tableFields[$docType];
        $query = "UPDATE $docType SET status = 'cancel' WHERE $idField = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param('s', $docId);

        if ($stmt->execute()) {
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['success' => false, 'error' => 'Failed to update status.']);
        }
    } else {
        echo json_encode(['success' => false, 'error' => 'Invalid document type.']);
    }
}
