<?php
session_start();
require('./config.php');

// Check if the user is logged in
if (!isset($_SESSION['staffname'])) {
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized access.']);
    exit;
}

// Check if the request is POST and contains the lender ID
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id'])) {
    $lenderId = intval($_POST['id']); // Sanitize the input

    // Check if the lender exists in the database
    $checkQuery = $conn->prepare("SELECT id FROM tbl_lender WHERE id = ?");
    $checkQuery->bind_param("i", $lenderId);
    $checkQuery->execute();
    $checkQuery->store_result();

    if ($checkQuery->num_rows > 0) {
        // Lender exists, proceed to delete
        $deleteQuery = $conn->prepare("DELETE FROM tbl_lender WHERE id = ?");
        $deleteQuery->bind_param("i", $lenderId);

        if ($deleteQuery->execute()) {
            echo json_encode(['status' => 'success', 'message' => 'Lender deleted successfully.']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Failed to delete lender.']);
        }
        $deleteQuery->close();
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Lender not found.']);
    }
    $checkQuery->close();
} else {
    echo json_encode(['status' => 'error', 'message' => 'Invalid request.']);
}

$conn->close();
?>
