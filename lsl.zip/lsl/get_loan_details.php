<?php
require('./config.php');

// Get the loan ID from the request
if (!isset($_GET['loan_id']) || empty($_GET['loan_id'])) {
    echo json_encode(['error' => 'Loan ID is required.']);
    exit;
}

$loan_id = mysqli_real_escape_string($conn, $_GET['loan_id']);

// Fetch loan details along with unpaid interest
$query = "
    SELECT 
        ll.id AS loan_id,
        l.lender_name,
        ll.balance AS remaining_balance,
        ll.requested_amount,
        ll.agreed_monthly_payment,
        ll.repay_duration,
        ll.loan_type,
        COALESCE(SUM(CASE WHEN li.status = 'unpaid' THEN li.interest_amount ELSE 0 END), 0) AS total_unpaid_interest
    FROM tbl_lender_loan ll
    JOIN tbl_lender l ON ll.lender_id = l.id
    LEFT JOIN tbl_lender_interest li ON li.lender_loan_id = ll.id
    WHERE ll.id = '$loan_id'
    GROUP BY ll.id, l.lender_name, ll.balance, ll.requested_amount, ll.agreed_monthly_payment, ll.repay_duration, ll.loan_type
    LIMIT 1
";

$result = mysqli_query($conn, $query);

if (!$result) {
    echo json_encode(['error' => 'Failed to fetch loan details.']);
    exit;
}

$loanDetails = mysqli_fetch_assoc($result);

if (!$loanDetails) {
    echo json_encode(['error' => 'No loan found with the provided ID.']);
    exit;
}

// Return loan details as JSON
echo json_encode([
    'success' => true, 
    'data' => [
        'loan_id' => $loanDetails['loan_id'],
        'lender_name' => $loanDetails['lender_name'],
        'requested_amount' => $loanDetails['requested_amount'],
        'remaining_balance' => $loanDetails['remaining_balance'], // Directly from tbl_lender_loan

        'repay_duration' => $loanDetails['repay_duration'],
        'loan_type' => $loanDetails['loan_type'],
        'total_unpaid_interest' => $loanDetails['total_unpaid_interest'] // Summed unpaid interest
    ]
]);
?>
