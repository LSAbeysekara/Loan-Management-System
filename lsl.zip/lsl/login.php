<?php require('./config.php') ?>
<?php session_start(); 
if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$csrf_token = $_SESSION['csrf_token'];

$errors = array();
?>
<?php
    
    if (isset($_POST['login'])) {
        // Check if CSRF token is valid 
        if (empty($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
            
            die("CSRF token validation failed.");
        }
    
        // Check if the maximum login attempts  reach or not reach.
        if (!isset($_SESSION['login_attempts'])) {
            $_SESSION['login_attempts'] = 0;
        }
    
        $max_login_attempts = 5; 

        if ($_SESSION['login_attempts'] >= $max_login_attempts) {
            
            die("Too many failed login attempts. Please try again later.");
        }
    
        if (!isset($_POST['username']) || strlen(trim($_POST['username'])) < 1) {
            $errors[] = 'User name is Missing or Invalid';
        }
    
        if (!isset($_POST['password']) || strlen(trim($_POST['password'])) < 1) {
            $errors[] = 'Password is Missing or Invalid';
        }
    
        if (empty($errors)) {
            
            $username = mysqli_real_escape_string($conn, $_POST['username']);
            $password = mysqli_real_escape_string($conn, $_POST['password']);
    
            $hash_psw = sha1($password);
    
            $query = mysqli_query($conn, "SELECT * FROM tbl_user WHERE username = '$username' AND password = '$hash_psw' LIMIT 1");
            $num_rows = mysqli_num_rows($query);
            $row = mysqli_fetch_array($query);
    
            if ($num_rows > 0) {
                
                $_SESSION['staffname'] = $row['username'];
                $_SESSION['user_type'] = $row['user_type'];
                $_SESSION['staffid'] = $row['id'];
                header('Location: index.php');
            } else {
                
                $errors[] = 'Invalid user name or password';
                $_SESSION['login_attempts']++; 
            }
        }
    }
    
    
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <title> LSL </title>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta content="Premium Multipurpose Admin & Dashboard Template" name="description" />
    <meta content="MyraStudio" name="author" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />

    <!-- App favicon -->
    <link rel="shortcut icon" href="assets/images/favicon.ico">

    <!-- App css -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <link href="assets/css/icons.min.css" rel="stylesheet" type="text/css" />
    <link href="assets/css/theme.min.css" rel="stylesheet" type="text/css" />

</head>

<body>
 
    <div>
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="d-flex align-items-center min-vh-100">
                        <div class="w-100 d-block bg-white shadow-lg rounded my-5">
                            <div class="row">
                                <div class="col-lg-5 d-none d-lg-block bg-login rounded-left"></div>
                                <div class="col-lg-7">
                                    <div class="p-5">
                                        <div class="text-center mb-5">
                                            <a href="index.php" class="text-dark font-size-22 font-family-secondary">
                                                <!-- <i class="mdi mdi-alpha-x-circle"></i> <b>XELORO</b> -->
                                                 <img src="./assets/images/logolsl.png" height="250px">
                                            </a>
                                        </div>
                                        <h1 class="h5 mb-1">Welcome Back!</h1>
                                        <p class="text-muted mb-4">Enter your email address and password to access Dashboard.</p>
                                        <form class="user" action="#" method="post">
                                            <div class="form-group">
                                                <input type="text" class="form-control form-control-user" id="username" name="username" placeholder="Username">
                                            </div>
                                            <div class="form-group">
                                                <input type="password" class="form-control form-control-user" id="Password" name="password" placeholder="Password">
                                            </div>
                                            
                                            <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                                            <input type="submit" name="login" class="btn btn-success btn-block waves-effect waves-light" value="Log In"> 
                                        </form>


                                        <!-- end row -->
                                    </div> <!-- end .padding-5 -->
                                </div> <!-- end col -->
                            </div> <!-- end row -->
                        </div> <!-- end .w-100 -->
                    </div> <!-- end .d-flex -->
                </div> <!-- end col-->
            </div> <!-- end row -->
        </div>
        <!-- end container -->
    </div>
    <!-- end page -->

    <!-- jQuery  -->
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/metismenu.min.js"></script>
    <script src="assets/js/waves.js"></script>
    <script src="assets/js/simplebar.min.js"></script>

    <!-- App js -->
    <script src="assets/js/theme.js"></script>

</body>

</html>