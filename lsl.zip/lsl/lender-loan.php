<?php
session_start();
require('./config.php');

if (!isset($_SESSION['staffname'])) {
    echo "<script>window.location.replace('login.php');</script>";
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $lender_id = $_POST['lender_id'];
    $monthlyInterestRate = $_POST['monthly_interest_rate'];
    $requestedAmount = $_POST['requested_amount'];
    $repayDuration = $_POST['repay_duration'];
    $purpose = $_POST['purpose'];
    $loanType = $_POST['loan_type'];
    $agreedMonthlyPayment = $_POST['agreed_monthly_payment'];
    $createdBy = $_SESSION['staffname'];

    $stmt = $conn->prepare("INSERT INTO tbl_lender_loan 
        (lender_id, monthly_interest_rate, requested_amount, repay_duration, purpose, loan_type, agreed_monthly_payment, created_by)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param('iddissds', $lender_id, $monthlyInterestRate, $requestedAmount, $repayDuration, $purpose, $loanType, $agreedMonthlyPayment, $createdBy);

    if ($stmt->execute()) {
        echo json_encode(['status' => 'success']);
    } else {
        echo json_encode(['status' => 'error']);
    }
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Lender Loan Creation</title>
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.datatables.net/1.13.1/css/jquery.dataTables.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/css/select2.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.1/js/jquery.dataTables.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/js/select2.min.js"></script>
</head>

<body>
    <div class="container mt-5">
        <h2>Lender Loan Creation</h2>
        <form id="lenderLoanForm">
            <div class="form-group">
                <label for="lender_id">Select Lender</label>
                <select class="form-control select2" id="lender_id" name="lender_id" required>
                    <!-- Populate lenders -->
                </select>
            </div>
            <div class="form-group">
                <label for="monthly_interest_rate">Monthly Interest Rate</label>
                <input type="number" class="form-control" id="monthly_interest_rate" name="monthly_interest_rate" required>
            </div>
            <div class="form-group">
                <label for="requested_amount">Requested Amount</label>
                <input type="number" class="form-control" id="requested_amount" name="requested_amount" required>
            </div>
            <div class="form-group">
                <label for="repay_duration">Repay Duration (Months)</label>
                <input type="number" class="form-control" id="repay_duration" name="repay_duration" required>
            </div>
            <div class="form-group">
                <label for="purpose">Purpose</label>
                <input type="text" class="form-control" id="purpose" name="purpose" required>
            </div>
            <div class="form-group">
                <label for="loan_type">Loan Type</label>
                <select class="form-control" id="loan_type" name="loan_type" required>
                    <option value="Business">Business</option>
                    <option value="Personal">Personal</option>
                    <option value="Gold Loan">Gold Loan</option>
                    <option value="Housing Loan">Housing Loan</option>
                </select>
            </div>
            <div class="form-group">
                <label for="agreed_monthly_payment">Agreed Monthly Payment</label>
                <input type="number" class="form-control" id="agreed_monthly_payment" name="agreed_monthly_payment" required>
            </div>
            <button type="submit" class="btn btn-primary">Create Loan</button>
        </form>

        <h2 class="mt-5">Lender Loans</h2>
        <table id="lenderLoanTable" class="display">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Lender</th>
                    <th>Interest Rate</th>
                    <th>Requested Amount</th>
                    <th>Duration</th>
                    <th>Purpose</th>
                    <th>Loan Type</th>
                    <th>Agreed Payment</th>
                </tr>
            </thead>
            <tbody>
                <!-- Dynamically populated -->
            </tbody>
        </table>
    </div>

    <script>
        $(document).ready(function () {
            $('.select2').select2();
            
            // Load lenders into the dropdown
            function loadLenders() {
                $.ajax({
                    url: 'get_lenders.php',
                    method: 'POST',
                    dataType: 'json',
                    success: function (data) {
                        let lenderOptions = '';
                        data.forEach(lender => {
                            lenderOptions += `<option value="${lender.id}">${lender.lender_name} (${lender.lender_phone})</option>`;
                        });
                        $('#lender_id').html(lenderOptions);
                    }
                });
            }

            // Load lender loans into the datatable
            function loadLenderLoans() {
                $('#lenderLoanTable').DataTable({
                    ajax: {
                        url: 'get_lender_loans.php',
                        dataSrc: ''
                    },
                    columns: [
                        { data: 'id' },
                        { data: 'lender_name' },
                        { data: 'monthly_interest_rate' },
                        { data: 'requested_amount' },
                        { data: 'repay_duration' },
                        { data: 'purpose' },
                        { data: 'loan_type' },
                        { data: 'agreed_monthly_payment' }
                    ]
                });
            }

            // Call functions on page load
            loadLenders();
            loadLenderLoans();

            // Handle form submission
            $('#lenderLoanForm').on('submit', function (e) {
                e.preventDefault();
                const formData = $(this).serialize();

                $.ajax({
                    url: 'lender-loan.php',
                    method: 'POST',
                    data: formData,
                    success: function (response) {
                        const res = JSON.parse(response);
                        if (res.status === 'success') {
                            alert('Loan Created Successfully');
                            $('#lenderLoanTable').DataTable().ajax.reload();
                            $('#lenderLoanForm')[0].reset();
                            $('.select2').val(null).trigger('change');
                        } else {
                            alert('Failed to create loan');
                        }
                    }
                });
            });
        });
    </script>
</body>

</html>
