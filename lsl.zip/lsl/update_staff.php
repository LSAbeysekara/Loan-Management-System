<?php
require('./config.php');

if (isset($_POST['staffid'])) {
    $staffid = $_POST['staffid'];
    $name = $_POST['fname'];
    $username = $_POST['username'];
    $email = $_POST['email'];
    $usertype = $_POST['usertype'];
    $phone = $_POST['phone'];

    // Update query
    $query = "UPDATE tbl_user SET name = ?, username = ?, email = ?, user_type = ?, phone = ? WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('sssssi', $name, $username, $email, $usertype, $phone, $staffid);

    if ($stmt->execute()) {
        echo 'Staff details updated successfully.';
    } else {
        echo 'Error updating staff: ' . $stmt->error;
    }
}
?>
