<?php session_start(); ?>
<?php require('./config.php'); ?>

<?php if (!isset($_SESSION['staffname']) || !in_array($_SESSION['user_type'], ['admin', 'manager'])) {
    echo "<script> window.location.replace('login.php'); </script>";
    exit;
}?>

    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="utf-8" />
        <title>LSL System</title>
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta content="Premium Multipurpose Admin & Dashboard Template" name="description" />
        <meta content="MyraStudio" name="author" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />

        <!-- App favicon -->
        <link rel="shortcut icon" href="assets/images/favicon.ico">

        <!-- App css -->
        <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/icons.min.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/theme.min.css" rel="stylesheet" type="text/css" />
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/css/select2.min.css" />
        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/js/select2.min.js"></script>
        <link href="https://cdn.jsdelivr.net/npm/sweetalert2@11.7.12/dist/sweetalert2.min.css" rel="stylesheet">
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.7.12/dist/sweetalert2.all.min.js"></script>

    </head>

    <body>

        <!-- Begin page -->
        <div id="layout-wrapper">
            <?php include('header.php'); ?>
            <?php include('sidebar.php'); ?>


            <!-- ============================================================== -->
            <!-- Start right Content here -->
            <!-- ============================================================== -->
            <div class="main-content">

                <div class="page-content">
                    <div class="container-fluid">

                        <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box d-flex align-items-center justify-content-between">
                                    <h4 class="mb-0 font-size-18">Expenses</h4>

                                    <div class="page-title-right">
                                        <ol class="breadcrumb m-0">
                                            <li class="breadcrumb-item"><a href="javascript: void(0);">Transaction</a></li>

                                            <li class="breadcrumb-item active">Add Expenses</li>
                                        </ol>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- end page title -->

                        <div class="row">
                            <div class="col-12">
                                <div class="card">
                                    <div class="card-body">

                                    <h3>Cancel Records</h3>
        <form id="cancelForm">
            <div class="form-group">
                <label for="docType">Select Document Type</label>
                <select id="docType" name="docType" class="form-control select2" required>
                    <option value="">-- Select Document Type --</option>
                    <option value="tbl_expenses">Expenses</option>
                    <option value="tbl_income">Income</option>
                    <option value="tbl_payments">Payments</option>
                </select>
            </div>

            <div class="form-group">
                <label for="docId">Select Document</label>
                <select id="docId" name="docId" class="form-control select2" required>
                    <option value="">-- Select Document --</option>
                </select>
            </div>

            <button type="button" id="cancelButton" class="btn btn-danger" disabled>Cancel</button>
        </form>
                                        </form>

                                    </div> <!-- end card-body-->
                                </div> <!-- end card-->
                            </div> <!-- end col -->
                        </div>
                        <!-- end row-->

                    </div> <!-- container-fluid -->
                </div>
                <!-- End Page-content -->

                <?php include './footer.php'; ?>

            </div>
            <!-- end main content-->

        </div>
        <!-- END layout-wrapper -->

        <!-- Overlay-->
        <div class="menu-overlay"></div>

        <!-- jQuery  -->
        
        <script src="assets/js/bootstrap.bundle.min.js"></script>
        <script src="assets/js/metismenu.min.js"></script>
        <script src="assets/js/waves.js"></script>
        <script src="assets/js/simplebar.min.js"></script>

        <!-- Validation custom js-->
        <script src="assets/pages/validation-demo.js"></script>

        <!-- App js -->
        <script src="assets/js/theme.js"></script>

        <!-- Custom script -->
        <script>
        $(document).ready(function () {
            $('.select2').select2();

            // Fetch documents based on selected type
            $('#docType').change(function () {
                const docType = $(this).val();
                $('#docId').empty().append('<option value="">-- Select Document --</option>');
                if (docType) {
                    $.ajax({
                        url: 'fetch_documents.php',
                        type: 'POST',
                        data: { docType },
                        dataType: 'json',
                        success: function (data) {
                            data.forEach(doc => {
                                $('#docId').append(new Option(`${doc.id} - ${doc.amount}`, doc.id));
                            });
                        },
                        error: function () {
                            Swal.fire('Error', 'Failed to load documents.', 'error');
                        }
                    });
                }
            });

            // Enable cancel button when document is selected
            $('#docId').change(function () {
                $('#cancelButton').prop('disabled', !$(this).val());
            });

            // Handle cancel action
            $('#cancelButton').click(function () {
                const docType = $('#docType').val();
                const docId = $('#docId').val();
                if (docType && docId) {
                    Swal.fire({
                        title: 'Are you sure?',
                        text: 'Do you want to cancel this record?',
                        icon: 'warning',
                        showCancelButton: true,
                        confirmButtonText: 'Yes, cancel it!',
                        cancelButtonText: 'No, keep it'
                    }).then((result) => {
                        if (result.isConfirmed) {
                            $.ajax({
                                url: 'cancel_document.php',
                                type: 'POST',
                                data: { docType, docId },
                                dataType: 'json',
                                success: function (response) {
                                    if (response.success) {
                                        Swal.fire('Canceled!', 'The record has been canceled.', 'success');
                                        $('#docType').trigger('change');
                                    } else {
                                        Swal.fire('Error', response.error || 'Failed to cancel the record.', 'error');
                                    }
                                },
                                error: function () {
                                    Swal.fire('Error', 'Failed to process the request.', 'error');
                                }
                            });
                        }
                    });
                }
            });
        });
    </script>
    </body>

    </html>
