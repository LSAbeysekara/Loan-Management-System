<?php
require('./config.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $customerId = $_POST['id'];

    // Delete customer from the database
    $query = "DELETE FROM tbl_customer WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $customerId);

    if ($stmt->execute()) {
        echo json_encode(['status' => 'success']);
    } else {
        echo json_encode(['status' => 'error']);
    }
}
?>
