<?php session_start(); ?>
<?php require('./config.php'); ?>

<?php if (!isset($_SESSION['staffname'])) {
    echo "<script> window.location.replace('login.php'); </script>";
} else {
    if (!isset($_REQUEST['id'])) {

        echo "<script> window.location.replace('accountcatogeris.php'); </script>";
    } else {

?>

        <!DOCTYPE html>
        <html lang="en">

        <head>
            <meta charset="utf-8" />
            <title>LSL System</title>
            <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
            <meta content="Premium Multipurpose Admin & Dashboard Template" name="description" />
            <meta content="MyraStudio" name="author" />
            <meta http-equiv="X-UA-Compatible" content="IE=edge" />

            <!-- App favicon -->
            <link rel="shortcut icon" href="assets/images/favicon.ico">

            <!-- App css -->
            <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
            <link href="assets/css/icons.min.css" rel="stylesheet" type="text/css" />
            <link href="assets/css/theme.min.css" rel="stylesheet" type="text/css" />
            <link href="https://cdn.jsdelivr.net/npm/sweetalert2@11.7.12/dist/sweetalert2.min.css" rel="stylesheet">
            <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.7.12/dist/sweetalert2.all.min.js"></script>
        </head>

        <body>

            <!-- Begin page -->
            <div id="layout-wrapper">
                <?php include('header.php'); ?>
                <?php include('sidebar.php'); ?>


                <!-- ============================================================== -->
                <!-- Start right Content here -->
                <!-- ============================================================== -->
                <div class="main-content">

                    <div class="page-content">
                        <div class="container-fluid">

                            <!-- start page title -->
                            <div class="row">
                                <div class="col-12">
                                    <div class="page-title-box d-flex align-items-center justify-content-between">
                                        <h4 class="mb-0 font-size-18">Accounts Catogeries</h4>

                                        <div class="page-title-right">
                                            <ol class="breadcrumb m-0">
                                                <li class="breadcrumb-item"><a href="javascript: void(0);">Accounts Catogeries</a></li>
                                                <li class="breadcrumb-item active">Edit Accounts Catogeries</li>
                                            </ol>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- end page title -->

                            <div class="row">
                                <div class="col-12">
                                    <div class="card">
                                        <div class="card-body">

                                            <h4 class="card-title">Edit Accounts Catogeries</h4>
                                            <p class="card-subtitle mb-4">Edit Accounts Catogeries here with required details.</p>

                                            <?php
                                            $lesqlw = "SELECT * FROM `tbl_accounts_catogery` WHERE acc_id=" . $_REQUEST['id'];
                                            if ($lesqlqw = $conn->query($lesqlw)) {
                                                $rowx = $lesqlqw->fetch_assoc();
                                            } else {
                                                echo $conn->error;
                                            } ?>
                                            <form class="ml-3 mr-3" method="post" action="#" enctype="multipart/form-data">

                                                <div class="form-group row">
                                                    <label for="fname" class="col-sm-2  col-form-label">Acc. Catogery Code: </label>
                                                    <div class="col-sm-10">
                                                        <!-- <input type="text" class="form-control" id="caid" value="<?php echo $rowx['acc_id'] ?>" name="caid" style="width: 300px; " disabled> -->
                                                        <input type="text" class="form-control" id="catid" name="catid" value="<?php echo $rowx['acc_id'] ?>"
                                                            style="width: 300px;" readonly>
                                                    </div>
                                                </div>

                                                <div class="form-group row">
                                                    <label for="inputcatname" class="col-sm-2  col-form-label">Acc. Category Name: </label>
                                                    <div class="col-sm-10">
                                                        <input type="text" class="form-control" id="catname" name="catname" style="width: 500px;"
                                                            value="<?php echo $rowx['Description'] ?>">

                                                    </div>
                                                </div>

                                                <div class="form-group row">
                                                    <label for="account_type" class="col-sm-2 col-form-label">Account Type:</label>
                                                    <div class="col-sm-10">
                                                        <select class="form-control" id="account_type" name="account_type" style="width: 300px;" required>
                                                            <option value="<?php echo $rowx['account_type'] ?>"><?php echo $rowx['account_type'] ?></option>
                                                            <option value="income">Income </option>
                                                            <option value="expenses">Expenses </option>

                                                        </select>
                                                    </div>
                                                </div>

                                                <div class="form-group row">
                                                    <div class="col-sm-10">
                                                        <button type="submit" name="update" class="btn btn-primary">Update</button>
                                                    </div>
                                                </div>
                                            </form>

                                        </div> <!-- end card-body-->
                                    </div> <!-- end card-->
                                </div> <!-- end col -->
                            </div>
                            <!-- end row-->

                        </div> <!-- container-fluid -->
                    </div>
                    <!-- End Page-content -->

                    <?php include './footer.php'; ?>

                </div>
                <!-- end main content-->

            </div>
            <!-- END layout-wrapper -->

            <!-- Overlay-->
            <div class="menu-overlay"></div>

            <!-- jQuery  -->
            <script src="assets/js/jquery.min.js"></script>
            <script src="assets/js/bootstrap.bundle.min.js"></script>
            <script src="assets/js/metismenu.min.js"></script>
            <script src="assets/js/waves.js"></script>
            <script src="assets/js/simplebar.min.js"></script>

            <!-- Validation custom js-->
            <script src="assets/pages/validation-demo.js"></script>

            <!-- App js -->
            <script src="assets/js/theme.js"></script>

            <!-- Custom script -->
            <script>

            </script>
        <?php } ?>
        </body>

        </html>
    <?php
    if (isset($_POST['update'])) {
        $catname = $_POST['catname'];
        $catid = $_POST['catid'];
        $type = $_POST['account_type'];
        $current_u = $_SESSION['staffname'];

        $insert = "UPDATE tbl_accounts_catogery SET Description ='$catname' ,`account_type`='$type' , modified_by='$current_u' WHERE acc_id=$catid";
        echo $insert;
        if (mysqli_query($conn, $insert)) {
            echo "<script>
      Swal.fire({
        icon: 'success',
        title: 'Success!',
        text: 'Record has been updated successfully.',
        showConfirmButton: false,
        timer: 1500
      }).then(function() {
        window.location.href = 'accountcatogeris.php';
      });
    </script>";
        }
        mysqli_close($conn);
    }
} ?> ?>