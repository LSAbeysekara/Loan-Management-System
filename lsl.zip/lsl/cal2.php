<?php
require('./config.php');

class LoanProcessor {
    private $conn;
    private $DAYS_BETWEEN_INSTALLMENTS = 30;
    
    public function __construct($conn) {
        $this->conn = $conn;
    }
    
    // Calculate monthly installment and interest
    private function calculateMonthlyAmounts($loanAmount, $interestRate, $duration) {
        $monthlyInterest = ($loanAmount * ($interestRate / 100)) / 12;
        $principalInstallment = $loanAmount / $duration;
        return [
            'principal' => $principalInstallment,
            'interest' => $monthlyInterest
        ];
    }
    
    // Process all active loans
    public function processLoans() {
        $sql = "SELECT * FROM tbl_loan WHERE status = 'Active'";
        $result = $this->conn->query($sql);
        
        while ($loan = $result->fetch_assoc()) {
            $this->processLoan($loan);
        }
    }
    
    // Process individual loan
    private function processLoan($loan) {
        // Calculate initial amounts
        $amounts = $this->calculateMonthlyAmounts(
            $loan['requested_amount'],
            $loan['monthly_interest_rate'],
            $loan['repay_duration']
        );
        
        // Create first installment if not exists
        $this->createFirstInstallment($loan, $amounts);
        
        // Process existing installments
        $this->processInstallments($loan, $amounts);
        
        // Check for warnings
        $this->processWarnings($loan);
    }
    
    // Create first installment if not exists
    private function createFirstInstallment($loan, $amounts) {
        $firstDueDate = date('Y-m-d', strtotime($loan['create_date'] . " +{$this->DAYS_BETWEEN_INSTALLMENTS} days"));
        
        $sql = "SELECT id FROM tbl_installments WHERE loan_id = ? AND due_date = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("is", $loan['id'], $firstDueDate);
        $stmt->execute();
        
        if ($stmt->get_result()->num_rows === 0) {
            // Insert principal installment
            $stmt = $this->conn->prepare("
                INSERT INTO tbl_installments (loan_id, installment_amount, due_date)
                VALUES (?, ?, ?)
            ");
            $stmt->bind_param("ids", $loan['id'], $amounts['principal'], $firstDueDate);
            $stmt->execute();
            
            // Insert corresponding interest
            $stmt = $this->conn->prepare("
                INSERT INTO tbl_loan_interest (loan_id, interest_amount, payment_date, created_by)
                VALUES (?, ?, ?, 0)
            ");
            $stmt->bind_param("ids", $loan['id'], $amounts['interest'], $firstDueDate);
            $stmt->execute();
        }
    }
    
    // Process existing installments
    private function processInstallments($loan, $amounts) {
        $sql = "SELECT i.*, li.interest_amount, li.id as interest_id, 
                COALESCE(SUM(p.payment_amount), 0) as total_payments
                FROM tbl_installments i
                LEFT JOIN tbl_loan_interest li ON li.loan_id = i.loan_id 
                    AND DATE(li.payment_date) = i.due_date
                LEFT JOIN tbl_payments p ON p.loan_id = i.loan_id 
                    AND DATE(p.payment_date) <= i.due_date
                WHERE i.loan_id = ? AND i.status = 'Pending' 
                AND i.due_date <= CURDATE()
                GROUP BY i.id";
                
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("i", $loan['id']);
        $stmt->execute();
        $result = $stmt->get_result();
        
        while ($installment = $result->fetch_assoc()) {
            $this->processInstallmentPayment(
                $loan,
                $installment,
                $amounts['interest']
            );
        }
    }
    
    // Process individual installment payment
    private function processInstallmentPayment($loan, $installment, $currentInterest) {
        $totalDue = $installment['installment_amount'] + 
                   ($installment['interest_amount'] ?? $currentInterest);
        
        if ($installment['total_payments'] >= $totalDue) {
            // Payment completed
            $this->updateLoanBalance($loan['id'], $installment['installment_amount']);
            $this->markInstallmentPaid($installment['id']);
            
            // Create next installment if needed
            $nextDueDate = date('Y-m-d', strtotime($installment['due_date'] . " +{$this->DAYS_BETWEEN_INSTALLMENTS} days"));
            if (strtotime($nextDueDate) <= strtotime(date('Y-m-d'))) {
                $this->createNextInstallment($loan['id'], $nextDueDate);
            }
        }
    }
    
    // Update loan balance
    private function updateLoanBalance($loanId, $amount) {
        $sql = "UPDATE tbl_loan SET 
                requested_amount = requested_amount - ?,
                modified_date = CURRENT_TIMESTAMP
                WHERE id = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("di", $amount, $loanId);
        $stmt->execute();
    }
    
    // Mark installment as paid
    private function markInstallmentPaid($installmentId) {
        $sql = "UPDATE tbl_installments SET status = 'Paid' WHERE id = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("i", $installmentId);
        $stmt->execute();
    }
    
    // Create next installment
    private function createNextInstallment($loanId, $dueDate) {
        $sql = "SELECT * FROM tbl_loan WHERE id = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("i", $loanId);
        $stmt->execute();
        $loan = $stmt->get_result()->fetch_assoc();
        
        if ($loan && $loan['requested_amount'] > 0) {
            $amounts = $this->calculateMonthlyAmounts(
                $loan['requested_amount'],
                $loan['monthly_interest_rate'],
                $loan['repay_duration']
            );
            
            $this->createFirstInstallment($loan, $amounts);
        }
    }
    
    // Process warnings for overdue payments
    private function processWarnings($loan) {
        $sql = "SELECT COUNT(*) as overdue_count 
                FROM tbl_installments 
                WHERE loan_id = ? AND status = 'Pending' 
                AND due_date < CURDATE()";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("i", $loan['id']);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();
        
        if ($result['overdue_count'] > 0) {
            $this->issueWarning($loan['id'], $loan['customer_id']);
        }
    }
    
    // Issue appropriate warning
    private function issueWarning($loanId, $customerId) {
        $sql = "SELECT COUNT(*) as warning_count 
                FROM tbl_warning_letters 
                WHERE loan_id = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("i", $loanId);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();
        
        $warningType = $this->getWarningType($result['warning_count']);
        if ($warningType) {
            $sql = "INSERT INTO tbl_warning_letters 
                    (customer_id, loan_id, warning_type, issued_date, created_by) 
                    VALUES (?, ?, ?, CURDATE(), 0)";
            $stmt = $this->conn->prepare($sql);
            $stmt->bind_param("iis", $customerId, $loanId, $warningType);
            $stmt->execute();
        }
    }
    
    // Get appropriate warning type
    private function getWarningType($warningCount) {
        switch ($warningCount) {
            case 0: return 'first';
            case 1: return 'second';
            case 2: return 'final';
            default: return null;
        }
    }
    
    // Manager's interest waiver function
    public function waiveInterest($loanId, $interestId, $amount, $managerId) {
        // Verify manager permissions
        $sql = "SELECT user_type FROM tbl_user WHERE id = ? AND user_type = 'Manager'";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("i", $managerId);
        $stmt->execute();
        
        if ($stmt->get_result()->num_rows === 0) {
            return false;
        }
        
        // Update interest amount
        $sql = "UPDATE tbl_loan_interest 
                SET interest_amount = interest_amount - ?,
                    modified_by = ?,
                    modified_date = CURRENT_TIMESTAMP
                WHERE id = ? AND loan_id = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("diii", $amount, $managerId, $interestId, $loanId);
        return $stmt->execute();
    }
}

// Create processor instance and run
$processor = new LoanProcessor($conn);
$processor->processLoans();
?>