<?php
require('./config.php'); // Database connection

function calculateInterest($conn) {
    $today = date('Y-m-d');

    // Fetch all active loans with balance > 0
    $sql = "SELECT id, requested_amount, monthly_interest_rate, create_date 
            FROM tbl_lender_loan 
            WHERE balance > 0";

    $result = $conn->query($sql);

    while ($row = $result->fetch_assoc()) {
        $loanId = $row['id'];
        $balance = $row['requested_amount'];
        $interestRate = $row['monthly_interest_rate'];
        $createDate = $row['create_date'];

        // Calculate the number of 30-day cycles since loan creation
        $daysDiff = (strtotime($today) - strtotime($createDate)) / (60 * 60 * 24);
        $cycles = floor($daysDiff / 30);

        // Fetch the last interest calculation date
        $lastInterestDateSql = "SELECT MAX(interest_date) AS last_interest_date 
                                FROM tbl_lender_interest 
                                WHERE lender_loan_id = ?";
        $stmt = $conn->prepare($lastInterestDateSql);
        $stmt->bind_param('i', $loanId);
        $stmt->execute();
        $lastInterestDateResult = $stmt->get_result()->fetch_assoc();
        $lastInterestDate = $lastInterestDateResult['last_interest_date'] ?? $createDate;

        // Calculate interest for missing cycles
        while ($cycles > 0) {
            $nextInterestDate = date('Y-m-d', strtotime($lastInterestDate . ' +30 days'));
            if (strtotime($nextInterestDate) > strtotime($today)) {
                break;
            }

            // Calculate interest for this cycle
            $interestAmount = $balance * ($interestRate / 100);

            // Insert into tbl_lender_interest
            $insertSql = "INSERT INTO tbl_lender_interest 
                          (lender_loan_id, interest_amount, interest_date) 
                          VALUES (?, ?, ?)";
            $insertStmt = $conn->prepare($insertSql);
            $insertStmt->bind_param('ids', $loanId, $interestAmount, $nextInterestDate);
            $insertStmt->execute();

            // Update balance in tbl_lender_loan
            $updateSql = "UPDATE tbl_lender_loan 
                          SET balance = balance + ? 
                          WHERE id = ?";
            $updateStmt = $conn->prepare($updateSql);
            $updateStmt->bind_param('di', $interestAmount, $loanId);
            $updateStmt->execute();

            // Update lastInterestDate and decrement cycles
            $lastInterestDate = $nextInterestDate;
            $cycles--;
        }
    }
}

calculateInterest($conn);
?>
