<?php session_start(); ?>
<?php require('./config.php'); ?>
<?php
if (!isset($_SESSION['staffname'])) {
    echo "<script> window.location.replace('login.php'); </script>";
} else { ?>
    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="utf-8" />
        <title>Add Customer</title>
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta content="Customer Management System" name="description" />
        <meta content="MyraStudio" name="author" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />

        <!-- App css -->
        <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/icons.min.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/theme.min.css" rel="stylesheet" type="text/css" />

        <!-- SweetAlert2 -->
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
    </head>

    <body>

        <div id="layout-wrapper">
            <?php include('header.php'); ?>
            <?php include('sidebar.php'); ?>

            <div class="main-content">
                <div class="page-content">
                    <div class="container-fluid">

                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box d-flex align-items-center justify-content-between">
                                    <h4 class="mb-0 font-size-18">Add Customer</h4>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-12">
                                <div class="card">
                                    <div class="card-body">
                                        <h4 class="card-title">New Customer</h4>
                                        <p class="card-subtitle mb-4">Fill in the required fields to add a new customer.</p>

                                        <form class="form-horizontal" id="addCustomerForm" enctype="multipart/form-data">
                                            <div class="form-group row mb-3">
                                                <label for="full_name" class="col-3 col-form-label">Full Name</label>
                                                <div class="col-9">
                                                    <input type="text" class="form-control" id="full_name" name="full_name" required>
                                                </div>
                                            </div>

                                            <!-- <div class="form-group row mb-3">
                                            <label for="membership_number" class="col-3 col-form-label">Membership Number</label>
                                            <div class="col-9">
                                                <input type="text" class="form-control" id="membership_number" name="membership_number" readonly value="<?php // echo generateMembershipNumber($conn); 
                                                                                                                                                        ?>">
                                            </div>
                                        </div> -->

                                            <div class="form-group row mb-3">
                                                <label for="name_with_initials" class="col-3 col-form-label">Name with Initials</label>
                                                <div class="col-9">
                                                    <input type="text" class="form-control" id="name_with_initials" name="name_with_initials" required>
                                                </div>
                                            </div>

                                            <div class="form-group row mb-3">
                                                <label for="nic_no" class="col-3 col-form-label">NIC No</label>
                                                <div class="col-9">
                                                    <input type="text" class="form-control" id="nic_no" name="nic_no" required>
                                                    <span id="nicStatus"></span>
                                                </div>
                                            </div>

                                            <div class="form-group row mb-3">
                                                <label for="postal_address" class="col-3 col-form-label">Postal Address</label>
                                                <div class="col-9">
                                                    <textarea class="form-control" id="postal_address" name="postal_address" required></textarea>
                                                </div>
                                            </div>

                                            <div class="form-group row mb-3">
                                                <label for="job_position" class="col-3 col-form-label">Job/Position</label>
                                                <div class="col-9">
                                                    <input type="text" class="form-control" id="job_position" name="job_position">
                                                </div>
                                            </div>

                                            <div class="form-group row mb-3">
                                                <label for="job_address" class="col-3 col-form-label">Job Address</label>
                                                <div class="col-9">
                                                    <textarea class="form-control" id="job_address" name="job_address"></textarea>
                                                </div>
                                            </div>

                                            <div class="form-group row mb-3">
                                                <label for="fixed_phone" class="col-3 col-form-label">Fixed Phone Number</label>
                                                <div class="col-9">
                                                    <input type="text" class="form-control" id="fixed_phone" name="fixed_phone">
                                                </div>
                                            </div>

                                            <div class="form-group row mb-3">
                                                <label for="mobile_phone" class="col-3 col-form-label">Mobile Phone Number</label>
                                                <div class="col-9">
                                                    <input type="text" class="form-control" id="mobile_phone" name="mobile_phone" required>
                                                    <span id="phoneStatus"></span>
                                                </div>
                                            </div>

                                            <div class="form-group row mb-3">
                                                <label for="marital_status" class="col-3 col-form-label">Marital Status</label>
                                                <div class="col-9">
                                                    <label class="radio-inline"><input type="radio" name="marital_status" value="Single" checked> Single</label>
                                                    <label class="radio-inline ml-3"><input type="radio" name="marital_status" value="Married"> Married</label>
                                                </div>
                                            </div>

                                            <div id="spouseDetails" style="display: none;">
                                                <div class="form-group row mb-3">
                                                    <label for="spouse_name" class="col-3 col-form-label">Spouse Name</label>
                                                    <div class="col-9">
                                                        <input type="text" class="form-control" id="spouse_name" name="spouse_name">
                                                    </div>
                                                </div>

                                                <div class="form-group row mb-3">
                                                    <label for="spouse_job" class="col-3 col-form-label">Spouse Job</label>
                                                    <div class="col-9">
                                                        <input type="text" class="form-control" id="spouse_job" name="spouse_job">
                                                    </div>
                                                </div>

                                                <div class="form-group row mb-3">
                                                    <label for="spouse_phone" class="col-3 col-form-label">Spouse Phone Number</label>
                                                    <div class="col-9">
                                                        <input type="text" class="form-control" id="spouse_phone" name="spouse_phone">
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="form-group row mb-3">
                                                <label for="nic_document" class="col-3 col-form-label">NIC Document</label>
                                                <div class="col-9">
                                                    <input type="file" class="form-control" id="nic_document" name="nic_document">
                                                </div>
                                            </div>

                                            <div class="form-group mb-0 justify-content-end row">
                                                <div class="col-9">
                                                    <button type="submit" class="btn btn-info waves-effect waves-light">Save</button>
                                                </div>
                                            </div>
                                        </form>

                                    </div> <!-- end card-body -->
                                </div> <!-- end card -->
                            </div> <!-- end col -->
                        </div> <!-- end row -->

                    </div> <!-- container-fluid -->
                </div> <!-- End Page-content -->
            </div> <!-- end main content -->
        </div> <!-- END layout-wrapper -->

        <!-- jQuery  -->
        <script src="assets/js/jquery.min.js"></script>
        <script src="assets/js/bootstrap.bundle.min.js"></script>
        <script src="assets/js/waves.js"></script>
        <script src="assets/js/simplebar.min.js"></script>

        <!-- SweetAlert2 -->
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

        <!-- App js -->
        <script src="assets/js/theme.js"></script>

        <script>
            $(document).ready(function() {
                // Show/Hide spouse details based on marital status
                $("input[name='marital_status']").change(function() {
                    if ($(this).val() == "Married") {
                        $("#spouseDetails").show();
                    } else {
                        $("#spouseDetails").hide();
                    }
                });

                // AJAX check for existing NIC and Phone
                $("#nic_no").on('blur', function() {
                    var nic = $(this).val();
                    $.ajax({
                        url: 'check_customer.php',
                        method: 'POST',
                        data: {
                            nic_no: $('#nic_no').val(), // or mobile_phone: $('#mobile_phone').val()
                        },
                        success: function(response) {
                            let res = JSON.parse(response);
                            if (res.status === 'error') {
                                // If duplicate found, show the message in red
                                $('#nicStatus').html(res.message).css('color', 'red');
                            } else {
                                // No duplicate found, clear the message
                                $('#nicStatus').html('');
                            }
                        }
                    });
                });

                $("#mobile_phone").on('blur', function() {
                    var phone = $(this).val();
                    $.ajax({
                        url: 'check_customer.php',
                        method: 'POST',
                        data: {
                            mobile_phone: $('#mobile_phone').val(), // or mobile_phone: $('#mobile_phone').val()
                        },
                        success: function(response) {
                            let res = JSON.parse(response);
                            if (res.status === 'error') {
                                // If duplicate found, show the message in red
                                $('#phoneStatus').html(res.message).css('color', 'red');
                            } else {
                                // No duplicate found, clear the message
                                $('#phoneStatus').html('');
                            }
                        }
                    });

                });

                // Handle form submission
                $("#addCustomerForm").on('submit', function(e) {
                    e.preventDefault();

                    var formData = new FormData(this);
                    $.ajax({
                        url: "save_customer.php",
                        method: "POST",
                        data: formData,
                        contentType: false,
                        processData: false,
                        success: function(response) {
                            var result = JSON.parse(response);
                            if (result.status === 'success') {
                                Swal.fire({
                                    title: 'Success!',
                                    text: 'Customer has been added successfully!',
                                    icon: 'success',
                                    confirmButtonText: 'OK'
                                }).then((result) => {
                                    if (result.isConfirmed) {
                                        window.location.href = "customer_list.php";
                                    }
                                });
                            } else {
                                Swal.fire({
                                    title: 'Error!',
                                    text: result.message,
                                    icon: 'error',
                                    confirmButtonText: 'OK'
                                });
                            }
                        }
                    });
                });
            });
        </script>

    </body>

    </html>
<?php } ?>