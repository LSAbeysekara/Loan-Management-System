<?php
require('./config.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $docType = $_POST['docType'];
    $tableFields = [
        'tbl_expenses' => ['id' => 'exp_id', 'amount' => 'amount'],
        'tbl_income' => ['id' => 'income_id', 'amount' => 'amount'],
        'tbl_payments' => ['id' => 'id', 'amount' => 'amount_paid']
    ];
    $stoday=date('Y-m-d') .' 00:00:00.000000';
    $etoday = date('Y-m-d') .' 23:59:59.000000';
    // echo $stoday;
    // echo $etoday;
    if (isset($tableFields[$docType])) {
        $fields = $tableFields[$docType];
        $query = "SELECT {$fields['id']} AS id, {$fields['amount']} AS amount FROM $docType WHERE status != 'cancel' && create_date between '$stoday' and '$etoday'";
        $result = $conn->query($query);
        $data = $result->fetch_all(MYSQLI_ASSOC);
        echo json_encode($data);
    } else {
        echo json_encode([]);
    }
}
