<?php session_start(); ?>
<?php require('./config.php'); ?>

<?php if (!isset($_SESSION['staffname'])) {
  echo "<script> window.location.replace('login.php'); </script>";
} ?>

<?php

$staffname = $_SESSION['staffname'];

if ($_POST['action'] === 'load_customers') {
    $search = isset($_POST['search']) ? '%' . $_POST['search'] . '%' : '%';
    $stmt = $conn->prepare("SELECT id, full_name FROM tbl_customer WHERE full_name LIKE ?");
    $stmt->bind_param('s', $search);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $customers = [];
    while ($row = $result->fetch_assoc()) {
        $customers[] = $row;
    }
    
    echo json_encode($customers);
    exit;
}

if ($_POST['action'] === 'load_pending') {
    $customerId = $_POST['customer_id'];

    // Modified SQL query to show all installments and interest amounts > 0
    $sql = "
        SELECT 
            type,
            amount,
            id,
            payment_st_date,
            payment_end_date,
            record_order
        FROM (
            SELECT 
                'Installment' AS type,
                ti.installment_amount AS amount,
                ti.id,
                ti.payment_st_date,
                ti.payment_end_date,
                1 as record_order
            FROM tbl_installments ti
            JOIN tbl_loan tl ON ti.loan_id = tl.id
            WHERE tl.customer_id = $customerId 
            AND ti.installment_amount > 0

            UNION ALL

            SELECT 
                'Interest' AS type,
                tli.balance_interest AS amount,
                tli.id,
                tli.payment_st_date,
                tli.payment_end_date,
                2 as record_order
            FROM tbl_loan_interest tli
            JOIN tbl_loan tl ON tli.loan_id = tl.id
            WHERE tl.customer_id = $customerId 
            AND tli.balance_interest > 0
        ) combined_records
        ORDER BY payment_st_date, record_order;
    ";

    $result = $conn->query($sql);
    
    if (!$result) {
        echo json_encode(['error' => $conn->error]);
        exit;
    }

    $records = [];
    $currentPeriod = null;
    $periodRecords = [];

    while ($row = $result->fetch_assoc()) {
        $period = $row['payment_st_date'] . ' to ' . $row['payment_end_date'];
        
        if ($currentPeriod !== $period) {
            if (!empty($periodRecords)) {
                $records[] = [
                    'period' => $currentPeriod,
                    'records' => $periodRecords
                ];
                $periodRecords = [];
            }
            $currentPeriod = $period;
        }

        $periodRecords[] = [
            'type' => $row['type'],
            'amount' => $row['amount'],
            'id' => $row['id']
        ];
    }

    if (!empty($periodRecords)) {
        $records[] = [
            'period' => $currentPeriod,
            'records' => $periodRecords
        ];
    }

    echo json_encode($records);
    exit;
}


// if ($_POST['action'] === 'load_pending') {
//     $customerId = $_POST['customer_id'];

//     // Simplified SQL query without JSON functions
//     $sql = "
//         SELECT 
//             type,
//             amount,
//             id,
//             payment_st_date,
//             payment_end_date,
//             record_order
//         FROM (
//             SELECT 
//                 'Installment' AS type,
//                 ti.installment_amount AS amount,
//                 ti.id,
//                 ti.payment_st_date,
//                 ti.payment_end_date,
//                 1 as record_order
//             FROM tbl_installments ti
//             JOIN tbl_loan tl ON ti.loan_id = tl.id
//             WHERE tl.customer_id = $customerId 
//             AND ti.status = 'Pending'

//             UNION ALL

//             SELECT 
//                 'Interest' AS type,
//                 tli.balance_interest AS amount,
//                 tli.id,
//                 tli.payment_st_date,
//                 tli.payment_end_date,
//                 2 as record_order
//             FROM tbl_loan_interest tli
//             JOIN tbl_loan tl ON tli.loan_id = tl.id
//             WHERE tl.customer_id = $customerId 
//             AND tli.balance_interest > 0 
//             AND tli.status = 'Pending'
//         ) combined_records
//         ORDER BY payment_st_date, record_order;
//     ";

//     $result = $conn->query($sql);
    
//     if (!$result) {
//         echo json_encode(['error' => $conn->error]);
//         exit;
//     }

//     $records = [];
//     $currentPeriod = null;
//     $periodRecords = [];

//     while ($row = $result->fetch_assoc()) {
//         $period = $row['payment_st_date'] . ' to ' . $row['payment_end_date'];
        
//         if ($currentPeriod !== $period) {
//             if (!empty($periodRecords)) {
//                 $records[] = [
//                     'period' => $currentPeriod,
//                     'records' => $periodRecords
//                 ];
//                 $periodRecords = [];
//             }
//             $currentPeriod = $period;
//         }

//         $periodRecords[] = [
//             'type' => $row['type'],
//             'amount' => $row['amount'],
//             'id' => $row['id']
//         ];
//     }

//     if (!empty($periodRecords)) {
//         $records[] = [
//             'period' => $currentPeriod,
//             'records' => $periodRecords
//         ];
//     }

//     echo json_encode($records);
//     exit;
// }



if ($_POST['action'] === 'validate_manager_password') {
    $password = $_POST['password'];
    $hashedPassword = sha1($password); // Hash the entered password

    $sql = "SELECT username FROM tbl_user WHERE user_type = 'Manager' AND password = '$hashedPassword'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        echo json_encode(['status' => 'success', 'username' => $row['username']]);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Invalid manager password']);
    }
    exit;
}

// Add this new handler to get original interest amount
if ($_POST['action'] === 'get_original_interest') {
    try {
        $recordId = filter_input(INPUT_POST, 'record_id', FILTER_SANITIZE_NUMBER_INT);
        
        // Get the ORIGINAL interest amount from database
        $stmt = $conn->prepare("
            SELECT COALESCE(
                (SELECT interest_amount FROM tbl_loan_interest WHERE id = ?),
                (SELECT balance_interest FROM tbl_loan_interest WHERE id = ?)
            ) as original_amount
        ");
        $stmt->bind_param('ii', $recordId, $recordId);
        
        if (!$stmt->execute()) {
            throw new Exception('Failed to fetch interest amount');
        }
        
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();
        
        echo json_encode([
            'status' => 'success',
            'original_amount' => $row['original_amount']
        ]);

    } catch (Exception $e) {
        echo json_encode([
            'status' => 'error',
            'message' => $e->getMessage()
        ]);
    }
    exit;
}

if ($_POST['action'] === 'process_interest_reduction') {
    try {
        $conn->begin_transaction();
 
        $recordId = filter_input(INPUT_POST, 'record_id', FILTER_SANITIZE_NUMBER_INT);
        $originalDbAmount = filter_input(INPUT_POST, 'original_db_amount', FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);
        $newAmount = filter_input(INPUT_POST, 'new_amount', FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);
        $managerUsername = isset($_POST['manager_username']) ? $_POST['manager_username'] : 'Unknown Manager';
 
        // First, get the original amount and loan_id from the database
        $stmt = $conn->prepare("SELECT interest_amount, balance_interest, loan_id FROM tbl_loan_interest WHERE id = ?");
        $stmt->bind_param('i', $recordId);
       
        if (!$stmt->execute()) {
            throw new Exception('Failed to fetch original amounts');
        }
       
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();
        $loanId = $row['loan_id']; // Get the loan_id
       
        // Compare balance_interest with new amount
        $currentBalance = floatval($row['balance_interest']);
        $reducedAmount = $currentBalance - floatval($newAmount);
 
        // Get current date and time in Sri Lanka timezone
        date_default_timezone_set('Asia/Colombo');
        $currentDateTime = date('Y-m-d H:i:s');
 
        // Only insert into expenses if there is an actual reduction
        if ($reducedAmount > 0.01) { // Using 0.01 to handle floating point precision
            
            // Insert into expenses table with the loan_id included
            $expDesc = "Interest reduction approved by manager: $managerUsername - Original Amount: $currentBalance, Reduced to: $newAmount";
            $stmt = $conn->prepare("INSERT INTO tbl_expenses (exp_desc, amount, create_date, loan_id) VALUES (?, ?, ?, ?)");
            $stmt->bind_param('sdsi', $expDesc, $reducedAmount, $currentDateTime, $loanId);
           
            if (!$stmt->execute()) {
                throw new Exception('Failed to record expense: ' . $stmt->error);
            }
        }
 
        // Update interest balance in tbl_loan_interest
        $stmt = $conn->prepare("UPDATE tbl_loan_interest SET balance_interest = ? WHERE id = ?");
        $stmt->bind_param('di', $newAmount, $recordId);
       
        if (!$stmt->execute()) {
            throw new Exception('Failed to update interest balance: ' . $stmt->error);
        }

        // Update loan_balance 
        $stmt = $conn->prepare("UPDATE tbl_loan SET loan_balance = loan_balance - ? WHERE id = ?");
        $stmt->bind_param('di', $reducedAmount, $loanId);
       
        if (!$stmt->execute()) {
            throw new Exception('Failed to update interest balance: ' . $stmt->error);
        }
 
        $conn->commit();
       
        echo json_encode([
            'status' => 'success',
            'message' => 'Interest reduction processed successfully',
            'reduced_amount' => number_format($reducedAmount, 2)
        ]);
 
    } catch (Exception $e) {
        $conn->rollback();
        echo json_encode([
            'status' => 'error',
            'message' => $e->getMessage()
        ]);
    }
    exit;
}

if ($_POST['action'] === 'update_interest_amount') {
    try {
        $recordId = filter_input(INPUT_POST, 'record_id', FILTER_SANITIZE_NUMBER_INT);
        $newAmount = filter_input(INPUT_POST, 'new_amount', FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);

        // Update interest balance in tbl_loan_interest
        $stmt = $conn->prepare("UPDATE tbl_loan_interest SET balance_interest = ? WHERE id = ?");
        $stmt->bind_param('di', $newAmount, $recordId);
        
        if (!$stmt->execute()) {
            throw new Exception('Failed to update interest amount: ' . $stmt->error);
        }

        echo json_encode([
            'status' => 'success',
            'message' => 'Interest amount updated successfully'
        ]);

    } catch (Exception $e) {
        echo json_encode([
            'status' => 'error',
            'message' => $e->getMessage()
        ]);
    }
    exit;
}


if ($_POST['action'] === 'process_payment') {
    try {
        $conn->begin_transaction();
        
        $customerId = filter_input(INPUT_POST, 'customer_id', FILTER_SANITIZE_NUMBER_INT);
        if (!$customerId) {
            throw new Exception('Invalid customer ID');
        }

        $selectedRecords = json_decode($_POST['selected_records'], true);
        if (empty($selectedRecords)) {
            throw new Exception('No records selected for payment');
        }

        // Get loan ID from first record
        $firstRecord = $selectedRecords[0];
        $recordType = $firstRecord['type'];
        
        $tableName = ($recordType === 'Installment') ? 'tbl_installments' : 'tbl_loan_interest';
        $stmt = $conn->prepare("SELECT loan_id FROM $tableName WHERE id = ?");
        $stmt->bind_param('i', $firstRecord['id']);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows === 0) {
            throw new Exception('Invalid record ID');
        }
        
        $row = $result->fetch_assoc();
        $loanId = $row['loan_id'];
        
        // Process payment
        $amountPaid = filter_input(INPUT_POST, 'repayment_amount', FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);
        $paymentMethod = filter_input(INPUT_POST, 'payment_method', FILTER_SANITIZE_STRING);
        $manager_username = $_POST['manager_username'] ?? null;
        
        // Insert payment record
        $stmt = $conn->prepare("
            INSERT INTO tbl_payments (
                loan_id, customer_id, amount_paid, payment_method, 
                manager_approval, created_by, create_date, status
            ) VALUES (?, ?, ?, ?, ?, ?, NOW(), 'Paid')
        ");
        $stmt->bind_param('iidsss', $loanId, $customerId, $amountPaid, 
                         $paymentMethod, $manager_username, $staffname);

        if (!$stmt->execute()) {
            throw new Exception('Failed to record payment: ' . $stmt->error);
        }
        
        $paymentId = $conn->insert_id;

        // Update records and handle reductions
        foreach ($selectedRecords as $record) {
            if ($record['type'] === 'Installment') {
                // For installments
                if (isset($record['remainingAmount'])) {
                    // Update the installment_amount with the remaining amount
                    $stmt = $conn->prepare("
                        UPDATE tbl_installments 
                        SET status = 'Paid',
                            installment_amount = ?
                        WHERE id = ? AND loan_id = ?
                    ");
                    $stmt->bind_param('dii', $record['remainingAmount'], $record['id'], $loanId);
                } else {
                    // If no reduction, mark as paid and set installment_amount to 0
                    // since the full amount is being paid
                    $zero = 0;
                    $stmt = $conn->prepare("
                        UPDATE tbl_installments 
                        SET status = 'Paid',
                            installment_amount = ?
                        WHERE id = ? AND loan_id = ?
                    ");
                    $stmt->bind_param('dii', $zero, $record['id'], $loanId);
                }
            } else {
                // For interest payments
                if (isset($record['remainingAmount'])) {
                    $stmt = $conn->prepare("
                        UPDATE tbl_loan_interest 
                        SET status = 'Paid',
                            balance_interest = ?
                        WHERE id = ? AND loan_id = ?
                    ");
                    $stmt->bind_param('dii', $record['remainingAmount'], $record['id'], $loanId);
                } else {
                    $stmt = $conn->prepare("
                        UPDATE tbl_loan_interest 
                        SET status = 'Paid',
                            balance_interest = 0
                        WHERE id = ? AND loan_id = ?
                    ");
                    $stmt->bind_param('ii', $record['id'], $loanId);
                }
            }
            
            if (!$stmt->execute()) {
                throw new Exception('Failed to update record: ' . $stmt->error . ' SQL: ' . $stmt->sqlstate);
            }
        }

        // Update loan balance
        $stmt = $conn->prepare("
            UPDATE tbl_loan 
            SET loan_balance = loan_balance - ?,
                last_payment_date = NOW(),
                last_installment_amount = ?,
                letter_count = 0
            WHERE id = ?
        ");
        $stmt->bind_param('ddi', $amountPaid, $amountPaid, $loanId);
        
        if (!$stmt->execute()) {
            throw new Exception('Failed to update loan balance: ' . $stmt->error);
        }

                // Fetch customer details for SMS
        $customerStmt = $conn->prepare("SELECT name_with_initials, mobile_phone FROM tbl_customer WHERE id = ?");
        $customerStmt->bind_param('i', $customerId);
        $customerStmt->execute();
        $customerResult = $customerStmt->get_result();
        
        if ($customerResult->num_rows === 0) {
            throw new Exception('Customer not found');
        }
        
        $customerData = $customerResult->fetch_assoc();
        
        // Format message for SMS
        $message = "Dear {$customerData['name_with_initials']}, Thank you for your payment of Rs. " . 
                  number_format($amountPaid, 2) . ". We appreciate your prompt payment.";
        
        // Set timezone to Sri Lanka
        date_default_timezone_set('Asia/Colombo');
        $currentDateTime = date('Y-m-d H:i:s');
        
        // Insert SMS record
        $smsStmt = $conn->prepare("
            INSERT INTO tbl_sms (message, SMS_type, status, date_time, phoneNo) 
            VALUES (?, 'payment', 'pending', ?, ?)
        ");
        
        $smsStmt->bind_param('sss', 
            $message,
            $currentDateTime,
            $customerData['mobile_phone']
        );
        
        if (!$smsStmt->execute()) {
            throw new Exception('Failed to create SMS record: ' . $smsStmt->error);
        }

        // Commit transaction
        $conn->commit();
        
        echo json_encode([
            'status' => 'success',
            'message' => 'Payment processed successfully',
            'paymentId' => $paymentId  // Add payment ID to response
        ]);

        
    } catch (Exception $e) {
        // Rollback transaction on error
        $conn->rollback();
        
        echo json_encode([
            'status' => 'error',
            'message' => $e->getMessage()
        ]);
    }
    exit;
}
?>
