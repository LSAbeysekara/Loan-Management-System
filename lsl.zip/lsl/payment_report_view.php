<?php
session_start();
require('./config.php');

if (!isset($_SESSION['staffname'])) {
    echo "<script>window.location.replace('login.php');</script>";
    exit;
}

// Get date range from GET parameters
$start_date = $_GET['start_date'] ?? date('Y-m-d');
$end_date = $_GET['end_date'] ?? date('Y-m-d');

// Modified query without staff table join
$payments_query = "
    SELECT 
        p.*,
        c.full_name as customer_name,
        l.requested_amount as loan_amount
    FROM tbl_payments p
    JOIN tbl_customer c ON p.customer_id = c.id
    JOIN tbl_loan l ON p.loan_id = l.id
    WHERE p.status = 'Paid'
    AND DATE(p.create_date) BETWEEN ? AND ?
    ORDER BY p.create_date DESC";

$stmt = $conn->prepare($payments_query);
$stmt->bind_param("ss", $start_date, $end_date);
$stmt->execute();
$result = $stmt->get_result();

// Calculate totals
$total_amount = 0;
$total_interest = 0;

// Store all results in an array for later use
$all_payments = [];
while ($row = $result->fetch_assoc()) {
    $all_payments[] = $row;
    $total_amount += $row['amount_paid'];
    $total_interest += $row['interest_paid'];
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Report</title>

    <!-- CSS -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/icons.min.css" rel="stylesheet">
    <link href="assets/css/theme.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css">
    <link rel="stylesheet" type="text/css"
        href="https://cdn.datatables.net/buttons/2.2.2/css/buttons.dataTables.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css" />

    <style>
        .filter-card {
            background-color: #f8f9fa;
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 20px;
        }

        .total-card {
            background-color: #4B49AC;
            color: white;
            border-radius: 8px;
            padding: 15px;
            margin-bottom: 20px;
        }

        .total-label {
            font-size: 0.9em;
            opacity: 0.9;
        }

        .total-value {
            font-size: 1.5em;
            font-weight: 600;
        }

        .method-badge {
            padding: 5px 10px;
            border-radius: 4px;
            font-size: 0.85em;
        }

        .method-cash {
            background-color: #d4edda;
            color: #155724;
        }

        .method-bank {
            background-color: #cce5ff;
            color: #1976d2;
        }

        .btn .btn-primary .btn-sm .mr-2 {
            background-color: #1976d2;
        }

        /* DataTables Buttons styling */
        .dt-buttons {
            margin-bottom: 15px;
        }

        .dt-button {
            margin-right: 5px;
        }
    </style>
</head>

<body>
    <div id="layout-wrapper">
        <?php include('header.php'); ?>
        <?php include('sidebar.php'); ?>

        <div class="main-content">
            <div class="page-content">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-12">
                            <div class="filter-card">
                                <form id="dateRangeForm" method="GET" class="row align-items-center">
                                    <div class="col-md-4">
                                        <label>Date Range</label>
                                        <input type="text" id="daterange" name="daterange" class="form-control"
                                            value="<?php echo date('m/d/Y', strtotime($start_date)) . ' - ' . date('m/d/Y', strtotime($end_date)); ?>">
                                    </div>
                                    <div class="col-md-2">
                                        <button type="submit" class="btn btn-primary mt-4">
                                            <i class="fas fa-filter"></i> Filter
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>

                    <!-- Totals -->
                    <div class="row">
                        <div class="col-md-6">
                            <div class="total-card" style="width: 80vw;">
                                <div class="total-label" style="text-align: right;">Total Amount Paid</div>
                                <div class="total-value" style="text-align: right;">Rs.
                                    <?php echo number_format($total_amount, 2); ?>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Payments Table -->
                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-body">
                                    <h4 class="card-title mb-4">Payment Report</h4>
                                    <div class="table-responsive">
                                        <table id="payments-table" class="table table-bordered">
                                            <thead>
                                                <tr>
                                                    <th>Date</th>
                                                    <th>Customer</th>
                                                    <th>Payment Method</th>
                                                    <th>Created By</th>
                                                    <th>Payment</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php foreach ($all_payments as $row) { ?>
                                                    <tr>
                                                        <td><?php echo date('d-m-Y H:i', strtotime($row['create_date'])); ?>
                                                        </td>
                                                        <td><?php echo htmlspecialchars($row['customer_name']); ?></td>
                                                        <td>
                                                            <span
                                                                class="method-badge method-<?php echo strtolower(str_replace(' ', '-', $row['payment_method'])); ?>">
                                                                <?php echo $row['payment_method']; ?>
                                                            </span>
                                                        </td>
                                                        <td><?php echo htmlspecialchars($row['created_by'] ?? 'System'); ?>
                                                        </td>
                                                        <td class="text-right">Rs.
                                                            <?php echo number_format($row['amount_paid'], 2); ?>
                                                        </td>
                                                    </tr>
                                                <?php } ?>
                                            </tbody>
                                            <tfoot>
                                                <tr>
                                                    <th colspan="4">Total</th>
                                                    <th class="text-right">Rs.
                                                        <?php echo number_format($total_amount, 2); ?>
                                                    </th>
                                                </tr>
                                            </tfoot>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php include 'footer.php'; ?>
        </div>
    </div>

    <!-- Scripts -->
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/metismenu.min.js"></script>
    <script src="assets/js/simplebar.min.js"></script>
    <script src="assets/js/waves.js"></script>

    <!-- DataTables with Buttons -->
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.2.2/js/dataTables.buttons.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.2.2/js/buttons.html5.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.2.2/js/buttons.print.min.js"></script>

    <!-- Date Range Picker -->
    <script type="text/javascript" src="https://cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script>
    <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.js"></script>

    <script>
        $(document).ready(function () {
            // Initialize date range picker
            $('#daterange').daterangepicker({
                opens: 'left',
                locale: {
                    format: 'MM/DD/YYYY'
                }
            });

            // Handle form submission
            $('#dateRangeForm').on('submit', function (e) {
                e.preventDefault();
                var dates = $('#daterange').val().split(' - ');
                var startDate = moment(dates[0], 'MM/DD/YYYY').format('YYYY-MM-DD');
                var endDate = moment(dates[1], 'MM/DD/YYYY').format('YYYY-MM-DD');
                window.location.href = '?start_date=' + startDate + '&end_date=' + endDate;
            });

            // Get total from PHP
            var grandTotal = <?php echo $total_amount; ?>;

            // Initialize DataTable
            var table = $('#payments-table').DataTable({
                dom: 'Bfrtip',
                buttons: [
                    {
                        extend: 'excel',
                        text: '<i class="fas fa-file-excel"></i> Excel',
                        className: 'btn btn-primary btn-sm mr-2',
                        title: 'Payment Report ' + $('#daterange').val(),
                        messageBottom: 'Total Amount: Rs. ' + grandTotal.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ","),
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4],
                            format: {
                                body: function (data, row, column, node) {
                                    if (column === 2) {
                                        return $(node).find('.method-badge').text().trim();
                                    }
                                    if (column === 4) {
                                        return data.replace('Rs. ', '').replace(/,/g, '');
                                    }
                                    return data.replace(/<[^>]+>/g, '').trim();
                                }
                            }
                        }
                    },
                    {
                        extend: 'pdf',
                        text: '<i class="fas fa-file-pdf"></i> PDF',
                        className: 'btn btn-danger btn-sm mr-2',
                        title: 'Payment Report ' + $('#daterange').val(),
                        exportOptions: {
                            columns: [0, 1, 2, 3, 4]
                        },
                        customize: function (doc) {
                            doc.styles.tableHeader.alignment = 'left';
                            doc.content[1].table.widths = ['20%', '25%', '15%', '20%', '20%'];

                            for (var i = 0; i < doc.content[1].table.body.length; i++) {
                                if (i !== 0) {
                                    var paymentCell = doc.content[1].table.body[i][4];
                                    if (typeof paymentCell === 'string' && paymentCell.startsWith('Rs.')) {
                                        doc.content[1].table.body[i][4] = {
                                            text: paymentCell,
                                            alignment: 'right'
                                        };
                                    }
                                }
                            }

                            doc.content[1].table.body.push([
                                { text: 'Total', bold: true },
                                { text: '', bold: true },
                                { text: '', bold: true },
                                { text: '', bold: true },
                                {
                                    text: 'Rs. ' + grandTotal.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ","),
                                    alignment: 'right',
                                    bold: true
                                }
                            ]);
                        }
                    }
                ],
                pageLength: 25,
                order: [[0, 'desc']],
                columnDefs: [
                    {
                        targets: 4,
                        className: 'text-right'
                    }
                ],
                footerCallback: function (row, data, start, end, display) {
                    var api = this.api();
                    $(api.column(4).footer()).html('Rs. ' + grandTotal.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ","));
                }
            });
        });
    </script>

    <script src="assets/js/theme.js"></script>
</body>

</html>