<?php session_start(); 
require('./config.php'); 


$paymentTypes = array();

$paymentQuery = "SELECT Pay_id, pay_desc FROM tbl_payment_types WHERE Pay_id IN (1, 11, 12,5)";
$result = $conn->query($paymentQuery);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $paymentTypes[] = array(
            "Pay_id" => $row["Pay_id"],
            "pay_desc" => $row["pay_desc"]
        );
    }
}

$conn->close();

header("Content-Type: application/json");
echo json_encode($paymentTypes);
?>
