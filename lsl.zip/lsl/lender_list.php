<?php 
session_start(); 
require('./config.php');

if (!isset($_SESSION['staffname'])) {
    echo "<script>window.location.replace('login.php');</script>";
} else { 
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <title>Lender List | LSL System</title>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta content="Admin & Dashboard Template" name="description" />
    <meta content="MyraStudio" name="author" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />

    <!-- App favicon -->
    <link rel="shortcut icon" href="assets/images/favicon.ico">

    <!-- App css -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <link href="assets/css/icons.min.css" rel="stylesheet" type="text/css" />
    <link href="assets/css/theme.min.css" rel="stylesheet" type="text/css" />
    <!-- DataTables css -->
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
</head>

<body>
    <!-- Begin page -->
    <div id="layout-wrapper">
        <?php include('header.php'); ?>
        <?php include('sidebar.php'); ?>

        <!-- ============================================================== -->
        <!-- Start right Content here -->
        <!-- ============================================================== -->
        <div class="main-content">
            <div class="page-content">
                <div class="container-fluid">
                    <!-- start page title -->
                    <div class="row">
                        <div class="col-12">
                            <div class="page-title-box d-flex align-items-center justify-content-between">
                                <h4 class="mb-0 font-size-18">Lender List</h4>

                                <div class="page-title-right">
                                    <ol class="breadcrumb m-0">
                                        <li class="breadcrumb-item"><a href="javascript: void(0);">Lenders</a></li>
                                        <li class="breadcrumb-item active">Lender List</li>
                                    </ol>
                                </div>
                            </div>
                        </div>
                    </div>     
                    <!-- end page title -->

                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-body">
                                    <h4 class="card-title">Lender List</h4>
                                    <p class="card-subtitle mb-4">Here you can manage and view the list of lenders.</p>

                                    <div class="table-responsive">
                                        <table id="lender-table" class="table table-bordered table-striped mb-0">
                                            <thead>
                                                <tr>
                                                    <th>#</th>
                                                    <th>Lender Name</th>
                                                    <th>Address</th>
                                                    <th>Phone Number</th>
                                                    <th>Email</th>
                                                    <th>Created By</th>
                                                    <th>Created Date</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                $query = "SELECT id, lender_name, lender_address, lender_phone, lender_email, created_by, created_date FROM tbl_lender ORDER BY id DESC";
                                                $result = $conn->query($query);
                                                $count = 1;

                                                while ($row = $result->fetch_assoc()) {
                                                    echo "<tr>";
                                                    echo "<td>" . $count++ . "</td>";
                                                    echo "<td>" . htmlspecialchars($row['lender_name']) . "</td>";
                                                    echo "<td>" . htmlspecialchars($row['lender_address']) . "</td>";
                                                    echo "<td>" . htmlspecialchars($row['lender_phone']) . "</td>";
                                                    echo "<td>" . htmlspecialchars($row['lender_email']) . "</td>";
                                                    echo "<td>" . htmlspecialchars($row['created_by']) . "</td>";
                                                    echo "<td>" . date('d-m-Y', strtotime($row['created_date'])) . "</td>";
                                                    echo "<td>";
                                                    echo "<a href='edit_lender.php?id=" . $row['id'] . "' class='btn btn-info btn-sm'>Edit</a> ";
                                                    echo "<button class='btn btn-danger btn-sm delete-lender' data-id='" . $row['id'] . "'>Delete</button>";
                                                    echo "</td>";
                                                    echo "</tr>";
                                                }
                                                ?>
                                            </tbody>
                                        </table>
                                    </div> <!-- end table-responsive-->
                                </div> <!-- end card-body-->
                            </div> <!-- end card-->
                        </div> <!-- end col -->
                    </div> <!-- end row-->
                </div> <!-- container-fluid -->
            </div> <!-- End Page-content -->
            
 <?php include 'footer.php'; ?>
        </div> <!-- end main content-->
    </div> <!-- END layout-wrapper -->

    <!-- jQuery  -->
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/metismenu.min.js"></script>
    <script src="assets/js/waves.js"></script>
    <script src="assets/js/simplebar.min.js"></script>
    <!-- DataTables js -->
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.js"></script>
    <!-- SweetAlert2 -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <!-- App js -->
    <script src="assets/js/theme.js"></script>

    <script>
    $(document).ready(function() {
        // Initialize DataTables
        $('#lender-table').DataTable({
            "pageLength": 10,
            "ordering": true,
            "searching": true,
            "lengthChange": true,
            "language": {
                "search": "Search:",
                "lengthMenu": "Show _MENU_ entries"
            }
        });

        // Handle Delete with SweetAlert2
        $('.delete-lender').on('click', function() {
            var lenderId = $(this).data('id');
            Swal.fire({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
                if (result.isConfirmed) {
                    $.ajax({
                        url: 'delete_lender.php',
                        type: 'POST',
                        data: { id: lenderId },
                        success: function(response) {
                            if (response.status == 'success') {
                                Swal.fire(
                                    'Deleted!',
                                    'Lender has been deleted.',
                                    'success'
                                ).then(() => {
                                    location.reload();
                                });
                            } else {
                                Swal.fire(
                                    'Error!',
                                    'Something went wrong. Please try again.',
                                    'error'
                                );
                            }
                        }
                    });
                }
            });
        });
    });
    </script>
</body>
</html>

<?php } ?>
