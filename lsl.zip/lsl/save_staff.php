<?php
require('./config.php');
session_start();
if (isset($_POST['username'])) {
    $name = $_POST['fname'];
    $username = $_POST['username'];
    $email = $_POST['email'];
    $usertype = $_POST['usertype'];
    $phone = $_POST['phone'];
    $password = sha1($_POST['password']); // Encrypt the password using SHA1

    $query = "INSERT INTO tbl_user (name, username, email, user_type, phone, password, create_date, created_by) VALUES (?, ?, ?, ?, ?, ?, NOW(), ?)";
    $stmt = $conn->prepare($query);
    $created_by = $_SESSION['staffname']; // Assuming staffname is the creator
    $stmt->bind_param('sssssss', $name, $username, $email, $usertype, $phone, $password, $created_by);
    
    if ($stmt->execute()) {
        echo 'Staff added successfully.';
    } else {
        echo 'Error adding staff: ' . $stmt->error;
    }
}
?>
