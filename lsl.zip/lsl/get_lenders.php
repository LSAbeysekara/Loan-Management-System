<?php
require('./config.php');
$result = $conn->query("SELECT id, lender_name, lender_nic_no,lender_phone FROM tbl_lender WHERE status = 'Active'");
$lenders = [];
while ($row = $result->fetch_assoc()) {
    $lenders[] = $row;
}
echo json_encode($lenders);
?>
