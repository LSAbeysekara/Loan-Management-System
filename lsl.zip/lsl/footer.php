<footer class="footer">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-sm-6">
                            2024 © All Right Received.
                        </div>
                        <div class="col-sm-6">
                            <div class="text-sm-right d-none d-sm-block">
                                Design & Develop by Tekceylo (Private) Limited.
                            </div>
                        </div>
                    </div>
                </div>
            </footer>