<?php 
session_start(); 
require('./config.php');

if (!isset($_SESSION['staffname'])) {
    echo "<script>window.location.replace('login.php');</script>";
} else { 
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <title>Customer List | LSL System</title>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta content="Admin & Dashboard Template" name="description" />
    <meta content="MyraStudio" name="author" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />

    <!-- App favicon -->
    <link rel="shortcut icon" href="assets/images/favicon.ico">

    <!-- App css -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <link href="assets/css/icons.min.css" rel="stylesheet" type="text/css" />
    <link href="assets/css/theme.min.css" rel="stylesheet" type="text/css" />
    <!-- DataTables css -->
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.css">
</head>

<body>
    <!-- Begin page -->
    <div id="layout-wrapper">
        <?php include('header.php'); ?>
        <?php include('sidebar.php'); ?>

        <!-- ============================================================== -->
        <!-- Start right Content here -->
        <!-- ============================================================== -->
        <div class="main-content">
            <div class="page-content">
                <div class="container-fluid">
                    <!-- start page title -->
                    <div class="row">
                        <div class="col-12">
                            <div class="page-title-box d-flex align-items-center justify-content-between">
                                <h4 class="mb-0 font-size-18">Customer List</h4>

                                <div class="page-title-right">
                                    <ol class="breadcrumb m-0">
                                        <li class="breadcrumb-item"><a href="javascript: void(0);">Customers</a></li>
                                        <li class="breadcrumb-item active">Customer List</li>
                                    </ol>
                                </div>
                            </div>
                        </div>
                    </div>     
                    <!-- end page title -->

                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-body">
                                    <h4 class="card-title">Customer List</h4>
                                    <p class="card-subtitle mb-4">Here you can manage and view the list of customers.</p>

                                    <div class="table-responsive">
                                        <table id="customer-table" class="table table-bordered table-striped mb-0">
                                            <thead>
                                                <tr>
                                                    <th>#</th>
                                                    <th>Membership Number</th>
                                                    <th>Full Name</th>
                                                    <th>NIC Number</th>
                                                    <th>Mobile Phone</th>
                                                    <th>Marital Status</th>
                                                    <th>Created Date</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                $query = "SELECT id, membership_number, full_name, nic_no, mobile_phone, marital_status, created_date FROM tbl_customer ORDER BY id DESC";
                                                $result = $conn->query($query);
                                                $count = 1;

                                                while ($row = $result->fetch_assoc()) {
                                                    echo "<tr>";
                                                    echo "<td>" . $count++ . "</td>";
                                                    echo "<td>" . $row['membership_number'] . "</td>";
                                                    echo "<td>" . $row['full_name'] . "</td>";
                                                    echo "<td>" . $row['nic_no'] . "</td>";
                                                    echo "<td>" . $row['mobile_phone'] . "</td>";
                                                    echo "<td>" . ucfirst($row['marital_status']) . "</td>";
                                                    echo "<td>" . date('d-m-Y', strtotime($row['created_date'])) . "</td>";
                                                    echo "<td>";
                                                    echo "<a href='edit_customer.php?id=" . $row['id'] . "' class='btn btn-info btn-sm'>Edit</a> ";
                                                    echo "<button class='btn btn-danger btn-sm delete-customer' data-id='" . $row['id'] . "'>Delete</button>";
                                                    echo "<a href='loan_selection_card.php?id=" . $row['id'] . "' class='btn btn-success btn-sm' style='margin-left: 4px;'>View</a> ";
                                                    echo "</td>";
                                                    echo "</tr>";
                                                }
                                                ?>
                                            </tbody>
                                        </table>
                                    </div> <!-- end table-responsive-->
                                </div> <!-- end card-body-->
                            </div> <!-- end card-->
                        </div> <!-- end col -->
                    </div> <!-- end row-->
                </div> <!-- container-fluid -->
            </div> <!-- End Page-content -->
            
 <?php include 'footer.php'; ?>
        </div> <!-- end main content-->
    </div> <!-- END layout-wrapper -->

    <!-- jQuery  -->
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/metismenu.min.js"></script>
    <script src="assets/js/waves.js"></script>
    <script src="assets/js/simplebar.min.js"></script>
    <!-- DataTables js -->
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.js"></script>
    <!-- SweetAlert2 -->
    <script src="assets/js/sweetalert2.all.min.js"></script>
    <!-- App js -->
    <script src="assets/js/theme.js"></script>

    <script>
    $(document).ready(function() {
        // Initialize DataTables
        $('#customer-table').DataTable({
            "pageLength": 10,
            "ordering": true,
            "searching": true,
            "lengthChange": true,
            "language": {
                "search": "Search:",
                "lengthMenu": "Show _MENU_ entries"
            }
        });

        // Handle Delete with SweetAlert2
        $('.delete-customer').on('click', function() {
            var customerId = $(this).data('id');
            Swal.fire({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
                if (result.isConfirmed) {
                    $.ajax({
                        url: 'delete_customer.php',
                        type: 'POST',
                        data: { id: customerId },
                        success: function(response) {
                            if (response.status == 'success') {
                                Swal.fire(
                                    'Deleted!',
                                    'Customer has been deleted.',
                                    'success'
                                ).then(() => {
                                    location.reload();
                                });
                            } else {
                                Swal.fire(
                                    'Error!',
                                    'Something went wrong. Please try again.',
                                    'error'
                                );
                            }
                        }
                    });
                }
            });
        });
    });
    </script>
</body>
</html>

<?php } ?>
