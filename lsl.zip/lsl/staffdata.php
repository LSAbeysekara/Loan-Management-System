<?php
require('./config.php');

$query = "SELECT `name`, `email`, user_type, `username`,`phone`, `status` FROM `tbl_user`";
$result = mysqli_query($conn, $query);

$data = array();

while ($row = mysqli_fetch_assoc($result)) {
    $data[] = $row;
}

echo json_encode(array("data" => $data));

mysqli_close($conn);
?>
