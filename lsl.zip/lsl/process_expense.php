<?php
session_start();
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    include('./config.php');

    // Get the main expense form data
    $billType = 'other';
    $payto = $_POST['payto'];
    $bill_no = $_POST['bill_no'];
    //$expenseremark = 'none';
    $pay_id = $_POST['paymentType'];  // Payment method for the whole document
    $cheque_no = $_POST['checkNumber'];  // Cheque number (optional)
    $realize_date = $_POST['realizationDate'];  // Realization date (optional)
    $created_by = $_SESSION['staffname'];

    // Calculate grand total
    $amounts = $_POST['amount'];
    $grandTotal = array_sum($amounts); // Sum of all amounts

    // Insert the main expense into tbl_expenses
    $sql = "INSERT INTO tbl_expenses (billType, payto, bill_no,  pay_id, cheque_no, realize_date, amount, create_by, create_date)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('ssssisds', $billType, $payto, $bill_no,  $pay_id, $cheque_no, $realize_date, $grandTotal, $created_by);
    $stmt->execute();

    // Get the last inserted exp_id
    $exp_id = $stmt->insert_id;

    // Insert the expense details (multiple entries)
    $expenseCategories = $_POST['expenseCategory'];
    $expenseDescriptions = $_POST['expenseDescription'];

    $detail_sql = "INSERT INTO tbl_expenses_details (exp_id, exp_cat, exp_desc, amount)
                   VALUES (?, ?, ?, ?)";
    $detail_stmt = $conn->prepare($detail_sql);

    // Loop through the expense details
    for ($i = 0; $i < count($expenseCategories); $i++) {
        $expenseCategory = $expenseCategories[$i];
        $expenseDescription = $expenseDescriptions[$i];
        $amount = $amounts[$i];

        // Bind parameters and execute for each detail
        $detail_stmt->bind_param('issd', $exp_id, $expenseCategory, $expenseDescription, $amount);
        $detail_stmt->execute();
    }

    if ($stmt && $detail_stmt) {
        echo json_encode(['success' => true, 'exp_id' => $exp_id]);
    } else {
        echo json_encode(['success' => false, 'error' => 'Failed to save data.']);
    }
}
