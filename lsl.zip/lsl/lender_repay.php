<?php session_start(); ?>
<?php require('./config.php'); ?>

<?php if (!isset($_SESSION['staffname'])) {
    echo "<script> window.location.replace('login.php'); </script>";
} else { ?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <title>LSL System</title>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta content="Premium Multipurpose Admin & Dashboard Template" name="description" />
    <meta content="MyraStudio" name="author" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />

    <!-- App favicon -->
    <link rel="shortcut icon" href="assets/images/favicon.ico">

    <!-- App css -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <link href="assets/css/icons.min.css" rel="stylesheet" type="text/css" />
    <link href="assets/css/theme.min.css" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/css/select2.min.css" />
    
    <link href="https://cdn.jsdelivr.net/npm/sweetalert2@11.7.12/dist/sweetalert2.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.7.12/dist/sweetalert2.all.min.js"></script>
</head>

<body>
    <div id="layout-wrapper">
        <?php include('header.php'); ?>
        <?php include('sidebar.php'); ?>

        <div class="main-content">
            <div class="page-content">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-12">
                            <div class="page-title-box d-flex align-items-center justify-content-between">
                                <h4 class="mb-0 font-size-18">Expenses</h4>
                                <div class="page-title-right">
                                    <ol class="breadcrumb m-0">
                                        <li class="breadcrumb-item"><a href="javascript: void(0);">Transaction</a></li>
                                        <li class="breadcrumb-item active">Add Expenses</li>
                                    </ol>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-body">
                                    <h4 class="card-title">Add Expenses</h4>
                                    <p class="card-subtitle mb-4">Add Expenses here with required details.</p>

                                    <form id="expenseForm">
                                        <div class="mb-3">
                                            <label for="bill_no" class="form-label">Bill Number</label>
                                            <input type="text" id="bill_no" name="bill_no" class="form-control col-sm-2" required>
                                        </div>

                                        <div class="mb-3">
                                            <label for="payto" class="form-label">Expense Pay to</label>
                                            <input type="text" id="payto" name="payto" class="form-control" required>
                                        </div>

                                        <div class="mb-3">
                                            <label for="expenseCategory" class="form-label">Expense Category</label>
                                            <select id="expenseCategory" name="expenseCategory" class="form-control" required>
                                                <option value="">Select Expense Category</option>
                                            </select>
                                        </div>

                                        <div id="lenderLoanSection" style="display: none;">
                                            <div class="mb-3">
                                                <label for="lenderLoan" class="form-label">Select Lender Loan</label>
                                                <select id="lenderLoan" name="lenderLoan" class="form-control">
                                                    <option value="">Select Loan</option>
                                                </select>
                                            </div>

                                            <div class="mb-3">
                                                <label for="interestAmount" class="form-label">Unpaid Interest</label>
                                                <input type="number" id="interestAmount" name="interestAmount" class="form-control" readonly>
                                            </div>

                                            <div class="mb-3">
                                                <label for="repayAmount" class="form-label">Remaining Loan Balance</label>
                                                <input type="number" id="repayAmount" name="repayAmount" class="form-control" readonly>
                                            </div>
                                        </div>

                                        <div class="mb-3">
                                            <label for="amount" class="form-label">Amount</label>
                                            <input type="number" id="amount" name="amount" class="form-control" required>
                                        </div>

                                        <button type="submit" class="btn btn-primary">Submit</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php include './footer.php'; ?>
            </div>
        </div>
    </div>

    <!-- Scripts -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/metismenu.min.js"></script>
    <script src="assets/js/waves.js"></script>
    <script src="assets/js/simplebar.min.js"></script>
    <script src="assets/js/theme.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/js/select2.min.js"></script>
    <script>
        $(document).ready(function () {
            // Load expense categories
            $.ajax({
                url: 'get_expense_categories.php',
                type: 'GET',
                dataType: 'json',
                success: function (data) {
                    const $categoryDropdown = $('#expenseCategory');
                    data.forEach(function (category) {
                        $categoryDropdown.append($('<option>', {
                            value: category.cat_id,
                            text: category.cat_name
                        }));
                    });
                }
            });

            // Show lender loan section for Loan Interest Pay or Loan Repay
            $('#expenseCategory').change(function () {
                const selectedCategory = $(this).val();
                if (selectedCategory == '3' || selectedCategory == '4') {
                    $('#lenderLoanSection').show();

                    // Fetch lender loans
                    $.ajax({
                        url: 'get_lender_loan.php',
                        type: 'GET',
                        dataType: 'json',
                        success: function (data) {
                            const $loanDropdown = $('#lenderLoan');
                            $loanDropdown.empty().append('<option value="">Select Loan</option>');
                            data.forEach(function (loan) {
                                $loanDropdown.append($('<option>', {
                                    value: loan.id,
                                    text: loan.loan_details
                                }));
                            });
                        }
                    });
                } else {
                    $('#lenderLoanSection').hide();
                }
            });

            // Load loan details (interest and balance)
            $('#lenderLoan').change(function () {
    const loanId = $(this).val(); // Get the loan ID from the dropdown

    // Check if loan ID is valid
    if (loanId) {
        $.ajax({
            url: 'get_loan_details.php',
            type: 'GET',
            data: { loan_id: loanId },
            dataType: 'json',
            success: function (data) {
                if (data.success) {
                    console.log(data); // Check the console to see the response

                    // Make sure that these keys exist in the response
                    $('#interestAmount').val(data.data.total_unpaid_interest);
                    $('#repayAmount').val(data.data.remaining_balance);
                } else {
                    alert('Error: ' + (data.error || 'Unable to fetch loan details.'));
                }
            },
            error: function (xhr, status, error) {
                console.error('AJAX Error:', status, error);
                alert('An error occurred while fetching loan details.');
            }
        });
    } else {
        // Clear the values if no loan is selected
        $('#interestAmount').val('');
        $('#repayAmount').val('');
    }
});


            // Handle form submission
            $('#expenseForm').submit(function (e) {
                e.preventDefault();
                $.ajax({
                    url: 'process_expense.php',
                    type: 'POST',
                    data: $(this).serialize(),
                    dataType: 'json',
                    success: function (response) {
                        if (response.success) {
                            Swal.fire('Success', 'Expense saved successfully!', 'success');
                            location.reload();
                        } else {
                            Swal.fire('Error', response.error, 'error');
                        }
                    }
                });
            });
        });
    </script>
    
</body>
</html>
<?php } ?>
