<?php
require('./config.php');
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $lender_name = $_POST['lender_name'];
    $lender_address = $_POST['lender_address'];
    $lender_phone = $_POST['lender_phone'];
    $lender_email = $_POST['lender_email'];
    $created_by = $_SESSION['staffname'];

    $query = $conn->prepare("INSERT INTO tbl_lender (lender_name, lender_address, lender_phone, lender_email, created_by) VALUES (?, ?, ?, ?, ?)");
    $query->bind_param("sssss", $lender_name, $lender_address, $lender_phone, $lender_email, $created_by);

    if ($query->execute()) {
        echo json_encode(['status' => 'success']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Failed to save lender.']);
    }
}
?>
