<?php
session_start();
require('./config.php');

if (!isset($_SESSION['staffname'])) {
    echo "<script>window.location.replace('login.php');</script>";
    exit;
}

$loan_id = $_GET['loan_id'] ?? 0;

// Get loan and customer details
$loan_query = "SELECT l.*, c.* 
               FROM tbl_loan l
               JOIN tbl_customer c ON l.customer_id = c.id
               WHERE l.id = ?";

$stmt = $conn->prepare($loan_query);
$stmt->bind_param("i", $loan_id);
$stmt->execute();
$loan_result = $stmt->get_result();
$loan = $loan_result->fetch_assoc();

if (!$loan) {
    header("Location: customer_list.php");
    exit;
}

// Get all transactions with UNION for payments, expenses, and loan disbursement
$transactions_query = "
    -- Loan Amount (Credit)
    SELECT 
        create_date as transaction_date,
        'Loan Amount' as description,
        requested_amount as credit,
        0 as debit,
        'Loan' as type
    FROM tbl_loan 
    WHERE id = ?

    UNION ALL
    
    -- Loan Payments (Debit)
    SELECT 
        p.create_date as transaction_date,
        CONCAT('Payment - Principal: ', FORMAT(p.amount_paid, 2)) as description,
        0 as credit,
        (p.amount_paid + p.interest_paid) as debit,
        'Payment' as type
    FROM tbl_payments p
    WHERE p.loan_id = ? AND p.status = 'Paid'
    
    UNION ALL
    
    -- Expenses (Debit)
    SELECT 
        e.create_date as transaction_date,
        CONCAT('Expense: ', e.exp_desc, ' (', e.billType, ')') as description,
        0 as credit,
        e.amount as debit,
        'Expense' as type
    FROM tbl_expenses e
    WHERE e.loan_id = ? AND e.status = 'active'

    UNION ALL
    
    -- Interest Charges (Credit)
    SELECT 
        DATE(li.created_date) as transaction_date,
        CONCAT('Interest charged for non-payment between ', 
               DATE_FORMAT(li.payment_st_date, '%d-%m-%Y'), 
               ' and ', 
               DATE_FORMAT(li.payment_end_date, '%d-%m-%Y')) as description,
        li.interest_amount as credit,
        0 as debit,
        'Interest' as type
    FROM tbl_loan_interest li
    WHERE li.loan_id = ? AND li.status != 'Cancelled'
    
    ORDER BY transaction_date ASC, type ASC";

$stmt = $conn->prepare($transactions_query);
$stmt->bind_param("iiii", $loan_id, $loan_id, $loan_id, $loan_id);
$stmt->execute();
$transactions_result = $stmt->get_result();

// Calculate running balance
$transactions = [];
$running_balance = 0;

while ($row = $transactions_result->fetch_assoc()) {
    // Update running balance
    $running_balance += $row['credit']; // Add credits (loan amount)
    $running_balance -= $row['debit'];  // Subtract debits (payments and expenses)
    
    $row['running_balance'] = $running_balance;
    $transactions[] = $row;
}

// Calculate summary statistics
$total_paid_query = "SELECT 
    COALESCE(SUM(amount_paid), 0) as total_principal_paid,
    COALESCE(SUM(interest_paid), 0) as total_interest_paid
    FROM tbl_payments 
    WHERE loan_id = ? AND status = 'Paid'";
$stmt = $conn->prepare($total_paid_query);
$stmt->bind_param("i", $loan_id);
$stmt->execute();
$payment_summary = $stmt->get_result()->fetch_assoc();

// Get total interest charges
$total_interest_query = "SELECT 
    COALESCE(SUM(interest_amount), 0) as total_interest_charged
    FROM tbl_loan_interest 
    WHERE loan_id = ? AND status != 'Cancelled'";
$stmt = $conn->prepare($total_interest_query);
$stmt->bind_param("i", $loan_id);
$stmt->execute();
$interest_summary = $stmt->get_result()->fetch_assoc();

$total_expenses_query = "SELECT 
    COALESCE(SUM(amount), 0) as total_expenses 
    FROM tbl_expenses 
    WHERE loan_id = ? AND status = 'active'";
$stmt = $conn->prepare($total_expenses_query);
$stmt->bind_param("i", $loan_id);
$stmt->execute();
$expenses_summary = $stmt->get_result()->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Loan History - <?php echo htmlspecialchars($loan['full_name']); ?></title>
    
    <!-- CSS -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/icons.min.css" rel="stylesheet">
    <link href="assets/css/theme.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/buttons/2.2.2/css/buttons.dataTables.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    
    <style>
        /* Main card and summary styles */
        .summary-card {
            background-color: #f8f9fa;
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 20px;
        }
        .summary-title {
            color: #495057;
            font-size: 1.1em;
            font-weight: 600;
            margin-bottom: 15px;
        }
        .summary-item {
            display: flex;
            justify-content: space-between;
            margin-bottom: 10px;
        }
        .summary-label {
            color: #6c757d;
        }
        .summary-value {
            font-weight: 500;
        }
        .summary-value.positive {
            color: #dc3545;
        }
        .summary-value.negative {
            color: #28a745;
        }

        /* Table styles */
        .passbook-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 1rem;
            background-color: #fff;
        }
        .passbook-table th {
            background-color: #f8f9fa;
            border: 1px solid #dee2e6;
            padding: 12px;
            font-weight: 600;
            text-align: center;
        }
        .passbook-table td {
            border: 1px solid #dee2e6;
            padding: 10px;
            vertical-align: middle;
        }
        .passbook-table .credit {
            color: #dc3545;
            text-align: right;
        }
        .passbook-table .debit {
            color: #28a745;
            text-align: right;
        }
        .passbook-table .balance {
            font-weight: 600;
            text-align: right;
        }

        /* Transaction type badges */
        .transaction-type {
            font-size: 0.85em;
            padding: 3px 8px;
            border-radius: 4px;
            margin-right: 8px;
            display: inline-block;
        }
        .type-opening {
            background-color: #fff3cd;
            color: #856404;
        }
        .type-disbursement {
            background-color: #cce5ff;
            color: #004085;
        }
        .type-payment {
            background-color: #d4edda;
            color: #155724;
        }
        .type-interest {
            background-color: #e2e3e5;
            color: #383d41;
        }
        .type-expense {
            background-color: #f8d7da;
            color: #721c24;
        }

        /* Hover effects */
        .transaction-row:hover {
            background-color: #f8f9fa;
        }

        /* DataTables button styling */
        .dt-buttons {
            margin-bottom: 15px;
            gap: 8px;
            display: flex;
            flex-wrap: wrap;
        }

        .dt-button {
            padding: 8px 16px !important;
            border-radius: 4px !important;
            border: none !important;
            font-size: 0.875rem !important;
            font-weight: 500 !important;
            transition: all 0.2s ease-in-out !important;
            display: inline-flex !important;
            align-items: center !important;
            justify-content: center !important;
            min-width: 100px !important;
            background: #4B49AC !important;
            color: white !important;
        }

        .dt-button:hover {
            background: #3c3a93 !important;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1) !important;
            transform: translateY(-1px) !important;
        }

        .dt-button:active {
            transform: translateY(0) !important;
            box-shadow: none !important;
        }

        .dt-button i {
            margin-right: 6px;
            font-size: 1rem;
        }

        /* DataTables search and length controls */
        .dataTables_length select {
            padding: 6px 12px;
            border-radius: 4px;
            border: 1px solid #dee2e6;
            background-color: white;
            margin: 0 6px;
        }

        .dataTables_filter input {
            padding: 6px 12px;
            border-radius: 4px;
            border: 1px solid #dee2e6;
            background-color: white;
            margin-left: 6px;
            min-width: 200px;
        }

        /* DataTables pagination */
        .dataTables_paginate {
            margin-top: 15px !important;
        }

        .paginate_button {
            padding: 6px 12px !important;
            margin: 0 2px !important;
            border-radius: 4px !important;
            border: 1px solid #dee2e6 !important;
            background-color: white !important;
            color: #4B49AC !important;
        }

        .paginate_button.current {
            background-color: #4B49AC !important;
            border-color: #4B49AC !important;
            color: white !important;
        }

        .paginate_button:hover {
            background-color: #f8f9fa !important;
            border-color: #4B49AC !important;
            color: #4B49AC !important;
        }

        /* Responsive adjustments */
        @media (max-width: 768px) {
            .dt-buttons {
                justify-content: center;
                margin-bottom: 20px;
            }
            
            .dataTables_filter {
                margin-top: 15px;
                text-align: center;
            }
            
            .dataTables_length {
                text-align: center;
            }
        }
    </style>
</head>

<body>
    <div id="layout-wrapper">
        <?php include('header.php'); ?>
        <?php include('sidebar.php'); ?>

        <div class="main-content">
            <div class="page-content">
                <div class="container-fluid">
                    <!-- Loan Summary -->
                    <div class="row">
                        <div class="col-12">
                            <div class="summary-card">
                                <h5 class="summary-title">Loan Summary</h5>
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="summary-item">
                                            <span class="summary-label">Customer Name:</span>
                                            <span class="summary-value"><?php echo htmlspecialchars($loan['full_name']); ?></span>
                                        </div>
                                        <div class="summary-item">
                                            <span class="summary-label">Loan Amount:</span>
                                            <span class="summary-value">Rs. <?php echo number_format($loan['requested_amount'], 2); ?></span>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="summary-item">
                                            <span class="summary-label">Total Principal Paid:</span>
                                            <span class="summary-value">Rs. <?php echo number_format($payment_summary['total_principal_paid'], 2); ?></span>
                                        </div>
                                        <div class="summary-item">
                                            <span class="summary-label">Total Interest Charged:</span>
                                            <span class="summary-value">Rs. <?php echo number_format($interest_summary['total_interest_charged'], 2); ?></span>
                                        </div>
                                        <div class="summary-item">
                                            <span class="summary-label">Total Expenses:</span>
                                            <span class="summary-value">Rs. <?php echo number_format($expenses_summary['total_expenses'], 2); ?></span>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="summary-item">
                                            <span class="summary-label">Current Balance:</span>
                                            <span class="summary-value <?php echo $running_balance > 0 ? 'negative' : 'positive'; ?>">
                                                Rs. <?php echo number_format($running_balance, 2); ?>
                                            </span>
                                        </div>
                                        <div class="summary-item">
                                            <span class="summary-label">Monthly Interest Rate:</span>
                                            <span class="summary-value"><?php echo number_format($loan['monthly_interest_rate'], 2); ?>%</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Passbook Table -->
                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-body">
                                    <h4 class="card-title mb-4">Loan Passbook</h4>
                                    <div class="table-responsive">
                                        <table id="loan-passbook" class="passbook-table">
                                            <thead>
                                                <tr>
                                                    <th>Date</th>
                                                    <th>Description</th>
                                                    <th>Credit (Rs.)</th>
                                                    <th>Debit (Rs.)</th>
                                                    <th>Balance (Rs.)</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php foreach ($transactions as $transaction): ?>
                                                <tr class="transaction-row">
                                                    <td><?php echo date('d-m-Y', strtotime($transaction['transaction_date'])); ?></td>
                                                    <td>
                                                        <span class="transaction-type type-<?php echo strtolower($transaction['type']); ?>">
                                                            <?php echo ucfirst($transaction['type']); ?>
                                                        </span>
                                                        <?php echo htmlspecialchars($transaction['description']); ?>
                                                    </td>
                                                    <td class="credit">
                                                        <?php echo $transaction['credit'] > 0 ? number_format($transaction['credit'], 2) : ''; ?>
                                                    </td>
                                                    <td class="debit">
                                                        <?php echo $transaction['debit'] > 0 ? number_format($transaction['debit'], 2) : ''; ?>
                                                    </td>
                                                    <td class="balance">
                                                        <?php echo number_format($transaction['running_balance'], 2); ?>
                                                    </td>
                                                </tr>
                                                <?php endforeach; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php include 'footer.php'; ?>
        </div>
    </div>

    <!-- Scripts -->
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/metismenu.min.js"></script>
    <script src="assets/js/simplebar.min.js"></script>
    <script src="assets/js/waves.js"></script>

    <!-- DataTables JS -->
    <script type="text/javascript" src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/buttons/2.2.2/js/dataTables.buttons.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/buttons/2.2.2/js/buttons.html5.min.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/buttons/2.2.2/js/buttons.print.min.js"></script>

    <script>
    $(document).ready(function() {
        $('#loan-passbook').DataTable({
            dom: '<"row"<"col-sm-12 col-md-6"B><"col-sm-12 col-md-6"f>>rtip',
            buttons: [
                {
                    extend: 'copy',
                    className: 'btn btn-primary btn-sm mr-2',
                    text: '<i class="fas fa-copy"></i> Copy'
                },
                {
                    extend: 'excel',
                    className: 'btn btn-primary btn-sm mr-2',
                    text: '<i class="fas fa-file-excel"></i> Excel'
                },
                {
                    extend: 'pdf',
                    className: 'btn btn-primary btn-sm mr-2',
                    text: '<i class="fas fa-file-pdf"></i> PDF'
                },
                {
                    extend: 'print',
                    className: 'btn btn-primary btn-sm',
                    text: '<i class="fas fa-print"></i> Print',
                    autoPrint: true,
                    title: '<?php echo htmlspecialchars($loan['full_name']); ?> - Loan History',
                    customize: function(win) {
                        $(win.document.body).css('padding', '20px');
                        // Direct print without opening new window
                        $(win.document.body).find('table')
                            .addClass('compact')
                            .css('font-size', 'inherit');
                        setTimeout(function() {
                            win.print();
                            win.close();
                        }, 500);
                    }
                }
            ],
            pageLength: 25,
            ordering: true,
            order: [[0, 'asc']],
            searching: true,
            responsive: true,
            columnDefs: [
                {
                    targets: [2, 3], // Debit and Credit columns
                    render: function(data, type, row) {
                        if (type === 'display' && data !== '') {
                            return 'Rs. ' + data;
                        }
                        return data;
                    }
                },
                {
                    targets: [0], // Date column
                    type: 'date-uk'
                }
            ],
            footerCallback: function(row, data, start, end, display) {
                var api = this.api();

                // Remove rupee symbol and comma from string and convert to float
                var parseAmount = function(amount) {
                    if (typeof amount === 'string') {
                        return parseFloat(amount.replace(/[^\d.-]/g, '')) || 0;
                    }
                    return amount || 0;
                };

                // Calculate total debit
                var totalDebit = api
                    .column(2, { search: 'applied' })
                    .data()
                    .reduce(function(acc, val) {
                        return acc + parseAmount(val);
                    }, 0);

                // Calculate total credit
                var totalCredit = api
                    .column(3, { search: 'applied' })
                    .data()
                    .reduce(function(acc, val) {
                        return acc + parseAmount(val);
                    }, 0);

                // Update footer row
                $(api.column(2).footer()).html('Rs. ' + totalDebit.toFixed(2));
                $(api.column(3).footer()).html('Rs. ' + totalCredit.toFixed(2));
                $(api.column(4).footer()).html('Rs. ' + (totalDebit - totalCredit).toFixed(2));
            }
        });

        // Custom sorting for UK date format (dd-mm-yyyy)
        $.fn.dataTable.ext.type.order['date-uk-pre'] = function(d) {
            if (!d) return 0;
            var ukDate = d.split('-');
            return (ukDate[2] + ukDate[1] + ukDate[0]) * 1;
        };

        // Add event listener for printing
        // $('.buttons-print').on('click', function() {
        //     window.print();
        // });

        // Add tooltips for transaction details
        $('[data-toggle="tooltip"]').tooltip();

        // Add click handler for transaction rows to show more details
        $('#loan-passbook tbody').on('click', 'tr', function() {
            var tr = $(this);
            if (tr.hasClass('selected')) {
                tr.removeClass('selected');
            } else {
                $('#loan-passbook tbody tr.selected').removeClass('selected');
                tr.addClass('selected');
            }
        });

        // Export function customization
        function customizeExport(doc) {
            // Add header
            doc.content.splice(0, 0, {
                text: '<?php echo htmlspecialchars($loan['full_name']); ?> - Loan History',
                style: 'header'
            });

            // Add loan summary
            doc.content.splice(1, 0, {
                text: [
                    'Loan Amount: Rs. <?php echo number_format($loan['requested_amount'], 2); ?>',
                    'Current Balance: Rs. <?php echo number_format($running_balance, 2); ?>',
                    'Monthly Interest Rate: <?php echo number_format($loan['monthly_interest_rate'], 2); ?>%'
                ],
                style: 'subheader'
            });

            // Customize styles
            doc.styles = {
                header: {
                    fontSize: 18,
                    bold: true,
                    alignment: 'center',
                    margin: [0, 0, 0, 10]
                },
                subheader: {
                    fontSize: 12,
                    alignment: 'left',
                    margin: [0, 5, 0, 10]
                }
            };
        }

        // Update PDF export button configuration
        var pdfButton = $('.buttons-pdf');
        if (pdfButton.length) {
            var originalAction = pdfButton.attr('data-original-title');
            pdfButton.attr('data-original-title', originalAction + ' (with formatting)');
        }
    });
    </script>

    <script src="assets/js/theme.js"></script>

    <!-- Add to existing style section or create new one -->
    <style>
        @media print {
            .main-content {
                margin-left: 0 !important;
            }
            .summary-card {
                break-inside: avoid;
            }
            .dataTables_wrapper .row:first-child,
            .dataTables_length,
            .dataTables_filter,
            .dataTables_paginate,
            .buttons-html5,
            .buttons-print {
                display: none !important;
            }
            .transaction-type {
                print-color-adjust: exact;
                -webkit-print-color-adjust: exact;
            }
        }
        
        /* Additional table styling for better print layout */
        @media print {
            .passbook-table {
                width: 100% !important;
                margin: 0 !important;
                border-collapse: collapse !important;
            }
            .passbook-table th,
            .passbook-table td {
                padding: 8px !important;
                border: 1px solid #ddd !important;
            }
            .passbook-table thead {
                display: table-header-group;
            }
            .passbook-table tfoot {
                display: table-footer-group;
            }
        }
    </style>
</body>
</html>