<?php session_start(); ?>
<?php require('./config.php'); ?>

<?php if (!isset($_SESSION['staffname'])) {
  echo "<script> window.location.replace('login.php'); </script>";
} else { ?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <title>LSL System</title>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta content="Premium Multipurpose Admin & Dashboard Template" name="description" />
    <meta content="MyraStudio" name="author" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />

    <!-- App favicon -->
    <link rel="shortcut icon" href="assets/images/favicon.ico">

    <!-- App css -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <link href="assets/css/icons.min.css" rel="stylesheet" type="text/css" />
    <link href="assets/css/theme.min.css" rel="stylesheet" type="text/css" />

</head>

<body>

    <!-- Begin page -->
    <div id="layout-wrapper">
    <?php include('header.php'); ?>
    <?php include('sidebar.php'); ?>


        <!-- ============================================================== -->
        <!-- Start right Content here -->
        <!-- ============================================================== -->
        <div class="main-content">

            <div class="page-content">
                <div class="container-fluid">

                    <!-- start page title -->
                    <div class="row">
                        <div class="col-12">
                            <div class="page-title-box d-flex align-items-center justify-content-between">
                                <h4 class="mb-0 font-size-18">Staff</h4>

                                <div class="page-title-right">
                                    <ol class="breadcrumb m-0">
                                        <li class="breadcrumb-item"><a href="javascript: void(0);">Staff</a></li>
                                        <li class="breadcrumb-item active">Add Staff</li>
                                    </ol>
                                </div>
                            </div>
                        </div>
                    </div>     
                    <!-- end page title -->

                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-body">
                    
                                <h4 class="card-title">Add Staff</h4>
                                    <p class="card-subtitle mb-4">Add staff here with required details.</p>

                                    <form class="form-horizontal" id="addStaffForm" method="POST">
                                        <div class="form-group row mb-3">
                                            <label for="fname" class="col-3 col-form-label">Name:</label>
                                            <div class="col-9">
                                                <input type="text" class="form-control" id="fname" name="fname" placeholder="Staff Name" required>
                                            </div>
                                        </div>

                                        <div class="form-group row mb-3">
                                            <label for="username" class="col-3 col-form-label">Username</label>
                                            <div class="col-9">
                                                <input type="text" class="form-control" id="username" name="username" placeholder="username" required>
                                                <span id="usernamestatus"></span>
                                            </div>
                                        </div>

                                        <div class="form-group row mb-3">
                                            <label for="email" class="col-3 col-form-label">Email</label>
                                            <div class="col-9">
                                                <input type="email" class="form-control" id="email" name="email" placeholder="Email" required>
                                            </div>
                                        </div>

                                        <div class="form-group row mb-3">
                                            <label for="usertype" class="col-3 col-form-label">User Type</label>
                                            <div class="col-9">
                                                <select name="usertype" id="usertype" class="form-control" required> 
                                                   <?php if($_SESSION['user_type']=='admin'){ ?>
                                                    <option value="admin">Admin</option>
                                                   <?php } ?>
                                                    <option value="Staff">Staff</option>
                                                    <option value="Manager">Manager</option>
                                                </select> 
                                            </div>
                                        </div>

                                        <div class="form-group row mb-3">
                                            <label for="phone" class="col-3 col-form-label">Phone</label>
                                            <div class="col-9">
                                                <input type="number" class="form-control" id="phone" name="phone" placeholder="Phone" required>
                                            </div>
                                        </div>

                                        <div class="form-group row mb-3">
                                            <label for="password" class="col-3 col-form-label">Password</label>
                                            <div class="col-9">
                                                <input type="password" class="form-control" id="password" name="password" placeholder="Password" required>
                                            </div>
                                        </div>

                                        <div class="form-group mb-0 justify-content-end row">
                                            <div class="col-9">
                                                <button type="submit" class="btn btn-info waves-effect waves-light">Save</button>
                                            </div>
                                        </div>
                                    </form>

                                </div> <!-- end card-body-->
                            </div> <!-- end card-->
                        </div> <!-- end col -->
                    </div>
                    <!-- end row-->

                </div> <!-- container-fluid -->
            </div>
            <!-- End Page-content -->

         <?php include './footer.php'; ?>                                           

        </div>
        <!-- end main content-->

    </div>
    <!-- END layout-wrapper -->

    <!-- Overlay-->
    <div class="menu-overlay"></div>

    <!-- jQuery  -->
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/metismenu.min.js"></script>
    <script src="assets/js/waves.js"></script>
    <script src="assets/js/simplebar.min.js"></script>

     <!-- Validation custom js-->
     <script src="assets/pages/validation-demo.js"></script>

    <!-- App js -->
    <script src="assets/js/theme.js"></script>

    <!-- Custom script -->
    <script>
        // AJAX for checking username availability
        $('#username').on('input', function() {
            var username = $(this).val();
            if (username.length > 0) {
                $.ajax({
                    url: 'check_username.php', // The PHP file that checks username availability
                    method: 'POST',
                    data: { username: username },
                    success: function(response) {
                        $('#usernamestatus').html(response); // Update the span with the result
                    }
                });
            } else {
                $('#usernamestatus').html(''); // Clear the status if the field is empty
            }
        });

        // Submit form
        $('#addStaffForm').on('submit', function(e) {
            e.preventDefault(); // Prevent the form from submitting the normal way
            var formData = $(this).serialize(); // Get the form data

            $.ajax({
                url: 'save_staff.php', // PHP script to save staff
                method: 'POST',
                data: formData,
                success: function(response) {
                    alert(response); // Show success/failure message
                }
            });
        });
    </script>

</body>

</html>
<?php } ?>
